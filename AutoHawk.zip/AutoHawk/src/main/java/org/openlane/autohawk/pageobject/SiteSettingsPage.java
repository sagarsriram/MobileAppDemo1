package org.openlane.autohawk.pageobject;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.*;
import org.openlane.autohawk.utils.AppiumGeneric;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.List;

@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSXCUITAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
public class SiteSettingsPage {
    AppiumDriver driver;
    AppiumGeneric generic;

    private static final Logger log = LoggerFactory.getLogger(SiteSettingsPage.class);

    public SiteSettingsPage(AppiumDriver driver) {
        this.driver = driver;
        this.generic = new AppiumGeneric();
        this.generic.setDriver(driver);
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }

    //Defining locators
    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/tv_subtitle_flipped"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/tv_subtitle_flipped")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement siteSettingsTitle;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Off Site\")")
    @iOSXCUITFindBy(id = "")
    private WebElement offSiteTab;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"On Site\")")
    @iOSXCUITFindBy(id = "")
    private WebElement onSiteTab;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"SEARCH FOR A SITE\")")
    @iOSXCUITFindBy(id = "")
    private WebElement searchBarOnSite;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/iv_back"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/iv_back")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement backButton;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/et_search_textbox"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/et_search_textbox")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement textInputForSearchBar;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/clear_button"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/clear_button")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement clearButton;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"No auction found. Enter a valid auction name.\")")
    @iOSXCUITFindBy(id = "")
    private WebElement invalidDetailsEnteredAlert;

    //Defining actions
    public void verifySiteSettingsTitle() {
        Assert.assertTrue(siteSettingsTitle.isDisplayed(), "Tittle not displayed");
    }

    public void selectOffSiteTab() {
        offSiteTab.click();
    }

    public void navigateToSearchBarThroughOnSiteTab() {
        generic.waitForVisibility(onSiteTab).click();
        searchBarOnSite.click();
    }

    public List<String> getSearchResults(String partialLocation) {
        textInputForSearchBar.sendKeys(partialLocation);
        List<WebElement> resultElements = driver.findElements(
                By.xpath("//android.widget.TextView[contains(translate(@text, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz') , '" + partialLocation + "')]")
        );

        List<String> results = new ArrayList<>();
        for (WebElement el : resultElements) {
            results.add(el.getText());
        }
        return results;
    }

    public void clickOnResult(String expectedLocation) {
        List<WebElement> resultElements = driver.findElements(
                By.xpath("//android.widget.TextView")
        );

        for (WebElement el : resultElements) {
            if (el.getText().equalsIgnoreCase(expectedLocation)) {
                el.click();
                break;
            }
        }
    }

    public void searchForInvalidSite(String invalidInput) {
        textInputForSearchBar.sendKeys(invalidInput);
        Assert.assertTrue(invalidDetailsEnteredAlert.isDisplayed(), "invalid input message not displayed");
    }
}


