package org.openlane.autohawk.pageobject;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.*;
import org.openlane.autohawk.utils.AndroidActions;
import org.openlane.autohawk.utils.AppiumGeneric;
import org.openlane.autohawk.utils.ApplicationGeneric;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.time.Duration;
import java.util.List;

@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSXCUITAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
public class InspectionRearInteriorPage {
    AppiumDriver driver;
    AppiumGeneric generic;
    AndroidActions actions;
    ApplicationGeneric appGeneric;
    private static final Logger log = LoggerFactory.getLogger(InspectionRearInteriorPage.class);

    public InspectionRearInteriorPage(AppiumDriver driver) {
        this.driver = driver;
        this.generic = new AppiumGeneric();
        this.generic.setDriver(driver);
        this.actions = new AndroidActions(driver);
        this.appGeneric = new ApplicationGeneric(driver);
        PageFactory.initElements(new AppiumFieldDecorator(driver, Duration.ofSeconds(10)), this);
    }

    //Defining locators

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/tv_title_extra_photo"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/tv_title_extra_photo")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement rearInteriorTitle;

    @AndroidFindBy(xpath = "//android.widget.TextView[@text=\"Rear Interior Photo*\"]/following-sibling::android.view.View[@resource-id=\"com.openlane.autohawk.uat:id/btn_add_photo\"]")
    private WebElement mandatoryRearInteriorPhoto;

    @AndroidFindBy(xpath = "(//android.widget.Button[@resource-id=\"com.openlane.autohawk.uat:id/btn_reviewInspection\"])[2]]")
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryRearInteriorPhotoRetake;

    @AndroidFindBy(xpath = "(//android.widget.TextView[@resource-id=\"com.openlane.autohawk.uat:id/tv_photo_title\" and @text=\"Interior Roof Photo*\"]/following-sibling::android.widget.TextView[@text = \"Add Photo*\"]")
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryInteriorRoofPhoto;

    @AndroidFindBy(xpath = "(//android.widget.Button[@resource-id=\"com.openlane.autohawk.uat:id/btn_reviewInspection\"])[2]]")
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryInteriorRoofPhotoRetake;

    @AndroidFindBy(xpath = "(//android.widget.TextView[@resource-id=\"com.openlane.autohawk.uat:id/tv_photo_title\" and @text=\"Dash Panel Photo*\"]/following-sibling::android.widget.TextView[@text = \"Add Photo*\"]")
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryDashPanelPhoto;

    @AndroidFindBy(xpath = "(//android.widget.Button[@resource-id=\"com.openlane.autohawk.uat:id/btn_reviewInspection\"])[3]")
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryDashPanelPhotoRetake;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/camera_capture_button"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/camera_capture_button")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement cameraCaptureButton;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/btn_retake"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/btn_retake")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement retakeCameraCaptureButton;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/btn_next"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/btn_next")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement confirmCameraCaptureNextButton;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/btn_next_section"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/btn_next_section")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement leftExteriorButton;

    @AndroidFindBy(xpath = "//android.widget.TextView[contains (@text, \"Interior Doors\")]/following-sibling::android.widget.ImageView")
    @iOSXCUITFindBy(id = "")
    private WebElement interiorDoorsRearDamageButton;

    public void verifyRearInteriorTitle() {
        String expectedTitle = "Rear Interior";
        String actualTitle = rearInteriorTitle.getText();
        Assert.assertEquals(actualTitle, expectedTitle, "Rear Interior title is not as expected");
        log.info("Rear Interior screen title is verified successfully");
    }

    public void verifyMandatoryInteriorPhoto() {
        appGeneric.handlePhotoSelection("Rear Interior Photo");
        appGeneric.handlePhotoSelection("Interior Roof Photo");
        appGeneric.handlePhotoSelection("Dash Panel Photo");
    }

    public void verifyMandatoryInteriorPhotoUS_OffLease() {
        appGeneric.handlePhotoSelection("Rear Interior Photo");
        appGeneric.handlePhotoSelection("Interior Roof Photo");
        appGeneric.handlePhotoSelection("Cntr Console/Shifter Photo");
        appGeneric.handlePhotoSelection("Dash Panel Photo");
    }

    public void finalizeRearInteriorInspection() throws InterruptedException {
        actions.swipeUntilEnd("up");
        //adding damage
        generic.waitForVisibility(interiorDoorsRearDamageButton).click();
        log.info("Adding damage for Interior Doors Rear section");
        appGeneric.addDamage();

        actions.swipeUntilEnd("up");
        generic.waitForVisibility(leftExteriorButton).click();
        log.info("completed all mandatory sections of Right Interior section");
    }

}
