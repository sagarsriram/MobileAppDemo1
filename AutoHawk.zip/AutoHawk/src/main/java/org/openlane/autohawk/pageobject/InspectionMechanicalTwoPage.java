package org.openlane.autohawk.pageobject;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.*;
import org.openlane.autohawk.utils.AndroidActions;
import org.openlane.autohawk.utils.AppiumGeneric;
import org.openlane.autohawk.utils.ApplicationGeneric;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;

@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSXCUITAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
public class InspectionMechanicalTwoPage {
    AppiumDriver driver;
    AppiumGeneric generic;
    AndroidActions actions;
    ApplicationGeneric appGeneric;
    private static final Logger log = LoggerFactory.getLogger(InspectionMechanicalTwoPage.class);

    public InspectionMechanicalTwoPage(AppiumDriver driver) {
        this.driver = driver;
        this.generic = new AppiumGeneric();
        this.generic.setDriver(driver);
        this.actions = new AndroidActions(driver);
        this.appGeneric = new ApplicationGeneric(driver);
        PageFactory.initElements(new AppiumFieldDecorator(driver, Duration.ofSeconds(10)), this);
    }

    //Defining locators

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/tv_title_extra_photo"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/tv_title_extra_photo")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement mechanicalTitle;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/btn_next_section"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/btn_next_section")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement electricalButton;

    public void verifyMechanicalTitle() {
        String expectedTitle1 = "Mechanical ";
        String expectedTitle2 = "Mechanical";
        String actualTitle = mechanicalTitle.getText();
        Assert.assertTrue(
                actualTitle.equals(expectedTitle1) || actualTitle.equals(expectedTitle2),
                "Mechanical title is not matching"
        );
        log.info("Mechanical title is verified successfully: " + actualTitle);
    }

    public void verifyMechanicalButtonOptionsToyotaSoldUnitNOAndGoldUnitNO() {
        List<String> items = Arrays.asList(
                "Frame/unibody must not have previous damage. Repairing still does not meet eligibility requirements.*",
                "No suspension modifications or non-factory spoilers/flare kits*",
                "No evidence of flood/water damage*",
                "There must be no evidence of oil sludge*",
                "Hoses and/or belts in poor condition*",
                "Fluids dirty and/or not at proper levels*",
                "Oil and filter not changed*",
                "Battery dirty and/or improperly fitting*",
                "Vehicle has a flat tire, therefore it cannot be driven*",
                "Tires on vehicle are not a matched set*",
                "One/more are below standards: TR Depth, condition, air press, edges*",
                "If vehicle will not start, it automatically fails. Do not jumpstart.*",
                "Vehicle does not start right away*",
                "Abnormal noises present during start up*",
                "Engine does not run smoothly while cold*",
                "Engine fails to reach normal temperature*",
                "Engine does not perform well when warm*",
                "Transmission and/or clutch does not operate smootly*",
                "Transmission and/or clutch are noisy*",
                "Vehicle does not switch smoothly from 2WD to 4WD and back*",
                "Parking brake does not set and hold vehicle*",
                "Brake pedal has excessive travel*",
                "Vehicle does not stop smoothly during light and heavy braking*",
                "Steering wheel has abnormal play and/or is not centered*",
                "Vehicle pulls left or right*",
                "Vehicle has wind, whistling, and/or buzzing noises while driving*",
                "Vehicle vibrates and/or shimmies while driving*",
                "Significant interior squeaks and/or rattles while driving*",
                "Evidence of damaged safety equipment makes vehicle ineligible for certification*",
                "Seat belts function properly*",
                "All headrests present and working properly*"
        );

        for (String item : items) {
            appGeneric.swipeToCenter(item);
            String selectedOption = appGeneric.handleButtonSelection(item, null);
            if (item.contains("Hoses and/or belts in poor condition*") && selectedOption.contains("Deduct")) {
                appGeneric.handlePhotoSelection("Engine Photo");
            }
        }
    }

    public void verifyMechanicalButtonOptionsToyotaSoldUnitNOAndGoldUnitYES() {
        List<String> items = Arrays.asList(
                "Frame/unibody must not have previous damage. Repairing still does not meet eligibility requirements.*",
                "No repaired &/or noticeably repaired body damage, nor repair of 3 or more body panels*",
                "No suspension modifications or non-factory spoilers/flare kits*",
                "No evidence of flood/water damage*",
                "There must be no evidence of oil sludge*",
                "Hoses and/or belts in poor condition*",
                "Fluids dirty and/or not at proper levels*",
                "Oil and filter not changed*",
                "Battery dirty and/or improperly fitting*",
                "Vehicle has a flat tire, therefore it cannot be driven*",
                "Tires on vehicle are not a matched set*",
                "One/more are below standards: TR Depth, condition, air press, edges*",
                "If vehicle will not start, it automatically fails. Do not jumpstart.*",
                "Vehicle does not start right away*",
                "Abnormal noises present during start up*",
                "Engine does not run smoothly while cold*",
                "Engine fails to reach normal temperature*",
                "Engine does not perform well when warm*",
                "Transmission and/or clutch does not operate smootly*",
                "Transmission and/or clutch are noisy*",
                "Vehicle does not switch smoothly from 2WD to 4WD and back*",
                "Parking brake does not set and hold vehicle*",
                "Brake pedal has excessive travel*",
                "Vehicle does not stop smoothly during light and heavy braking*",
                "Steering wheel has abnormal play and/or is not centered*",
                "Vehicle pulls left or right*",
                "Vehicle has wind, whistling, and/or buzzing noises while driving*",
                "Vehicle vibrates and/or shimmies while driving*",
                "Significant interior squeaks and/or rattles while driving*",
                "Evidence of damaged safety equipment makes vehicle ineligible for certification*",
                "Seat belts function properly*",
                "All headrests present and working properly*"
        );

        for (String item : items) {
            appGeneric.swipeToCenter(item);
            String selectedOption = appGeneric.handleButtonSelection(item, null);
            if (item.contains("Hoses and/or belts in poor condition*") && selectedOption.contains("Deduct")) {
                appGeneric.handlePhotoSelection("Engine Photo");
            }
        }
    }

    public void verifyMechanicalButtonOptionsHyundai() {
        List<String> items = Arrays.asList(
                "No suspension modifications or non-factory spoilers/flare kits*",
                "There must be no evidence of oil sludge*",
                "No evidence of flood/water damage*",
                "Engine compartment is dirty*",
                "Perform service recalls/updates/campaigns on vehicle*",
                "Hood insulation is free from damage/wear*",
                "Hoses and/or belts in poor condition*",
                "Fluids dirty and/or not at proper levels*",
                "Oil and filter not changed*",
                "Battery dirty and/or improperly fitting*",
                "Engine components free from visible leaks*",
                "Abnormal noises present during start up*",
                "Engine does not run smoothly while cold*",
                "Engine fails to reach normal temperature*",
                "Engine does not perform well when warm*",
                "If vehicle will not start, it automatically fails. Do not jumpstart.*",
                "Vehicle does not start right away*",
                "Transmission and/or clutch does not operate smootly*",
                "Transmission and/or clutch are noisy*",
                "Vehicle does not switch smoothly from 2WD to 4WD and back*",
                "Parking brake does not set and hold vehicle*",
                "Brake pedal has excessive travel*",
                "Vehicle does not stop smoothly during light and heavy braking*",
                "Steering wheel has abnormal play and/or is not centered*"
        );

        for (String item : items) {
            appGeneric.swipeToCenter(item);
            String selectedOption = appGeneric.handleButtonSelection(item, null);
            if (item.contains("Hoses and/or belts in poor condition*") && selectedOption.contains("Deduct")) {
                appGeneric.handlePhotoSelection("Engine Photo");
            }
        }
    }

    public void verifyMechanicalButtonOptionsGulfState() {
        List<String> items = Arrays.asList(
                "Vehicle has Frame/Unibody damage*",
                "No repaired &/or noticeably repaired body damage, nor repair of 3 or more body panels*",
                "No suspension modifications or non-factory spoilers/flare kits*",
                "No evidence of flood/water damage*",
                "There must be no evidence of oil sludge*",
                "Hoses and/or belts in poor condition*",
                "Fluids dirty and/or not at proper levels*",
                "Oil and filter not changed*",
                "Battery dirty and/or improperly fitting*",
                "Vehicle has a flat tire, therefore it cannot be driven*",
                "Tires on vehicle are not a matched set*",
                "Vehicle has one or more tires that are below standards for tread depth, condition, air pressure, or edges*",
                "Vehicle will not start (request dealer to jumpstart)*",
                "Vehicle does not start right away*",
                "Abnormal noises present during start up*",
                "Engine does not run smoothly while cold*",
                "Engine fails to reach normal temperature*",
                "Engine does not perform well when warm*",
                "Transmission and/or clutch does not operate smootly*",
                "Transmission and/or clutch are noisy*",
                "Vehicle does not switch smoothly from 2WD to 4WD and back*",
                "Parking brake does not set and hold vehicle*",
                "Brake pedal has excessive travel*",
                "Vehicle does not stop smoothly during light and heavy braking*",
                "Steering wheel has abnormal play and/or is not centered*",
                "Vehicle pulls left or right*",
                "Vehicle has wind, whistling, and/or buzzing noises while driving*",
                "Vehicle vibrates and/or shimmies while driving*",
                "Significant interior squeaks and/or rattles while driving*",
                "No evidence of damaged safety equipment*",
                "Seat belts function properly*",
                "All headrests present and working properly*"
        );

        for (String item : items) {
            appGeneric.swipeToCenter(item);
            String selectedOption = appGeneric.handleButtonSelection(item, null);
            if (item.contains("Hoses and/or belts in poor condition*") && selectedOption.contains("Deduct")) {
                appGeneric.handlePhotoSelection("Engine Photo");
            }
        }
    }

    public void verifyMechanicalButtonOptionsLexus() {
        List<String> items = Arrays.asList(
                "Hoses and/or belts in poor condition*",
                "Fluids dirty and/or not at proper levels*",
                "Oil and filter not changed*",
                "Battery dirty and/or improperly fitting*",
                "Vehicle has a flat tire, therefore it cannot be driven*",
                "Tires on vehicle are not a matched set*",
                "One or more tires below standards; tread depth less than 5/32\", condition, air pressure, edges*",
                "If vehicle will not start, it automatically fails. Do not jumpstart.*",
                "Vehicle does not start right away*",
                "Abnormal noises present during start up*",
                "Engine does not run smoothly while cold*",
                "Engine fails to reach normal temperature*",
                "Engine does not perform well when warm*",
                "Transmission and/or clutch does not operate smootly*",
                "Transmission and/or clutch are noisy*",
                "Vehicle does not switch smoothly from 2WD to 4WD and back*",
                "Parking brake does not set and hold vehicle*",
                "Brake pedal has excessive travel*",
                "Vehicle does not stop smoothly during light and heavy braking*",
                "Steering wheel has abnormal play and/or is not centered*",
                "Vehicle pulls left or right*",
                "Vehicle has wind, whistling, and/or buzzing noises while driving*",
                "Vehicle vibrates and/or shimmies while driving*",
                "Significant interior squeaks and/or rattles while driving*",
                "No evidence of damaged safety equipment*",
                "Seat belts function properly*",
                "All headrests present and working properly*"
        );

        for (String item : items) {
            appGeneric.swipeToCenter(item);
            String details = appGeneric.handleButtonSelection(item, null);
            log.info("For the question : {} selected option: {}", item, details);
        }
    }

    public void finalizeMechanicalSection() throws InterruptedException {
        actions.swipeUntilEnd("up");
        generic.waitForVisibility(electricalButton).click();
        log.info("Completed all sections of Mechanical.");
    }

}
