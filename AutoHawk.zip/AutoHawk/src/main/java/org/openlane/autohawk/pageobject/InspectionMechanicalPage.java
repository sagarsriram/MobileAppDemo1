package org.openlane.autohawk.pageobject;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.*;
import org.openlane.autohawk.utils.AndroidActions;
import org.openlane.autohawk.utils.AppiumGeneric;
import org.openlane.autohawk.utils.ApplicationGeneric;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.time.Duration;
import java.util.List;

@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSXCUITAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
public class InspectionMechanicalPage {
    AppiumDriver driver;
    AppiumGeneric generic;
    AndroidActions actions;
    ApplicationGeneric appGeneric;
    private static final Logger log = LoggerFactory.getLogger(InspectionMechanicalPage.class);

    public InspectionMechanicalPage(AppiumDriver driver) {
        this.driver = driver;
        this.generic = new AppiumGeneric();
        this.generic.setDriver(driver);
        this.actions = new AndroidActions(driver);
        this.appGeneric = new ApplicationGeneric(driver);
        PageFactory.initElements(new AppiumFieldDecorator(driver, Duration.ofSeconds(10)), this);
    }

    //Defining locators

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/tv_title_extra_photo"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/tv_title_extra_photo")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement mechanicalTitle;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Fuel Type*\")")
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryFuelTypeDropDownSubTitle;

    @AndroidFindBy(xpath = "//android.widget.TextView[@text = \"Drive Train*\"]/parent::android.widget.LinearLayout/following-sibling::android.widget.RadioGroup/child::android.widget.RadioButton")
    @iOSXCUITFindBy(id = "")
    private List<WebElement> mandatoryDrivetrainRadioButtonList;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Drivetrain*\")")
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryDrivetrainSubTitle;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/btn_next_section"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/btn_next_section")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement overallVehicle;

    @AndroidFindBy(xpath = "//android.widget.TextView[contains (@text, \"Brakes\")]/following-sibling::android.widget.ImageView")
    @iOSXCUITFindBy(id = "")
    private WebElement brakesDamageButton;

    public void verifyMechanicalSectionTitle() {
        String expectedTitle = "Mechanical";
        String actualTitle = mechanicalTitle.getText();
        Assert.assertEquals(actualTitle, expectedTitle, "Title does not match");
        log.info("Section Title verified successfully: {}", actualTitle);
    }

    public void verifyMandatoryEmissionStickerSection() {
        appGeneric.handlePhotoSelection("Emission Sticker Photo");
    }

    public void verifyMandatoryEmissionStickerSectionRental() {
        appGeneric.handlePhotoSelection("Emission Sticker Photo");
        appGeneric.handleButtonSelection("Emissions Sticker", "EPA Label - Present");
    }

    public void verifyMandatoryEngineSection() {
        By subTitleLocator = By.xpath("//android.widget.TextView[contains(@text, 'Engine Photo')]");
        actions.swipeUntilVisibleAndCenter(subTitleLocator);
        appGeneric.handlePhotoSelection("Engine Photo");
        appGeneric.handleDropDownSelection("Fuel Type*", "Hydrogen Fuel Cell", mandatoryFuelTypeDropDownSubTitle);
    }

    public void verifyMandatoryFluidsSection() {
        appGeneric.swipeToCenter("Fluids");
        appGeneric.handleButtonSelection("Oil Filter*", "OEM Filter");
    }

    public void verifyMandatoryDrivetrainSection() {
        By subTitleLocator = By.xpath("//android.widget.TextView[contains(@text, 'Drivetrain*')]");
        actions.swipeUntilVisibleAndCenter(subTitleLocator);
        actions.scrollElementToCenter(mandatoryDrivetrainSubTitle);
        appGeneric.handleRadioButtonsSelection(mandatoryDrivetrainRadioButtonList);
    }

    public void finalizeMechanicalInspection() throws InterruptedException {
        actions.swipeUntilEnd("up");

        //adding damage
        generic.waitForVisibility(brakesDamageButton).click();
        log.info("Adding damage to Brakes");
        appGeneric.addDamage();

        actions.swipeUntilEnd("up");
        generic.waitForVisibility(overallVehicle).click();
        log.info("completed all mandatory sections of Mechanical section");
    }


}
