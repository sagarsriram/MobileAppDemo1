package org.openlane.autohawk.pageobject;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.*;
import org.openlane.autohawk.utils.AndroidActions;
import org.openlane.autohawk.utils.AppiumGeneric;
import org.openlane.autohawk.utils.ApplicationGeneric;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;

@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSXCUITAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
public class InspectionElectricalPage {
    AppiumDriver driver;
    AppiumGeneric generic;
    AndroidActions actions;
    ApplicationGeneric appGeneric;
    private static final Logger log = LoggerFactory.getLogger(InspectionElectricalPage.class);

    public InspectionElectricalPage(AppiumDriver driver) {
        this.driver = driver;
        this.generic = new AppiumGeneric();
        this.generic.setDriver(driver);
        this.actions = new AndroidActions(driver);
        this.appGeneric = new ApplicationGeneric(driver);
        PageFactory.initElements(new AppiumFieldDecorator(driver, Duration.ofSeconds(10)), this);
    }

    //Defining locators

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/tv_title_extra_photo"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/tv_title_extra_photo")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement electricalTitle;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/btn_next_section"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/btn_next_section")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement detailinglButton;

    @AndroidFindBy(uiAutomator = "new UiSelector().textContains(\"Interior Roof Photo\")")
    @iOSXCUITFindBy(id = "")
    private WebElement interiorRoofPhotoButton;

    @AndroidFindBy(uiAutomator = "new UiSelector().textContains(\"Cntr Console/Shifter Photo\")")
    @iOSXCUITFindBy(id = "")
    private WebElement cntrlConsoleShifterButton;


    public void verifyElectricalTitle() {
        String expectedTitle = "Electrical";
        String actualTitle = electricalTitle.getText();
        Assert.assertEquals(actualTitle, expectedTitle, "Mechanical title is not matching");
        log.info("Mechanical title is verified successfully: " + actualTitle);
    }

    public void verifyElectricalButtonOptionsToyota() {
        List<String> items = Arrays.asList(
                "A/C does not blow cold air and/or work properly*",
                "Heater does not blow warm air and/or work properly*",
                "Vents do not work properly*",
                "Rear defroster does not work properly*",
                "One or more exterior lights/signals are inoperable*",
                "One or more interior lights/signals are inoperable*",
                "ABS light stays on*",
                "SRS light must go on for 4 sec & go off while engine running*",
                "One or more gauges/indicator lights do not work properly*",
                "Cruise control does not function properly*",
                "Cigarette lighter does not work*",
                "Clock does not work*",
                "Horn does not work*",
                "Windows and/or controls do not operate*",
                "Child safety seats do not function properly*",
                "Power and manual seat adjustors do not operate properly*",
                "Moon/sun roof doesn't operate and/or open and close correctly*",
                "Rear-view and/or exterior mirrors do not adjust properly*",
                "Radio, cassette and/or CD player does not work properly*",
                "Antenna is missing, does not work properly and/or is bent*",
                "One or more locking functions do not work properly*",
                "Child safety locks inoperable or malfunctioning*"

        );
        for (String item : items) {
            appGeneric.swipeToCenter(item);
            String details = appGeneric.handleButtonSelection(item, null);
            log.info("For the question : {} selected option: {}", item, details);

        }
    }


    public void verifyElectricalButtonOptionsGulfState() {
        List<String> items = Arrays.asList(
                "A/C does not blow cold air and/or work properly*",
                "Heater does not blow warm air and/or work properly*",
                "Vents do not work properly*",
                "Rear defroster does not work properly*",
                "One or more exterior lights/signals are inoperable*",
                "One or more interior lights/signals are inoperable*",
                "ABS light stays on*",
                "SRS light must go on for 4 sec & go off while engine running*",
                "One or more gauges/indicator lights do not work properly*",
                "Cruise control does not function properly*",
                "Cigarette lighter does not work*",
                "Clock does not work*",
                "Horn does not work*",
                "Windows and/or controls do not operate*",
                "Child safety seats do not function properly*",
                "Power and manual seat adjustors do not operate properly*",
                "Moon/sun roof doesn't operate and/or open and close correctly*",
                "Rear-view and/or exterior mirrors do not adjust properly*",
                "Radio, cassette and/or CD player does not work properly*",
                "Antenna is missing, does not work properly and/or is bent*",
                "One or more locking functions do not work properly*",
                "Child safety locks inoperable or malfunctioning*",
                "Dash, instrument lens, interior crevices and vents are not clean*",
                "Dash, instruments lens, interior crevices and vents have excessive dressing*",
                "Dashboard has noticeable rips, tears, fading or damage*",
                "Door jambs and gaskets are dirty*",
                "Door gaskets are missing, ripped and/or damaged*",
                "Headliner has burn holes, excessive stains and/or damage*",
                "Visor mirrors are cracked, damaged and/or dirty*",
                "Visors are dirty*",
                "Visors have burn holes, excessive stains or damage*",
                "Glove box and console areas do not work properly*",
                "Glove box and console areas are not clean*",
                "Shifter area, boot, and crevices are not clean or dressed*",
                "Cup holders are broken, missing*",
                "Cup holders are dirty*",
                "Ashtrays and lighter are missing*",
                "Ashtrays and lighter are dirty and show signs of use*",
                "Ashtrays and lighter do not function properly*",
                "Vehicle must not have a detectable odor or perfume*",
                "Interior is dirty*",
                "Interior has excessive dressing*",
                "Interior has burn holes, excessive stains or damage*",
                "Spare tire is present and full of air*",
                "Trunk and compartments have debris, stains and/or tears*",
                "Spare tire and storage area not clean*",
                "All tools are not present and/or tightened down*"
        );

        for (String item : items) {
            appGeneric.swipeToCenter(item);
            String selectedOption = appGeneric.handleButtonSelection(item, null);
            if (item.contains("ABS light stays on*") && selectedOption.contains("Deduct")) {
                appGeneric.handlePhotoSelection("Dash Panel Photo");
            }
            if (item.contains("Visors have burn holes, excessive stains or damage*") && generic.isElementVisible(interiorRoofPhotoButton)) {
                appGeneric.handlePhotoSelection("Interior Roof Photo");
            }
            if (item.contains("Cup holders are dirty*") && generic.isElementVisible(cntrlConsoleShifterButton)) {
                appGeneric.handlePhotoSelection("Cntr Console/Shifter Photo");
            }
            if (item.contains("Spare tire and storage area not clean*") && selectedOption.contains("Deduct")) {
                appGeneric.handlePhotoSelection("Cargo Area Photo");
            }

        }
    }

    public void verifyElectricalButtonOptionsLexus() {
        List<String> items = Arrays.asList(
                "A/C does not blow cold air and/or work properly*",
                "Heater does not blow warm air and/or work properly*",
                "Vents do not work properly*",
                "Rear defroster does not work properly*",
                "One or more exterior lights/signals are inoperable*",
                "One or more interior lights/signals are inoperable*",
                "ABS light stays on*",
                "Any warning light goes on for four seconds and turns off when engine is running*",
                "One or more gauges/indicator lights do not work properly*",
                "Cruise control does not function properly*",
                "Cigarette lighter does not work*",
                "Clock does not work*",
                "Horn does not work*",
                "Windows and/or controls do not operate*",
                "Power and manual seat adjustors do not operate properly*",
                "Moon/sun roof doesn't operate and/or open and close correctly*",
                "Rear-view and/or exterior mirrors do not adjust properly*",
                "Audio system does not function as designed*",
                "Antenna is missing, does not work properly and/or is bent*",
                "One or more locking functions do not work properly*",
                "Child safety locks inoperable or malfunctioning*"
        );

        for (String item : items) {
            appGeneric.swipeToCenter(item);
            String details = appGeneric.handleButtonSelection(item, null);
            log.info("For the question : {} selected option: {}", item, details);
        }
    }

    public void finalizeElectricalSection() throws InterruptedException {
        actions.swipeUntilEnd("up");
        generic.waitForVisibility(detailinglButton).click();
        log.info("Completed all sections of Electrical.");
    }

}
