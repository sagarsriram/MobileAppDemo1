package org.openlane.autohawk.pageobject;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.*;
import org.openlane.autohawk.utils.AndroidActions;
import org.openlane.autohawk.utils.AppiumGeneric;
import org.openlane.autohawk.utils.ApplicationGeneric;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSXCUITAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
public class InspectionCompletionPage {
    AppiumDriver driver;
    AppiumGeneric generic;
    AndroidActions actions;
    ApplicationGeneric appGeneric;
    private static final Logger log = LoggerFactory.getLogger(InspectionCompletionPage.class);

    public InspectionCompletionPage(AppiumDriver driver) {
        this.driver = driver;
        this.generic = new AppiumGeneric();
        this.generic.setDriver(driver);
        this.actions = new AndroidActions(driver);
        this.appGeneric = new ApplicationGeneric(driver);
        PageFactory.initElements(new AppiumFieldDecorator(driver, Duration.ofSeconds(10)), this);
    }

    //Defining locators

    @AndroidFindBy(xpath = "//android.widget.TextView[@text = \"Inspection Completed\"]")
    @iOSXCUITFindBy(id = "")
    private WebElement inspectionCompletionTitle;

    @AndroidFindBy(xpath = "//android.widget.Button")
    @iOSXCUITFindBy(id = "")
    private WebElement nextInspectionButton;

    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id=\"com.openlane.autohawk.uat:id/textView16\"]")
    @iOSXCUITFindBy(id = "")
    private WebElement timeTakenForInspection;

    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id=\"com.openlane.autohawk.uat:id/tempTextView\"]")
    @iOSXCUITFindBy(id = "")
    private WebElement noOfInspectionsCompleted;


    //Defining actions

    public Map<String, String> verifyInspectionCompletion() {
        Map<String, String> result = new HashMap<>();
        try {
            String expectedTitle = "Inspection Completed";
            String actualTitle = inspectionCompletionTitle.getText();
            Assert.assertEquals(actualTitle, expectedTitle, "Title does not match");
            log.info("Section Title verified successfully: {}", actualTitle);

            String totalTime = timeTakenForInspection.getText();
            String totalInspections = noOfInspectionsCompleted.getText();

            log.info("Total time taken for inspection: {} Total Inspections completed : {}", totalTime, totalInspections);

            generic.waitForVisibility(nextInspectionButton).click();

            result.put("TotalTime", totalTime);
            result.put("TotalInspections", totalInspections);
        } catch (Exception e) {
            log.error("Error verifying inspection completion: {}", e.getMessage());
        }
        return result;
    }

}
