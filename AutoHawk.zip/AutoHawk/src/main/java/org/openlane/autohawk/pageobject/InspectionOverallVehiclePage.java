package org.openlane.autohawk.pageobject;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.*;
import org.openlane.autohawk.utils.AndroidActions;
import org.openlane.autohawk.utils.AppiumGeneric;
import org.openlane.autohawk.utils.ApplicationGeneric;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.time.Duration;
import java.util.List;
import java.util.Random;

@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSXCUITAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
public class InspectionOverallVehiclePage {
    AppiumDriver driver;
    AppiumGeneric generic;
    AndroidActions actions;
    ApplicationGeneric appGeneric;
    private static final Logger log = LoggerFactory.getLogger(InspectionOverallVehiclePage.class);

    public InspectionOverallVehiclePage(AppiumDriver driver) {
        this.driver = driver;
        this.generic = new AppiumGeneric();
        this.generic.setDriver(driver);
        this.actions = new AndroidActions(driver);
        this.appGeneric = new ApplicationGeneric(driver);
        PageFactory.initElements(new AppiumFieldDecorator(driver, Duration.ofSeconds(10)), this);
    }

    //Defining locators

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/tv_title_extra_photo"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/tv_title_extra_photo")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement overallVehicleTitle;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Vehicle Grade*\")")
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryVehicleGradeSubTitle;

    @AndroidFindBy(xpath = "//android.widget.RadioButton")
    @iOSXCUITFindBy(id = "")
    private List<WebElement> mandatoryVehicleGradeButtonList;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/btn_next_section"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/btn_next_section")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement overallVehicle;

    @AndroidFindBy(xpath = "//android.widget.TextView[contains (@text, \"Additional Damages\")]/following-sibling::android.widget.ImageView")
    @iOSXCUITFindBy(id = "")
    private WebElement additionalDamagesDamageButton;

    //Defining actions

    public void verifyOverallVehicleSectionTitle() {
        String expectedTitle = "Overall Vehicle";
        String actualTitle = overallVehicleTitle.getText();
        Assert.assertEquals(actualTitle, expectedTitle, "Title does not match");
        log.info("Section Title verified successfully: {}", actualTitle);
    }

    public void verifyMandatoryRightFrontThreeQuartersPhoto() {
        appGeneric.handlePhotoSelection("Right Front 3/4 Photo");

        //adding damage
        generic.waitForVisibility(additionalDamagesDamageButton).click();
        log.info("Clicked on Additional Damages button");
        appGeneric.addDamage();
    }

    public void verifyMandatoryVehicleAdminVehicleGrade() throws InterruptedException {
        By subTitleLocator = By.xpath("//android.widget.TextView[contains(@text, 'Vehicle Admin*')]");
        actions.swipeUntilVisibleAndCenter(subTitleLocator);
        actions.scrollElementToCenter(mandatoryVehicleGradeSubTitle);
        appGeneric.handleRadioButtonsSelection(mandatoryVehicleGradeButtonList);

    }

    public void finalizeOverallInspection() throws InterruptedException {
        actions.swipeUntilEnd("up");
        generic.waitForVisibility(overallVehicle).click();
        log.info("completed all mandatory sections of Overall section");
    }

}
