package org.openlane.autohawk.pageobject;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.pagefactory.*;
import org.openlane.autohawk.utils.AndroidActions;
import org.openlane.autohawk.utils.AppiumGeneric;
import org.openlane.autohawk.utils.ApplicationGeneric;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.time.Duration;
import java.util.List;
import java.util.Random;

@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSXCUITAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
public class InspectionKickOffPage {
    AppiumDriver driver;
    AppiumGeneric generic;
    AndroidActions actions;
    ApplicationGeneric appGeneric;
    private static final Logger log = LoggerFactory.getLogger(InspectionKickOffPage.class);

    public InspectionKickOffPage(AppiumDriver driver) {
        this.driver = driver;
        this.generic = new AppiumGeneric();
        this.generic.setDriver(driver);
        this.actions = new AndroidActions(driver);
        this.appGeneric = new ApplicationGeneric(driver);
        PageFactory.initElements(new AppiumFieldDecorator(driver, Duration.ofSeconds(10)), this);
    }

    /*
    Defining locators
     */
    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/tv_title_extra_photo"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/tv_title_extra_photo")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement kickOffScreenTitle;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/tv_radio_group_title"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/tv_radio_group_title")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryInspectionDetailsVehicleTypeSubTitle;

    @AndroidFindBy(xpath = "//android.widget.LinearLayout[.//android.widget.TextView[@text='Vehicle Type*']]//android.widget.RadioButton")
    @iOSXCUITFindBy(id = "")
    private List<WebElement> mandatoryInspectionDetailsVehicleTypeSubTitleOptions;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/tv_title_horizontal"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/tv_title_horizontal")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryInspectionDetailsNoOfDoorsSubTitle;

    @AndroidFindBy(xpath = "//android.view.ViewGroup[.//android.widget.TextView[@text='# of Doors*']]//android.widget.Button")
    @iOSXCUITFindBy(id = "")
    private List<WebElement> mandatoryInspectionDetailsNoOfDoorsButtons;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Vehicle Source Type*\")")
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryInspectionDetailsVehicleSourceTypeTitle;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Arrival Date*\")")
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryInspectionDetailsArrivalDateTitle;

    @AndroidFindBy(uiAutomator = "new UiSelector().textContains(\"Dash VIN Plate Photo\")")
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryKickoffPhotosDashVINPlatePhotoSubTitle;

    @AndroidFindAll({
            @AndroidBy(xpath = "//android.widget.TextView[contains(@text, 'Dash VIN Plate')]/following-sibling::android.view.View[@resource-id='com.openlane.autohawk.test:id/btn_add_photo']"),
            @AndroidBy(xpath = "//android.widget.TextView[contains(@text, 'Dash VIN Plate')]/following-sibling::android.view.View[@resource-id='com.openlane.autohawk.uat:id/btn_add_photo']")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryKickoffPhotosDashVINPlatePhotoCapture;

    @AndroidFindBy(uiAutomator = "new UiSelector().textContains(\"Left Front 3/4 Photo\")")
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryKickoffPhotosLeftFrontThreeQuartersPhotoSubTitle;

    @AndroidFindBy(uiAutomator = "new UiSelector().textContains(\"Left Front Wheel/Tire Photo\")")
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryKickoffPhotosLeftFrontWheelTirePhotoSubTitle;

    @AndroidFindBy(uiAutomator = "new UiSelector().textContains(\"Undercarriage - Left Photo\")")
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryKickoffPhotosUnderCarriageLeftPhotoSubTitle;

    @AndroidFindBy(uiAutomator = "new UiSelector().textContains(\"Front Interior Photo\")")
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryKickoffPhotosFrontInteriorPhotoSubTitle;

    @AndroidFindBy(uiAutomator = "new UiSelector().textContains(\"Left Front Seat Photo\")")
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryKickoffPhotosLeftFrontSeatPhotoSubTitle;

    @AndroidFindBy(uiAutomator = "new UiSelector().textContains(\"Tire Info Sticker Photo\")")
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryKickoffPhotosTireInfoStickerPhotoSubTitle;

    @AndroidFindBy(uiAutomator = "new UiSelector().textContains(\"VIN Sticker Photo\")")
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryVINStickerPhotoSubTitle;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/et_textbox_control"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/et_textbox_control")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryMileageTextBox;

    @AndroidFindBy(uiAutomator = "new UiSelector().textContains(\"Double-check\")")
    @iOSXCUITFindBy(id = "")
    private WebElement DoubleCheckPopup;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/btn_confirm"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/btn_confirm")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement unitOfMeasurePopupConfirmButton;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/iv_back"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/iv_back")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement appBackButton;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/camera_capture_button"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/camera_capture_button")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement cameraCaptureButton;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/btn_retake"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/btn_retake")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement retakeCameraButton;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/btn_next"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/btn_next")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement confirmCaptureNextButton;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/iv_back"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/iv_back")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement backButton;

    @AndroidFindBy(xpath = "(//android.widget.TextView[@text=\"Engine Details*\"])[2]")
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryEngineDetailsEngineDetailsSubTitle;

    @AndroidFindBy(xpath = "(//android.widget.TextView[@text=\"Primary Exterior Color*\"])")
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryExteriorColorsPrimaryExteriorColorSubTitle;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.test:id/btn_next_section"),
            @AndroidBy(id = "com.openlane.autohawk.uat:id/btn_next_section")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement frontInteriorButton;

    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text , \"Vehicle Type\")]/parent::android.widget.LinearLayout/following-sibling::android.widget.RadioGroup/child::android.widget.RadioButton")
    @iOSXCUITFindBy(id = "")
    private List<WebElement> mandatoryVehicleTypeRadioButtonList;

    @AndroidFindBy(xpath = "//android.widget.TextView[contains (@text, \"VIN Sticker\")]/following-sibling::android.widget.ImageView")
    @iOSXCUITFindBy(id = "")
    private WebElement VINStickerDamageButton;

    /*
    Defining actions
     */
    public void verifyKickOffScreenTitle() {
        String expectedTitle = "Kickoff";
        String actualTitle = kickOffScreenTitle.getText();
        Assert.assertEquals(actualTitle, expectedTitle, "Kick Off screen title is not as expected");
        log.info("Kick Off screen title is verified successfully");
    }

    public void verifyMandatoryInspectionDetailsVehicleTypeRadioButtons() {
        Assert.assertTrue(mandatoryInspectionDetailsVehicleTypeSubTitle.isDisplayed(), "Vehicle Type sub title is not displayed");
        appGeneric.handleRadioButtonsSelection(mandatoryVehicleTypeRadioButtonList);
    }

    public void verifyMandatoryInspectionDetailsVehicleTypeDropDown() {
        appGeneric.handleDropDownSelection("Vehicle Type*", "Motorcycle", null);
    }

    public void verifyMandatoryInspectionDetailsNumberOfDoorsOptions() {
        Assert.assertTrue(mandatoryInspectionDetailsNoOfDoorsSubTitle.isDisplayed(), "Number of Doors sub title is not displayed");
        int count = mandatoryInspectionDetailsNoOfDoorsButtons.size();
        if (count == 0) {
            log.warn("no door selection option found");
            throw new IllegalStateException("No door selection option to select");
        }

        Random random = new Random();
        int randomIndex = random.nextInt(count);
        if (mandatoryInspectionDetailsNoOfDoorsButtons.get(randomIndex).isSelected()) {
            log.info("Number of doors option already selected: " + mandatoryInspectionDetailsNoOfDoorsButtons.get(randomIndex).getText());
            return;
        }
        mandatoryInspectionDetailsNoOfDoorsButtons.get(randomIndex).click();
        log.info("Selected number of doors option: " + mandatoryInspectionDetailsNoOfDoorsButtons.get(randomIndex).getText());
    }

    public void verifyMandatoryInspectionDetailsVehicleSourceTypeDropDown() {
        By mandatoryInspectionDetailsVehicleSourceTypeTitleDrag = AppiumBy.androidUIAutomator("new UiSelector().text(\"Vehicle Source Type*\")");
        actions.swipeUntilVisibleAndCenter(mandatoryInspectionDetailsVehicleSourceTypeTitleDrag);
        appGeneric.handleDropDownSelection("Vehicle Source Type*", "Commercial Unit", null);
    }

    public void verifyMandatoryInspectionDetailsVehicleSourceTypeDropDownRental() {
        By mandatoryInspectionDetailsVehicleSourceTypeTitleDrag = AppiumBy.androidUIAutomator("new UiSelector().text(\"Vehicle Source Type*\")");
        actions.swipeUntilVisibleAndCenter(mandatoryInspectionDetailsVehicleSourceTypeTitleDrag);
        String dropdownText = "Vehicle Source Type*";
        String selectionText = "Rental Unit";
        try {
            WebElement dropDownValidation = driver.findElement(By.xpath("//android.widget.TextView[@resource-id=\"com.openlane.autohawk.uat:id/titleText\" and @text=\"" + dropdownText + "\"]/following-sibling::android.widget.TextView[@resource-id=\"com.openlane.autohawk.uat:id/selectionText\"]"));
            if (dropDownValidation.getText().equals(selectionText)) {
                log.info("{} already selected: {}", dropdownText, dropDownValidation.getText());
            }
        } catch (Exception e) {
            log.info("entered catch");
            WebElement dropDownTitleValidation = driver.findElement(By.xpath("//android.widget.TextView[@text=\"" + dropdownText + "\" and @resource-id=\"com.openlane.autohawk.uat:id/selectionText\"]"));
            generic.waitForVisibility(dropDownTitleValidation).click();
            actions.swipe("left");
            WebElement dropDownPicker = driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().text(\"" + selectionText + "\")"));
            if (dropDownPicker.isDisplayed()) {
                dropDownPicker.click();
                log.info("Selected {} type: {}", dropdownText, dropDownPicker.getText());
            }
        }
    }

    public void verifyMandatoryInspectionDetailsArrivalDateDropDown() {
        By mandatoryInspectionDetailsArrivalDateTitleDrag = AppiumBy.androidUIAutomator("new UiSelector().text(\"Arrival Date*\")");
        actions.swipeUntilVisibleAndCenter(mandatoryInspectionDetailsArrivalDateTitleDrag);
        Assert.assertTrue(mandatoryInspectionDetailsArrivalDateTitle.isDisplayed(), "Arrival Date drop down is not displayed");

        WebElement dropDownValidation = driver.findElement(By.xpath("(//android.widget.TextView[@resource-id=\"com.openlane.autohawk.uat:id/selectionText\"])[2]"));
        if (dropDownValidation.getText().equals("Arrival Date*")) {
            generic.waitForVisibility(mandatoryInspectionDetailsArrivalDateTitle).click();

            WebElement selectDate = driver.findElement(AppiumBy.accessibilityId("15 January 2025"));
            if (selectDate.isDisplayed()) {
                selectDate.click();
                selectDate.isSelected();
                log.info("Selected arrival date: " + selectDate.getText());
            } else {
                log.warn("Arrival date option not found");
                throw new IllegalStateException("Arrival date option not found");
            }
        } else {
            log.info("Arrival date drop down is already selected " +
                    dropDownValidation.getText());
        }

    }

    public void verifyMarshalledInSelection() {
        appGeneric.swipeToCenter("Marshalled In");
        appGeneric.handleButtonSelection("Marshalled In", null);
    }

    public void verifyOptionalSellerInformationAMSCategory() {

    }

    public void verifyOptionalSellerInformationTranAccountName() {

    }

    public void verifyOptionalSellerInformationAMSOrgCode() {

    }

    public void verifyMandatoryKickoffPhotosDashVINPlatePhoto() throws InterruptedException {
        By subTitleLocator = By.xpath("//android.widget.TextView[contains(@text, 'Kickoff Photos')]");
        actions.swipeUntilVisibleAndCenter(subTitleLocator);
        //actions.scrollElementToCenter(mandatoryKickoffPhotosDashVINPlatePhotoSubTitle);
        try {
            WebElement addPhoto = driver.findElement(By.xpath("//android.widget.TextView[@text='Dash VIN Plate Photo*']/parent::android.widget.LinearLayout/following-sibling::android.widget.TextView[@text=\"Add Photo*\"]"));
            addPhoto.click();
            generic.waitForVisibility(cameraCaptureButton).click();
            generic.waitForVisibility(confirmCaptureNextButton).click();
            log.info("Dash VIN Plate Photo is captured");
        } catch (Exception e) {
            WebElement retakeCapturedPhotoButton = driver.findElement(By.xpath("//android.widget.TextView[@text = \"Dash VIN Plate Photo\"]/parent::android.widget.LinearLayout/following-sibling::android.view.ViewGroup/child::android.widget.Button[@resource-id=\"com.openlane.autohawk.uat:id/btn_reviewInspection\"]"));
            generic.isElementVisible(retakeCapturedPhotoButton);
            log.info("Dash VIN Plate Photo is already captured");

        }


    }

    public void verifyMandatoryKickoffPhotosLeftFrontThreeQuartersPhoto() throws InterruptedException {
        actions.scrollElementToCenter(mandatoryKickoffPhotosLeftFrontThreeQuartersPhotoSubTitle);
        Assert.assertTrue(mandatoryKickoffPhotosLeftFrontThreeQuartersPhotoSubTitle.isDisplayed(), "Left Front 3/4 Photo sub title is not displayed");

        try {
            WebElement addPhoto = driver.findElement(By.xpath("//android.widget.TextView[@text='Left Front 3/4 Photo*']/parent::android.widget.LinearLayout/following-sibling::android.widget.TextView[@text=\"Add Photo*\"]"));
            addPhoto.click();
            cameraCaptureButton.click();
            confirmCaptureNextButton.click();
            log.info("Left Front 3/4 Photo is captured");
        } catch (Exception e) {
            WebElement retakeCapturedPhotoButton = driver.findElement(By.xpath("//android.widget.TextView[@text = \"Left Front 3/4 Photo\"]/parent::android.widget.LinearLayout/following-sibling::android.view.ViewGroup/child::android.widget.Button[@resource-id=\"com.openlane.autohawk.uat:id/btn_reviewInspection\"]"));
            generic.isElementVisible(retakeCapturedPhotoButton);
            log.info("Left Front 3/4 Photo is already captured");

        }
    }

    public void verifyMandatoryKickoffPhotosFullFrontPhoto() {
        appGeneric.swipeToCenter("full Front Photo");
        appGeneric.handlePhotoSelection("full Front Photo");
    }

    public void verifyMandatoryKickoffPhotosRightFrontThreeQuartersPhoto() {
        appGeneric.swipeToCenter("Right Front 3/4 Photo");
        appGeneric.handlePhotoSelection("Right Front 3/4 Photo");
    }

    public void verifyMandatoryKickoffPhotosFuelTankPhoto() {
        appGeneric.swipeToCenter("Fuel Tank");
        appGeneric.handlePhotoSelection("Fuel Tank");
    }

    public void verifyMandatoryKickoffPhotosLeftFrontWheelTirePhoto() {
        actions.scrollElementToCenter(mandatoryKickoffPhotosLeftFrontWheelTirePhotoSubTitle);
        Assert.assertTrue(mandatoryKickoffPhotosLeftFrontWheelTirePhotoSubTitle.isDisplayed(), "Left Front Wheel/Tire Photo sub title is not displayed");
        try {
            WebElement addPhoto = driver.findElement(By.xpath("//android.widget.TextView[@text='Left Front Wheel/Tire Photo*']/parent::android.widget.LinearLayout/following-sibling::android.widget.TextView[@text=\"Add Photo*\"]"));
            addPhoto.click();
            cameraCaptureButton.click();
            confirmCaptureNextButton.click();
            log.info("Left Front Wheel/Tire Photo is captured");
        } catch (Exception e) {
            WebElement retakeCapturedPhotoButton = driver.findElement(By.xpath("//android.widget.TextView[@text = \"Left Front Wheel/Tire Photo\"]/parent::android.widget.LinearLayout/following-sibling::android.view.ViewGroup/child::android.widget.Button[@resource-id=\"com.openlane.autohawk.uat:id/btn_reviewInspection\"]"));
            generic.isElementVisible(retakeCapturedPhotoButton);
            log.info("Left Front Wheel/Tire Photo is already captured");

        }
    }

    public void verifyMandatoryKickoffPhotosUnderCarriageLeftPhoto() {
        actions.scrollElementToCenter(mandatoryKickoffPhotosUnderCarriageLeftPhotoSubTitle);
        Assert.assertTrue(mandatoryKickoffPhotosUnderCarriageLeftPhotoSubTitle.isDisplayed(), "Undercarriage - Left Photo sub title is not displayed");
        try {
            WebElement addPhoto = driver.findElement(By.xpath("//android.widget.TextView[@text='Undercarriage - Left Photo*']/parent::android.widget.LinearLayout/following-sibling::android.widget.TextView[@text=\"Add Photo*\"]"));
            addPhoto.click();
            cameraCaptureButton.click();
            confirmCaptureNextButton.click();
            log.info("Undercarriage - Left Photo is captured");
        } catch (Exception e) {
            WebElement retakeCapturedPhotoButton = driver.findElement(By.xpath("//android.widget.TextView[@text = \"Undercarriage - Left Photo\"]/parent::android.widget.LinearLayout/following-sibling::android.view.ViewGroup/child::android.widget.Button[@resource-id=\"com.openlane.autohawk.uat:id/btn_reviewInspection\"]"));
            generic.isElementVisible(retakeCapturedPhotoButton);
            log.info("Undercarriage - Left Photo is already captured");

        }
    }

    public void verifyMandatoryKickoffPhotosFrontInteriorPhoto() {
        actions.scrollElementToCenter(mandatoryKickoffPhotosFrontInteriorPhotoSubTitle);
        Assert.assertTrue(mandatoryKickoffPhotosFrontInteriorPhotoSubTitle.isDisplayed(), "Front Interior Photo sub title is not displayed");
        try {
            WebElement addPhoto = driver.findElement(By.xpath("//android.widget.TextView[@text='Front Interior Photo*']/parent::android.widget.LinearLayout/following-sibling::android.widget.TextView[@text=\"Add Photo*\"]"));
            addPhoto.click();
            cameraCaptureButton.click();
            confirmCaptureNextButton.click();
            log.info("Front Interior Photo is captured");
        } catch (Exception e) {
            WebElement retakeCapturedPhotoButton = driver.findElement(By.xpath("//android.widget.TextView[@text = \"Front Interior Photo\"]/parent::android.widget.LinearLayout/following-sibling::android.view.ViewGroup/child::android.widget.Button[@resource-id=\"com.openlane.autohawk.uat:id/btn_reviewInspection\"]"));
            generic.isElementVisible(retakeCapturedPhotoButton);
            log.info("Front Interior Photo is already captured");

        }
    }

    public void verifyMandatoryKickoffPhotosLeftFrontSeatPhoto() {
        actions.scrollElementToCenter(mandatoryKickoffPhotosLeftFrontSeatPhotoSubTitle);
        Assert.assertTrue(mandatoryKickoffPhotosLeftFrontSeatPhotoSubTitle.isDisplayed(), "Left Front Seat Photo sub title is not displayed");
        try {
            WebElement addPhoto = driver.findElement(By.xpath("//android.widget.TextView[@text='Front Interior Photo*']/parent::android.widget.LinearLayout/following-sibling::android.widget.TextView[@text=\"Add Photo*\"]"));
            addPhoto.click();
            cameraCaptureButton.click();
            confirmCaptureNextButton.click();
            log.info("Left Front Seat Photo is captured");
        } catch (Exception e) {
            WebElement retakeCapturedPhotoButton = driver.findElement(By.xpath("//android.widget.TextView[@text = \"Front Interior Photo\"]/parent::android.widget.LinearLayout/following-sibling::android.view.ViewGroup/child::android.widget.Button[@resource-id=\"com.openlane.autohawk.uat:id/btn_reviewInspection\"]"));
            generic.isElementVisible(retakeCapturedPhotoButton);
            log.info("Left Front Seat Photo is already captured");

        }
    }

    public void verifyMandatoryKickoffPhotosTireInfoStickerPhoto() {
        actions.scrollElementToCenter(mandatoryKickoffPhotosTireInfoStickerPhotoSubTitle);
        Assert.assertTrue(mandatoryKickoffPhotosTireInfoStickerPhotoSubTitle.isDisplayed(), "Tire Info Sticker Photo sub title is not displayed");
        try {
            WebElement addPhoto = driver.findElement(By.xpath("//android.widget.TextView[@text='Front Interior Photo*']/parent::android.widget.LinearLayout/following-sibling::android.widget.TextView[@text=\"Add Photo*\"]"));
            addPhoto.click();
            cameraCaptureButton.click();
            confirmCaptureNextButton.click();
            log.info("Tire Info Sticker Photo is captured");
        } catch (Exception e) {
            WebElement retakeCapturedPhotoButton = driver.findElement(By.xpath("//android.widget.TextView[@text = \"Front Interior Photo\"]/parent::android.widget.LinearLayout/following-sibling::android.view.ViewGroup/child::android.widget.Button[@resource-id=\"com.openlane.autohawk.uat:id/btn_reviewInspection\"]"));
            generic.isElementVisible(retakeCapturedPhotoButton);
            log.info("Tire Info Sticker Photo is already captured");

        }
    }

    public void verifyMandatoryKickOffOdometerInfoSection() {

        appGeneric.swipeToCenter("Odometer Info");
        By subTitleLocator2 = By.xpath("//android.widget.TextView[contains(@text, 'Mileage*')]");
        actions.swipeUntilVisibleAndCenter(subTitleLocator2);
        generic.waitForVisibility(mandatoryMileageTextBox).click();
        generic.waitForVisibility(mandatoryMileageTextBox).clear();
        generic.waitForVisibility(mandatoryMileageTextBox).sendKeys("4321");
        AndroidDriver driver1 = (AndroidDriver) driver;
        driver1.pressKey(new KeyEvent(AndroidKey.ENTER));
        if (generic.isElementVisible(DoubleCheckPopup)) {
            unitOfMeasurePopupConfirmButton.click();
            log.info("Double-check odo reading popup is displayed");
        } else {
            log.info("Double-check odo reading popup is not displayed");
        }

        By subTitleLocator3 = By.xpath("//android.widget.TextView[contains(@text, 'Odo Scale*')]");
        actions.swipeUntilVisibleAndCenter(subTitleLocator3);
        appGeneric.handleCheckBoxSelection("Odo Scale");
        if (generic.isElementVisible(DoubleCheckPopup)) {
            unitOfMeasurePopupConfirmButton.click();
            log.info("Unit of measure popup is displayed");
        } else {
            log.info("Unit of measure popup is not displayed");
        }

        appGeneric.swipeToCenter("Odometer Photo");
        appGeneric.handlePhotoSelection("Odometer Photo");


    }

    public void verifyMandatoryVINStickerVINStickerPhoto() {
        actions.scrollElementToCenter(mandatoryVINStickerPhotoSubTitle);
        Assert.assertTrue(mandatoryVINStickerPhotoSubTitle.isDisplayed(), "VIN Sticker Photo sub title is not displayed");
        try {
            WebElement addPhoto = driver.findElement(By.xpath("//android.widget.TextView[@text='VIN Sticker Photo*']/parent::android.widget.LinearLayout/following-sibling::android.widget.TextView[@text=\"Add Photo*\"]"));
            addPhoto.click();
            cameraCaptureButton.click();
            confirmCaptureNextButton.click();
            log.info("VIN Sticker Photo is captured");
        } catch (Exception e) {
            WebElement retakeCapturedPhotoButton = driver.findElement(By.xpath("//android.widget.TextView[@text = \"VIN Sticker Photo\"]/parent::android.widget.LinearLayout/following-sibling::android.view.ViewGroup/child::android.widget.Button[@resource-id=\"com.openlane.autohawk.uat:id/btn_reviewInspection\"]"));
            generic.isElementVisible(retakeCapturedPhotoButton);
            log.info("VIN Sticker Photo is already captured");
        }
        //adding damage
        generic.waitForVisibility(VINStickerDamageButton).click();
        appGeneric.addDamage();
    }

    public void verifyMandatoryVINPlateStickerPhoto() {
        appGeneric.swipeToCenter("VIN Plate/ Sticker");
        appGeneric.handlePhotoSelection("VIN Sticker/ Plate Photo");
    }

    public void verifyOptionalVINPlateAnnouncementsSelection() {

    }

    public void verifyMandatoryEngineDetailsEngineDetailsDropDown() {
        By mandatoryInspectionDetailsVehicleSourceTypeTitleDrag = AppiumBy.androidUIAutomator("new UiSelector().text(\"Engine Details*\")");
        actions.swipeUntilVisibleAndCenter(mandatoryInspectionDetailsVehicleSourceTypeTitleDrag);
        Assert.assertTrue(mandatoryEngineDetailsEngineDetailsSubTitle.isDisplayed(), "Engine Details sub title is not displayed");

        appGeneric.handleDropDownSelection("Engine Details*", "6 Cylinder Gas", null);
    }

    public void verifyFrontTireSpecs() {
        appGeneric.swipeToCenter("Tire Width - Front");
        handleDropDownSelection("Tire Width - Front*", "225", null);
    }

    public void verifyMandatoryExteriorColorsPrimaryExteriorColorsDropDown() {
        By mandatoryInspectionDetailsVehicleSourceTypeTitleDrag = AppiumBy.androidUIAutomator("new UiSelector().text(\"Exterior Colors*\")");
        actions.swipeUntilVisibleAndCenter(mandatoryInspectionDetailsVehicleSourceTypeTitleDrag);
        Assert.assertTrue(mandatoryExteriorColorsPrimaryExteriorColorSubTitle.isDisplayed(), "Primary Exterior Color sub title is not displayed");

        appGeneric.handleDropDownSelection("Primary Exterior Color*", "Blue", null);
    }

    public void verifyOptionalExteriorColorsOEMExteriorColorNameTextField() {

    }

    public void verifyOptionalExteriorColorsOEMExteriorColorCodeTextField() {

    }

    public void verifyOptionalExteriorColorsSecondaryColorDropDown() {

    }

    public void finalizeKickOffSection() throws InterruptedException {
        actions.swipeUntilEnd("up");
        generic.waitForVisibility(frontInteriorButton).click();
        log.info("completed all mandatory sections of kick off");

    }

    public void handleDropDownSelection(String dropdownText, String selectionText, WebElement sectionTitleName) {
        try {
            // Locate and validate the dropdown
            WebElement dropDownValidation = driver.findElement(By.xpath("//android.widget.TextView[@resource-id=\"com.openlane.autohawk.uat:id/titleText\" and @text=\"" + dropdownText + "\"]/following-sibling::android.widget.TextView[@resource-id=\"com.openlane.autohawk.uat:id/selectionText\"]"));
            if (generic.isElementVisible(dropDownValidation)) {
                log.info("{} already selected: {}", dropdownText, dropDownValidation.getText());
                return;
            }
        } catch (Exception e) {
            log.info("Dropdown validation processing for : {}", dropdownText);
        }

        try {
            // Check and interact with the mandatory dropdown
            if (dropdownText.equals(sectionTitleName.getText())) {
                generic.waitForVisibility(sectionTitleName).click();
                WebElement dropDownPicker = driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().text(\"" + selectionText + "\")"));
                if (dropDownPicker.isDisplayed()) {
                    dropDownPicker.click();
                    By titleLocator = AppiumBy.id("com.openlane.autohawk.uat:id/tv_title");
                    try {
                        WebElement title = driver.findElement(titleLocator);
                        if (!title.getText().equals(dropdownText.substring(0, dropdownText.length() - 1))) {
                            log.info("going back");
                            appBackButton.click();
                        } else {
                            log.info("continuing... dropdown selection");
                        }
                    } catch (Exception e) {
                        log.info("Title not found, continuing with dropdown selection");
                    }
                    log.info("Selected {} type: {}", dropdownText, dropDownPicker.getText());
                } else {
                    log.warn("Selected {} option not found", dropdownText);
                    throw new IllegalStateException("Vehicle source type option not found");
                }
            }
        } catch (NoSuchElementException e) {
            log.error("Dropdown or {} option not found", dropdownText, e);
            throw e;
        } catch (Exception e) {
            log.error("Unexpected error while interacting with the {} dropdown", dropdownText, e);
            throw e;
        }
    }
}


