package org.openlane.autohawk.pageobject;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.*;
import org.openlane.autohawk.utils.AndroidActions;
import org.openlane.autohawk.utils.AppiumGeneric;
import org.openlane.autohawk.utils.ApplicationGeneric;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;

@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSXCUITAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
public class InspectionDisplayMarketingInformationPage {
    AppiumDriver driver;
    AppiumGeneric generic;
    AndroidActions actions;
    ApplicationGeneric appGeneric;
    private static final Logger log = LoggerFactory.getLogger(InspectionDisplayMarketingInformationPage.class);

    public InspectionDisplayMarketingInformationPage(AppiumDriver driver) {
        this.driver = driver;
        this.generic = new AppiumGeneric();
        this.generic.setDriver(driver);
        this.actions = new AndroidActions(driver);
        this.appGeneric = new ApplicationGeneric(driver);
        PageFactory.initElements(new AppiumFieldDecorator(driver, Duration.ofSeconds(10)), this);
    }

    //Defining locators
    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/tv_title_extra_photo"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/tv_title_extra_photo")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement displayMarketingInformationTitle;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/btn_next_section"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/btn_next_section")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement paperworkButton;

    public void verifyTitleDisplayMarketingInformation() {
        String expectedTitle = "Display / Marketing Information";
        String actualTitle = displayMarketingInformationTitle.getText();
        Assert.assertEquals(actualTitle, expectedTitle, "Display / Marketing Information title is not matching");
        log.info("Display / Marketing Information title is verified successfully: " + actualTitle);
    }

    public void verifyDisplayMarketingInformationButtonOptions() {
        List<String> items = Arrays.asList(
                "Does the vehicle have a Lexus CPOV certification label displayed?*",
                "Does the vehicle have a Lexus permanent certification insignia affixed to the driver's side doorjamb?*",
                "Does the vehicle have a Lexus CPOV windshield decal displayed?*",
                "Does the vehicle have a model year windshield decal displayed?*",
                "Does the vehicle have a Lexus CPOV license plate insert?*",
                "Does the vehicle have a Lexus certified window label?*",
                "Does the window label have pricing information?*"
        );

        for (String item : items) {
            appGeneric.swipeToCenter(item);
            String details = appGeneric.handleButtonSelection(item, null);
            log.info("For the question : {} selected option: {}", item, details);
        }
    }

    public void finalizeDisplayMarketingInformationSection() throws InterruptedException {
        actions.swipeUntilEnd("up");
        generic.waitForVisibility(paperworkButton).click();
        log.info("Completed all sections of Display / Marketing Information.");
    }

}
