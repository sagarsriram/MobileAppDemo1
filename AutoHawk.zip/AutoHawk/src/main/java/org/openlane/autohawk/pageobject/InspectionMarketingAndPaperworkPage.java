package org.openlane.autohawk.pageobject;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.*;
import org.openlane.autohawk.utils.AndroidActions;
import org.openlane.autohawk.utils.AppiumGeneric;
import org.openlane.autohawk.utils.ApplicationGeneric;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;

@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSXCUITAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
public class InspectionMarketingAndPaperworkPage {
    AppiumDriver driver;
    AppiumGeneric generic;
    AndroidActions actions;
    ApplicationGeneric appGeneric;
    private static final Logger log = LoggerFactory.getLogger(InspectionMarketingAndPaperworkPage.class);

    public InspectionMarketingAndPaperworkPage(AppiumDriver driver) {
        this.driver = driver;
        this.generic = new AppiumGeneric();
        this.generic.setDriver(driver);
        this.actions = new AndroidActions(driver);
        this.appGeneric = new ApplicationGeneric(driver);
        PageFactory.initElements(new AppiumFieldDecorator(driver, Duration.ofSeconds(10)), this);
    }

    //Defining locators

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/tv_title_extra_photo"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/tv_title_extra_photo")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement marketingAndPaperworkTitle;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/btn_next_section"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/btn_next_section")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement eligibilityButton;

    public void verifyMarketingAndPaperworkTitle() {
        String expectedTitle1 = "Marketing and Paperwork ";
        String expectedTitle2 = "Paperwork";
        String expectedTitle3 = "Marketing and Paperwork";
        String actualTitle = generic.waitForVisibility(marketingAndPaperworkTitle).getText();
        Assert.assertTrue(
                actualTitle.equals(expectedTitle1) || actualTitle.equals(expectedTitle2) || actualTitle.equals(expectedTitle3),
                "Marketing and Paperwork title is not matching"
        );
        log.info("Marketing and Paperwork title is verified successfully: " + actualTitle);
    }

    public void verifyMarketingAndPaperworkButtonOptionsGulfState() {
        List<String> items = Arrays.asList(
                "Does the vehicle have a CPO certified window label?*",
                "Does the window label have pricing information?*",
                "Window label has the warranty expiration date*",
                "Check sheet is missing (digital or paper copies acceptable)*",
                "Check sheet is not filled out completely and correctly (digital or paper copies acceptable)*",
                "Dealer is not properly using TCUV adhesive/static cling or visor hanger*",
                "FTC window label is affixed to the vehicle*",
                "Warranty box is checked*",
                "Repair orders documenting required repairs are missing (digital or paper copies acceptable)*",
                "Repair orders match the checklist (digital or paper copies acceptable)*",
                "Vehicle history report (VHR) is missing (digital or paper copies acceptable)*",
                "Techstream health check is not complete or copy is missing from file (digital or paper copies acceptable)*",
                "Are there open recalls on this vehicle?*"
        );

        for (String item : items) {
            appGeneric.swipeToCenter(item);
            String details = appGeneric.handleButtonSelection(item, null);
            log.info("For the question : {} selected option: {}", item, details);
        }
    }

    public void verifyMarketingAndPaperworkButtonOptionsHyundaiSoldUnitNO() {
        List<String> items = Arrays.asList(
                "Vehicle has CPOV signage displayed*",
                "Does the window label have pricing information?*",
                "Window label has the warranty expiration date*",
                "FTC window label is affixed to the vehicle*",
                "Warranty box is checked*",
                "Check sheet is missing*",
                "Check sheet is not filled out completely and correctly*",
                "Check sheet has all required signatures*",
                "Repair orders documenting required repairs are missing*",
                "Repair orders match the checklist*",
                "Vehicle history report (VHR) is missing*"
        );

        for (String item : items) {
            appGeneric.swipeToCenter(item);
            String details = appGeneric.handleButtonSelection(item, null);
            log.info("For the question : {} selected option: {}", item, details);
        }
    }

    public void verifyMarketingAndPaperworkButtonOptionsToyotaSoldUnitNOAndSelectedGoldUnit() {
        List<String> items = Arrays.asList(
                "Does the vehicle have a CPO certified window label?*",
                "Does the window label have pricing information?*",
                "Does the window label have TCUV warranty and RSA benefits listed?*",
                "Check sheet is present (digital or paper copies acceptable)*",
                "Check sheet is not filled out completely and correctly (digital or paper copies acceptable)*",
                "TCUV Adhesive/Static cling logos being used?*",
                "FTC window label is affixed to the vehicle*",
                "Vehicle's inspection form is missing any required signatures (This excludes the detailer) (digital or paper copies acceptable)*",
                "Repair orders documenting required repairs are missing (digital or paper copies acceptable)*",
                "Warranty box is checked*",
                "Repair orders match the checklist (digital or paper copies acceptable)*",
                "Vehicle history report (VHR) is missing (digital or paper copies acceptable)*",
                "Are there open recalls on this vehicle confirmed at https://www.toyota.com/recall/?*"
        );

        for (String item : items) {
            appGeneric.swipeToCenter(item);
            String details = appGeneric.handleButtonSelection(item, null);
            log.info("For the question : {} selected option: {}", item, details);
        }
    }

    public void verifyMarketingAndPaperworkButtonOptionsHyundaiSoldUnitYES() {
        List<String> items = Arrays.asList(
                "Does the window label have pricing information?*",
                "Check sheet is missing*",
                "Check sheet is not filled out completely and correctly*",
                "Check sheet has all required signatures*",
                "Repair orders documenting required repairs are missing*",
                "Repair orders match the checklist*",
                "Vehicle history report (VHR) is missing*"
        );

        for (String item : items) {
            appGeneric.swipeToCenter(item);
            String details = appGeneric.handleButtonSelection(item, null);
            log.info("For the question : {} selected option: {}", item, details);
        }
    }

    public void verifyPaperworkButtonOptionsLexus() {
        List<String> items = Arrays.asList(
                "Lexus vehicle certificate is present (digital or paper copies acceptable)*",
                "Lexus vehicle certificate includes vin (digital or paper copies acceptable)*",
                "Lexus vehicle certificate includes signature of person who performed certification (digital or paper copies acceptable)*",
                "Check sheet is present (digital or paper copies acceptable)*",
                "Check sheet is not filled out completely and correctly (digital or paper copies acceptable)*",
                "Check sheet has all required signatures (digital or paper copies acceptable)*",
                "Repair orders documenting required repairs are missing (digital or paper copies acceptable)*",
                "Repair orders match the checklist (digital or paper copies acceptable)*",
                "Vehicle history report (VHR) is missing (digital or paper copies acceptable)*",
                "Original owners manual is present*",
                "Certified pre-owned warranty supplement and roadside assistance guide is present*",
                "Are there open recalls on this vehicle confirmed at www.Lexus.com/recalls?*"
        );

        for (String item : items) {
            appGeneric.swipeToCenter(item);
            String details = appGeneric.handleButtonSelection(item, null);
            log.info("For the question : {} selected option: {}", item, details);
        }
    }

    public void finalizeMarketingAndPaperworkSection() throws InterruptedException {
        actions.swipeUntilEnd("up");
        generic.waitForVisibility(eligibilityButton).click();
        log.info("Completed all sections of CPO Audit - Sold Unit Paperwork.");
    }

}
