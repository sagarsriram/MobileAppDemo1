package org.openlane.autohawk.testcases.functional;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.ios.IOSDriver;
import org.openlane.autohawk.pageobject.HomePage;
import org.openlane.autohawk.pageobject.LoginPage;
import org.openlane.autohawk.testcases.e2e.Full_InspectionTC;
import org.openlane.autohawk.testutils.BaseTest;
import org.openlane.autohawk.utils.AndroidActions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;


public class BrowserStackIntegration extends BaseTest {
    private static final Logger log = LoggerFactory.getLogger(BrowserStackIntegration.class);

    @Test
    public void demoChaining() throws InterruptedException {
        log.info("device launched");
    //    driver.findElement(AppiumBy.iOSClassChain("**/XCUIElementTypeStaticText[`name == \"Buttons\"`]")).click();
        IOSDriver iosDriver = (IOSDriver) driver;
        AndroidActions actions = new AndroidActions(driver);
        driver.switchTo().alert().dismiss();
        actions.swipeUntilEnd("up");
        iOSGeneric iosgeneric = new iOSGeneric();
   //     driver.navigate().back();
        driver.findElement(AppiumBy.iOSClassChain("**/XCUIElementTypeStaticText[`name == \"TEMP LOG IN\"`]")).click();
        driver.findElement(AppiumBy.iOSClassChain("**/XCUIElementTypeSwitch[1]")).click();
        driver.findElement(AppiumBy.iOSClassChain("**/XCUIElementTypeSwitch[1]")).click();

//        driver.findElement(AppiumBy.iOSClassChain("**/XCUIElementTypeStaticText[`name == \"Confirm / Cancel\"`]")).click();
//        iosgeneric.acceptAlert();
//        driver.findElement(AppiumBy.iOSClassChain("**/XCUIElementTypeStaticText[`name == \"Simple\"`]")).click();
//        driver.switchTo().alert().dismiss();
//        driver.findElement(AppiumBy.iOSClassChain("**/XCUIElementTypeStaticText[`name == \"Simple\"`]")).click();
//        driver.switchTo().alert().accept();


    }


    public class iOSGeneric {
        // Interact with a Button
        public void clickButton(String buttonName) {
            WebElement button = driver.findElement(AppiumBy.iOSClassChain("**/XCUIElementTypeButton[`name == \"" + buttonName + "\"`]"));
            button.click();
        }

        // Interact with Static Text
        public String getStaticText(String textName) {
            WebElement staticText = driver.findElement(AppiumBy.iOSClassChain("**/XCUIElementTypeStaticText[`name == \"" + textName + "\"`]"));
            return staticText.getText();
        }

        // Interact with a Text Field
        public void enterTextInTextField(String fieldName, String text) {
            WebElement textField = driver.findElement(AppiumBy.iOSClassChain("**/XCUIElementTypeTextField[`name == \"" + fieldName + "\"`]"));
            textField.sendKeys(text);
        }

        // Interact with a Secure Text Field
        public void enterTextInSecureTextField(String fieldName, String text) {
            WebElement secureTextField = driver.findElement(AppiumBy.iOSClassChain("**/XCUIElementTypeSecureTextField[`name == \"" + fieldName + "\"`]"));
            secureTextField.sendKeys(text);
        }

        // Interact with an Image
        public void clickImage(String imageName) {
            WebElement image = driver.findElement(AppiumBy.iOSClassChain("**/XCUIElementTypeImage[`name == \"" + imageName + "\"`]"));
            image.click();
        }

        // Interact with a Picker Wheel
        public void selectPickerWheelValue(String wheelName, String value) {
            WebElement pickerWheel = driver.findElement(AppiumBy.iOSClassChain("**/XCUIElementTypePickerWheel[`name == \"" + wheelName + "\"`]"));
            pickerWheel.sendKeys(value);
            By abc = AppiumBy.iOSClassChain("");
            WebElement pickerElement = driver.findElement(abc);

        }

        // Interact with a Switch
        public void toggleSwitch(String switchName, boolean enable) {
            WebElement switchElement = driver.findElement(AppiumBy.iOSClassChain("**/XCUIElementTypeSwitch[`name == \"" + switchName + "\"`]"));
            if (enable && switchElement.getAttribute("value").equals("0")) {
                switchElement.click();
            } else if (!enable && switchElement.getAttribute("value").equals("1")) {
                switchElement.click();
            }
        }

        // Interact with a Slider
        public void setSliderValue(String sliderName, double value) {
            WebElement slider = driver.findElement(AppiumBy.iOSClassChain("**/XCUIElementTypeSlider[`name == \"" + sliderName + "\"`]"));
            slider.sendKeys(String.valueOf(value));
        }

        // Interact with a Table Cell
        public void clickTableCell(String cellName) {
            WebElement cell = driver.findElement(AppiumBy.iOSClassChain("**/XCUIElementTypeCell[`name == \"" + cellName + "\"`]"));
            cell.click();
        }

        // Interact with a Collection View
        public void clickCollectionViewItem(String itemName) {
            WebElement item = driver.findElement(AppiumBy.iOSClassChain("**/XCUIElementTypeCollectionView[`name == \"" + itemName + "\"`]"));
            item.click();
        }

        // Interact with a Scroll View
        public void scrollToElement(String elementName) {
            WebElement element = driver.findElement(AppiumBy.iOSClassChain("**/XCUIElementTypeScrollView[`name == \"" + elementName + "\"`]"));
            element.click();
        }

        // Interact with a Web View
        public void interactWithWebView(String webViewName) {
            WebElement webView = driver.findElement(AppiumBy.iOSClassChain("**/XCUIElementTypeWebView[`name == \"" + webViewName + "\"`]"));
            webView.click();
        }

        // Interact with an Alert
        public void acceptAlert() {
            WebElement alert = driver.findElement(AppiumBy.iOSClassChain("**/XCUIElementTypeAlert"));
            alert.findElement(AppiumBy.iOSClassChain("**/XCUIElementTypeButton[`name == \"OK\"`]")).click();
        }
    }
}
