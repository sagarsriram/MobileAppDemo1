package org.openlane.autohawk.testcases.e2e;

import org.openlane.autohawk.pageobject.*;
import org.openlane.autohawk.testutils.BaseTest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

import static org.openlane.autohawk.testutils.Listeners.extentTest;

//Completed - do not alter anything unless u debug

public class AVL_CPO_Inspection_HYUNDAI_SoldUnit_YES extends BaseTest {
    // This class is a placeholder for the full inspection test case.
    // It will contain methods to perform end-to-end testing of the application.
    // The actual implementation will depend on the specific requirements and flow of the application.
    LoginPage login;
    HomePage home;
    SiteSettingsPage siteSettings;
    VehicleInfoPage vehicleInfo;
    InspectionLandingPage inspectionHome;
    InspectionTypeOfInspectionPage typeOfInspectionSection;
    InspectionMarketingAndPaperworkPage marketingAndPaperworkSection;
    InspectionVehicleGeneralEligibilityPage vehicleGeneralEligibilitySection;
    InspectionImagesPage imagesSection;
    InspectionCPOAuditSoldUnitPaperworkPage cpoAuditSoldUnitPaperwork;
    InspectionCommentsForClientPage commentsForClientSection;
    InspectionCompletionPage completionSection;
    private static final Logger log = LoggerFactory.getLogger(AVL_CPO_Inspection_HYUNDAI_SoldUnit_YES.class);

    @BeforeClass
    public void setupPages() {
        login = new LoginPage(driver);
        home = new HomePage(driver);
        siteSettings = new SiteSettingsPage(driver);
        vehicleInfo = new VehicleInfoPage(driver);
        inspectionHome = new InspectionLandingPage(driver);
        typeOfInspectionSection = new InspectionTypeOfInspectionPage(driver);
        marketingAndPaperworkSection = new InspectionMarketingAndPaperworkPage(driver);
        vehicleGeneralEligibilitySection = new InspectionVehicleGeneralEligibilityPage(driver);
        imagesSection = new InspectionImagesPage(driver);
        cpoAuditSoldUnitPaperwork = new InspectionCPOAuditSoldUnitPaperworkPage(driver);
        commentsForClientSection = new InspectionCommentsForClientPage(driver);
        completionSection = new InspectionCompletionPage(driver);
    }

    @Test
    public void login() throws InterruptedException {
        login.defaultLogin();
        home.verifyHomePageLoaded();
        home.tapAssignedTab();
        String vinNumber = VinDetailsReader.getVinValue("FINAL_AVL_CPO_INSPECTION_HYUNDAI_SOLDUNIT_YES");
        home.initiateInspectionUsingVinFromSearchBar(vinNumber);
        vehicleInfo.verifyVehicleInfoScreenLoaded();
        vehicleInfo.clickConfirmInfoButton();
        inspectionHome.verifyLandingOfInspectionScreen(vinNumber);
        extentTest.info("Inspection screen is loaded for VIN: " + vinNumber);
    }

    @Test(dependsOnMethods = {"login"})
    public void typeOfInspection() throws Exception {
        inspectionHome.tapTypeOfInspectionSection();
        typeOfInspectionSection.verifyTypeOfInspectionTitle();
        typeOfInspectionSection.verifyMandatoryTypeOfInspection("Yes");
        extentTest.info("Type of Inspection section verified successfully.");
    }

    @Test(dependsOnMethods = {"typeOfInspection"})
    public void marketingAndPaperWorkInspection() throws InterruptedException {
        inspectionHome.tapMarketingAndPaperworkSection();
        marketingAndPaperworkSection.verifyMarketingAndPaperworkTitle();
        marketingAndPaperworkSection.verifyMarketingAndPaperworkButtonOptionsHyundaiSoldUnitYES();
        marketingAndPaperworkSection.finalizeMarketingAndPaperworkSection();
        extentTest.info("Marketing and Paperwork section completed successfully.");
    }

    @Test(dependsOnMethods = {"marketingAndPaperWorkInspection"})
    public void vehicleGeneralEligibilityInspection() throws InterruptedException {
        vehicleGeneralEligibilitySection.verifyVehicleGeneralEligibilityTitle();
        vehicleGeneralEligibilitySection.verifyGeneralEligibilitySectionHyundai();
        vehicleGeneralEligibilitySection.finalizeVehicleGeneralEligibilitySection();
        extentTest.info("Vehicle General Eligibility section completed successfully.");
    }

    @Test(dependsOnMethods = {"vehicleGeneralEligibilityInspection"})
    public void imagesInspection() throws InterruptedException {
        imagesSection.verifyImagesTitle();
        imagesSection.verifyRequiredImagesHyundaiSoldUnitYES();
        imagesSection.finalizeImagesSection();
        extentTest.info("Images section completed successfully.");
    }

    @Test(dependsOnMethods = {"imagesInspection"})
    public void commentsForClientInspection() {
        commentsForClientSection.verifyCommentsForClientTitle();
        commentsForClientSection.verifyCommentInput();
        commentsForClientSection.finalizeCommentsForClientSection();
        extentTest.info("Comments for Client section completed successfully.");
    }

    @Test(dependsOnMethods = {"commentsForClientInspection"})
    public void completeInspection() throws InterruptedException {
        inspectionHome.tapCompleteInspectionButton();
        Map<String, String> details = completionSection.verifyInspectionCompletion();
        String totalTime = details.get("TotalTime");
        String totalInspection = details.get("TotalInspections");
        log.info("Total time taken for inspection: {}", totalTime);
        log.info("Total Inspections completed: {}", totalInspection);
        extentTest.info("Inspection completed successfully with total time: " + totalTime + " and total inspections: " + totalInspection);

    }
}
