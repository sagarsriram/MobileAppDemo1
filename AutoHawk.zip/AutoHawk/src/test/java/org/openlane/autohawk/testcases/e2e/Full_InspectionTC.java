package org.openlane.autohawk.testcases.e2e;

import org.openlane.autohawk.pageobject.*;
import org.openlane.autohawk.testutils.BaseTest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

import static org.openlane.autohawk.testutils.Listeners.extentTest;


public class Full_InspectionTC extends BaseTest {
    // This class is a placeholder for the full inspection test case.
    // It will contain methods to perform end-to-end testing of the application.
    // The actual implementation will depend on the specific requirements and flow of the application.

    LoginPage login;
    HomePage home;
    SiteSettingsPage siteSettings;
    VehicleInfoPage vehicleInfo;
    InspectionLandingPage inspectionHome;
    InspectionKickOffPage kickoffSection;
    InspectionFrontInteriorPage frontInteriorSection;
    InspectionRearInteriorPage rearInteriorSection;
    InspectionLeftExteriorPage leftExteriorSection;
    InspectionRearExteriorPage rearExteriorSection;
    InspectionRightExteriorPage rightExteriorSection;
    InspectionFrontExteriorPage frontExteriorSection;
    InspectionMechanicalPage mechanicalSection;
    InspectionOverallVehiclePage overallVehicleSection;
    InspectionCompletionPage completionSection;
    private static final Logger log = LoggerFactory.getLogger(Full_InspectionTC.class);

    @BeforeClass
    public void setupPages() {
        login = new LoginPage(driver);
        home = new HomePage(driver);
        siteSettings = new SiteSettingsPage(driver);
        vehicleInfo = new VehicleInfoPage(driver);
        inspectionHome = new InspectionLandingPage(driver);
        kickoffSection = new InspectionKickOffPage(driver);
        frontInteriorSection = new InspectionFrontInteriorPage(driver);
        rearInteriorSection = new InspectionRearInteriorPage(driver);
        leftExteriorSection = new InspectionLeftExteriorPage(driver);
        rearExteriorSection = new InspectionRearExteriorPage(driver);
        rightExteriorSection = new InspectionRightExteriorPage(driver);
        frontExteriorSection = new InspectionFrontExteriorPage(driver);
        mechanicalSection = new InspectionMechanicalPage(driver);
        overallVehicleSection = new InspectionOverallVehiclePage(driver);
        completionSection = new InspectionCompletionPage(driver);
    }

    @Test
    public void login() throws InterruptedException {
        //login to the app and launch home screen
        login.defaultLogin();
        home.verifyHomePageLoaded();
        home.verifyHomePageElementsDisplayedForOnSiteUser();
        String vinNumber = home.initiateInspectionFromSiteTab(); // change index to select inspection
        vehicleInfo.verifyVehicleInfoScreenLoaded();
        vehicleInfo.clickConfirmInfoButton();
        inspectionHome.verifyLandingOfInspectionScreen(vinNumber);
      //  extentTest.info("Inspection screen is loaded for VIN: " + vinNumber);
    }

    @Test(dependsOnMethods = {"login"})
    public void kickoffInspection() throws InterruptedException {
        inspectionHome.tapKickoffSection();
        kickoffSection.verifyKickOffScreenTitle();
        kickoffSection.verifyMandatoryInspectionDetailsVehicleTypeRadioButtons();
        kickoffSection.verifyMandatoryInspectionDetailsNumberOfDoorsOptions();
        kickoffSection.verifyMandatoryInspectionDetailsVehicleSourceTypeDropDown();
        kickoffSection.verifyMandatoryInspectionDetailsArrivalDateDropDown();
        kickoffSection.verifyMandatoryKickoffPhotosDashVINPlatePhoto();
        kickoffSection.verifyMandatoryKickoffPhotosLeftFrontThreeQuartersPhoto();
        kickoffSection.verifyMandatoryKickoffPhotosLeftFrontWheelTirePhoto();
        kickoffSection.verifyMandatoryKickoffPhotosUnderCarriageLeftPhoto();
        kickoffSection.verifyMandatoryKickoffPhotosFrontInteriorPhoto();
        kickoffSection.verifyMandatoryVINStickerVINStickerPhoto();
        kickoffSection.verifyMandatoryEngineDetailsEngineDetailsDropDown();
        kickoffSection.verifyMandatoryExteriorColorsPrimaryExteriorColorsDropDown();
        kickoffSection.finalizeKickOffSection();
    //    extentTest.info("Kickoff section is completed successfully");
    }

    @Test(dependsOnMethods = {"kickoffInspection"})
    public void frontInteriorInspection() throws InterruptedException {
        inspectionHome.tapFrontInteriorSection();
        frontInteriorSection.verifyFrontInteriorTitle();
        frontInteriorSection.verifyMandatoryOdorPresentButton();
        frontInteriorSection.verifyMandatoryInteriorColorDropDown();
        frontInteriorSection.verifyMandatoryKeysSection();
        frontInteriorSection.verifyMandatoryKeysFobsManualPhoto();
        frontInteriorSection.verifyMandatoryDrivableDropDown();
        frontInteriorSection.verifyMandatoryOdometerInfo();
        frontInteriorSection.verifyMandatoryFuelRadioButton();
        frontInteriorSection.verifyMandatoryOBD2CodesSkip();
        frontInteriorSection.verifyMandatoryDriverControls();
        frontInteriorSection.verifyMandatoryHeating();
        frontInteriorSection.verifyMandatorySoundSystem();
        frontInteriorSection.verifyMandatorySafetyOptions();
        frontInteriorSection.verifyMandatorySeating();
        frontInteriorSection.finaliseFrontInteriorSection();
     //   extentTest.info("Front interior inspection is completed successfully");
    }

    @Test(dependsOnMethods = {"frontInteriorInspection"})
    public void rearInteriorInspection() throws InterruptedException {
        //RearInterior - done
        inspectionHome.tapRearInteriorSection();
        rearInteriorSection.verifyRearInteriorTitle();
        rearInteriorSection.verifyMandatoryInteriorPhoto();
        rearInteriorSection.finalizeRearInteriorInspection();
        extentTest.info("Rear interior inspection is completed successfully");
    }

    @Test(dependsOnMethods = {"rearInteriorInspection"})
    public void leftExteriorInspection() throws InterruptedException {
        //LeftExterior Inspection - done
        inspectionHome.tapLeftExteriorSection();
        leftExteriorSection.verifyLeftExteriorScreenTitle();
        leftExteriorSection.addDamageLFTireWheel();
        leftExteriorSection.verifyMandatoryLFTireOrWheelsDropdowns();
        leftExteriorSection.verifyMandatoryLRTireOrWheelDropDowns();
        leftExteriorSection.verifyMandatoryLeftRearThreeQuartersPhoto();
        leftExteriorSection.finalizeLeftExteriorSection();
        extentTest.info("Left exterior inspection is completed successfully");
    }

    @Test(dependsOnMethods = {"leftExteriorInspection"})
    public void rearExteriorInspection() throws InterruptedException {
        //RearExterior Inspection - done partial check pending
        inspectionHome.tapRearExteriorSection();
        rearExteriorSection.verifyRearExteriorTitle();
        rearExteriorSection.verifyMandatoryCargoAreaSection();
        rearExteriorSection.verifyMandatorySpareTireSection();
        rearExteriorSection.verifyMandatoryUnderCarriagePhotoSection();
        rearExteriorSection.finalizeRearExteriorInspection();
        extentTest.info("Rear exterior inspection is completed successfully");
    }

    @Test(dependsOnMethods = {"rearExteriorInspection"})
    public void rightExteriorInspection() throws InterruptedException {
        //RightExterior Inspection
//        inspectionHome.tapRightExteriorSection();
        rightExteriorSection.verifyRightExteriorTitle();
        rightExteriorSection.verifyMandatoryRightRearThreeQuartersPhoto();
        rightExteriorSection.verifyMandatoryRRTireOrWheelDropDown();
        rightExteriorSection.verifyMandatoryUnderCarriageRightPhoto();
        rightExteriorSection.verifyMandatoryRFTireOrWheelDropDown();
        rightExteriorSection.finalizeRightExteriorSection();
        extentTest.info("Right exterior inspection is completed successfully");
    }

    @Test(dependsOnMethods = {"rightExteriorInspection"})
    public void frontExteriorInspection() throws InterruptedException {
        //FrontExterior Inspection -done
//        inspectionHome.tapFrontExteriorSection();
        frontExteriorSection.verifyFrontExteriorTitle();
        frontExteriorSection.verifyMandatoryRoofSection();
        frontExteriorSection.verifyMandatoryUnderCarriagePhotoFrontSection();
        frontExteriorSection.finalizeFrontExteriorInspection();
        extentTest.info("Front exterior inspection is completed successfully");
    }

    @Test(dependsOnMethods = {"frontExteriorInspection"})
    public void mechanicalInspection() throws InterruptedException {
        //Mechanical Inspection - done
//        inspectionHome.tapMechanicalSection();
        mechanicalSection.verifyMechanicalSectionTitle();
        mechanicalSection.verifyMandatoryEmissionStickerSection();
        mechanicalSection.verifyMandatoryEngineSection();
        mechanicalSection.verifyMandatoryDrivetrainSection();
        mechanicalSection.finalizeMechanicalInspection();
        extentTest.info("Mechanical inspection is completed successfully");
    }

    @Test(dependsOnMethods = {"mechanicalInspection"})
    public void overallVehicleInspection() throws InterruptedException {
        //Overall Vehicle Inspection
//        inspectionHome.tapOverallVehicleSection();
        overallVehicleSection.verifyOverallVehicleSectionTitle();
        overallVehicleSection.verifyMandatoryRightFrontThreeQuartersPhoto();
        overallVehicleSection.verifyMandatoryVehicleAdminVehicleGrade();
        overallVehicleSection.finalizeOverallInspection();
        extentTest.info("Overall vehicle inspection is completed successfully");
    }

    @Test(dependsOnMethods = {"overallVehicleInspection"})
    public void completeInspection() throws InterruptedException {
        //complete Inspection
        inspectionHome.tapCompleteInspectionButton();
        Map<String, String> details = completionSection.verifyInspectionCompletion();
        String totalTime = details.get("TotalTime");
        String totalInspection = details.get("TotalInspections");
        log.info("Total time taken for inspection: {}", totalTime);
        log.info("Total Inspections completed: {}", totalInspection);
        extentTest.info("Inspection completed successfully with total time: " + totalTime + " and total inspections: " + totalInspection);

    }

}
