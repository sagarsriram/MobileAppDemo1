package org.openlane.autohawk.testutils;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.options.XCUITestOptions;
import org.openlane.autohawk.utils.AppiumGeneric;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.*;
import io.appium.java_client.service.local.AppiumDriverLocalService;

import java.io.IOException;
import java.net.URL;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

public class BaseTest extends AppiumGeneric {
    private static final Logger log = LoggerFactory.getLogger(BaseTest.class);
    public AppiumDriver driver;
    public AppiumDriverLocalService service;
    public static final String JSON_FILE_PATH = System.getProperty("user.dir") + "/src/test/java/org/openlane/autohawk/testData/eCommerce.json";

    /*
    This method is executed before any test case in the class
    It sets up the Appium driver and starts the Appium server
    The driver is set to implicit wait for all elements
    The driver instance is stored in a class variable for use in test cases
    */
    @BeforeClass
    public void setUp() throws IOException {
        /*
        Sets up the test environment before any tests are executed.
        1. Determines the platform (Android or iOS) from either:
             - System property passed via command line (e.g. -DplatformName=Android)
             - Or fallback to the value from data.properties
        2. Resolves Appium server IP and port (system property > config file).
        3. Starts the Appium server with the resolved IP and port.
        5. Initializes the appropriate Appium driver (Android or iOS) based on the platform
         */
        String platformName = System.getProperty("platformName");
        if (platformName == null || platformName.isEmpty()) {
            platformName = AppiumGeneric.getProperty("platform");
            log.info("No platformName provided via system property, using config file value: {}", platformName);
        }
        if (platformName == null || platformName.isEmpty()) {
            log.error("No platformName provided via system property or config file!");
            throw new IllegalArgumentException("No Platform provided via system property or config file!");
        }

        String ipAddress = System.getProperty("ipAddress") != null ? System.getProperty("ipAddress") : AppiumGeneric.getProperty("ipAddress");
        String port = AppiumGeneric.getProperty("port");

        //To start APPIUM server
        //service = startAppiumServer(ipAddress, Integer.parseInt(port));

        if (platformName.equalsIgnoreCase("Android") || platformName.equalsIgnoreCase("BrowserStackAndroid")) {
            if (platformName.equalsIgnoreCase("BrowserStackAndroid")) {
                driver = new AndroidDriver(new URL("http://hub-cloud.browserstack.com/wd/hub"), getAndroidOptions());
                log.info("Started with BrowserStack AndroidServer");
            } else {
                service = startAppiumServer(ipAddress, Integer.parseInt(port));
                driver = new AndroidDriver(new URL(service.getUrl().toString()), getAndroidOptions());
                log.info("Started with local Android Appium server at: {}", service.getUrl());
            }
        } else if (platformName.equalsIgnoreCase("iOS") || platformName.equalsIgnoreCase("BrowserStackiOS")) {
            if (platformName.equalsIgnoreCase("BrowserStackiOS")) {
                driver = new IOSDriver(new URL("http://hub-cloud.browserstack.com/wd/hub"), getIOSOptions());
                log.info("Started with BrowserStack iOS Server");
            } else {
                service = startAppiumServer(ipAddress, Integer.parseInt(port));
                driver = new IOSDriver(new URL("http://hud-cloud.browserstack.com"), getIOSOptions());
                log.info("Started with local iOS Appium server at: {}", service.getUrl());
            }

        } else {
            throw new IllegalArgumentException("Unsupported platform: " + platformName);
        }

        // Set Implicit wait for all elements and setting driver for Appium generic methods
        setDriver(driver);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        log.info("waits initialized with implicit wait of 6 seconds");

         /*
         Adding Device details to Extent Report's system info
        This must be done *after* driver is initialized to avoid NullPointerException.
        It uses the driver capabilities to fetch platformName (e.g., Android/iOS) dynamically.
        The ExtentManager holds the shared ExtentReports instance created during extentTest start.
         */
//        ExtentReporterNG.getExtent().setSystemInfo("Platform Name", driver.getCapabilities().getCapability("platformName").toString());
//        ExtentReporterNG.getExtent().setSystemInfo("Platform Version", driver.getCapabilities().getCapability("platformVersion").toString());
//        ExtentReporterNG.getExtent().setSystemInfo("Automation Name", driver.getCapabilities().getCapability("automationName").toString());
//        ExtentReporterNG.getExtent().setSystemInfo("Device Name", driver.getCapabilities().getCapability("deviceName").toString());
//        ExtentReporterNG.getExtent().setSystemInfo("App Package", driver.getCapabilities().getCapability("appPackage").toString() != null ? AppiumGeneric.getProperty("UAT_ANDROID_APP_PACKAGE") : AppiumGeneric.getProperty("UAT_IOS_APP_BUNDLE_ID"));

    }

    //To exit driver and stop APPIUM server
    @AfterClass
    public void tearDown() {
        String platformName = "BrowserStack";
        String browserStackUser = AppiumGeneric.getProperty("platform");
        if (browserStackUser.contains(platformName)) {
            log.info("BrowserStack tests do not require driver.quit() or service.stop() as they are managed by BrowserStack.");
            return;
        }
        driver.quit();
        service.stop();
        log.info("Driver quit and Appium server stopped successfully.");
    }

    private UiAutomator2Options getAndroidOptions() {
        UiAutomator2Options options = new UiAutomator2Options();
        options.setDeviceName("emulator-5554");
        options.setAppPackage(AppiumGeneric.getProperty("UAT_ANDROID_APP_PACKAGE"));
        options.setAppActivity(AppiumGeneric.getProperty("ANDROID_APP_ACTIVITY"));
        options.autoGrantPermissions();
        options.setAutoWebview(false);
        //when provided with apk
        //options.setApp(System.getProperty("user.dir") + "/src/Test/java/org/openlane/autohawk/resources/app-uat-intune2.apk");
        return options;
    }

    private XCUITestOptions getIOSOptions() throws IOException {
        XCUITestOptions options = new XCUITestOptions();
        options.setDeviceName("iPhone 16 Pro");
        options.setApp("/Users/sagars/Documents/***.app");
        options.setPlatformVersion("18.3");
        options.setBundleId("com.example.apple-samplecode.UICatalog");
        options.setWdaLaunchTimeout(Duration.ofSeconds(20));
        return options;
    }

}

