package org.openlane.autohawk.testcases.e2e;

import org.openlane.autohawk.pageobject.*;
import org.openlane.autohawk.testutils.BaseTest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

import static org.openlane.autohawk.testutils.Listeners.extentTest;


public class AVL_CPO_SoldUnit_Yes extends BaseTest {
    // This class is a placeholder for the full inspection test case.
    // It will contain methods to perform end-to-end testing of the application.
    // The actual implementation will depend on the specific requirements and flow of the application.

    LoginPage login;
    HomePage home;
    SiteSettingsPage siteSettings;
    VehicleInfoPage vehicleInfo;
    InspectionLandingPage inspectionHome;
    InspectionTypeOfInspectionPage typeOfInspectionSection;
    InspectionImagesPage imagesSection;
    InspectionCPOAuditSoldUnitPaperworkPage cpoAuditSoldUnitPaperwork;
    InspectionCommentsForClientPage commentsForClientSection;
    InspectionCompletionPage completionSection;

    private static final Logger log = LoggerFactory.getLogger(AVL_CPO_SoldUnit_Yes.class);

    @BeforeClass
    public void setupPages() {
        login = new LoginPage(driver);
        home = new HomePage(driver);
        siteSettings = new SiteSettingsPage(driver);
        vehicleInfo = new VehicleInfoPage(driver);
        inspectionHome = new InspectionLandingPage(driver);
        typeOfInspectionSection = new InspectionTypeOfInspectionPage(driver);
        cpoAuditSoldUnitPaperwork = new InspectionCPOAuditSoldUnitPaperworkPage(driver);
        imagesSection = new InspectionImagesPage(driver);
        commentsForClientSection = new InspectionCommentsForClientPage(driver);
        completionSection = new InspectionCompletionPage(driver);
    }

    @Test
    public void login() throws InterruptedException {
        //login to the app and launch home screen
        login.defaultLogin();
        home.verifyHomePageLoaded();
        home.tapAssignedTab();
        String vinNumber = home.initiateAndVerifyInspectionThroughVinValidationUsingInputFromAssignedTab();
//        home.verifyHomePageElementsDisplayedForOnSiteUser();
//        String vinNumber = home.initiateInspectionFromSiteTab(); // change index to select inspection
        vehicleInfo.verifyVehicleInfoScreenLoaded();
        vehicleInfo.clickConfirmInfoButton();
        inspectionHome.verifyLandingOfInspectionScreen(vinNumber);
        //extentTest.info("Inspection screen is loaded for VIN: " + vinNumber);
    }

    @Test(dependsOnMethods = {"login"})
    public void typeOfInspection() throws Exception {
        inspectionHome.tapTypeOfInspectionSection();
        typeOfInspectionSection.verifyTypeOfInspectionTitle();
        typeOfInspectionSection.verifyMandatoryTypeOfInspection("Yes");
    }

    @Test(dependsOnMethods = {"typeOfInspection"})
    public void cpoAuditSoldUnitPaperworkInspection() throws InterruptedException {
        inspectionHome.tapCPOAuditSection();
        cpoAuditSoldUnitPaperwork.verifyCPOAuditSoldUnitPaperWorkTitle();
        cpoAuditSoldUnitPaperwork.verifyCPOAuditMandatoryButtonOptions();
        cpoAuditSoldUnitPaperwork.finalizeCPOAuditSoldUnitPaperworkSection();
        //   extentTest.info("CPO Audit - Sold Unit Paperwork section completed successfully.");
    }

    @Test(dependsOnMethods = {"cpoAuditSoldUnitPaperworkInspection"})
    public void ImagesInspection() throws InterruptedException {
        imagesSection.verifyImagesTitle();
        imagesSection.finalizeImagesSection();
    }

    @Test(dependsOnMethods = {"ImagesInspection"})
    public void commentsForClientInspection() {
        commentsForClientSection.verifyCommentsForClientTitle();
        commentsForClientSection.verifyCommentInput();
        commentsForClientSection.finalizeCommentsForClientSection();
    }

    @Test(dependsOnMethods = {"commentsForClientInspection"})
    public void completeInspection() throws InterruptedException {
        //complete Inspection
        inspectionHome.tapCompleteInspectionButton();
        Map<String, String> details = completionSection.verifyInspectionCompletion();
        String totalTime = details.get("TotalTime");
        String totalInspection = details.get("TotalInspections");
        log.info("Total time taken for inspection: {}", totalTime);
        log.info("Total Inspections completed: {}", totalInspection);
        extentTest.info("Inspection completed successfully with total time: " + totalTime + " and total inspections: " + totalInspection);

    }
}
