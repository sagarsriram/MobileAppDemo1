package org.openlane.autohawk.testcases.functional;

import org.openlane.autohawk.pageobject.HomePage;
import org.openlane.autohawk.pageobject.LoginPage;
import org.openlane.autohawk.testutils.BaseTest;
import org.openlane.autohawk.utils.AppiumGeneric;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class HomeTC extends BaseTest {
    LoginPage login;
    HomePage home;

    @BeforeClass
    public void setupPages() {
        login = new LoginPage(driver);
        home = new HomePage(driver);
    }

    @Test(priority = 1)
    public void validateHomeScreen_AfterLogin() {
        login.verifyLoginScreenLoadedAfterLoginButton();
        login.enterCredentials(AppiumGeneric.getProperty("username"), AppiumGeneric.getProperty("password"));
        login.clickSignIn();
        home.verifyHomePageLoaded();
    }

    @Test(priority = 2)
    public void verifyHomePageForOffsiteUser() {
        home.verifyHomePageElementsDisplayedForOffSiteUser();
        home.verifyOnsiteTabNotPresent();
    }

    @Test(priority = 3)
    public void verifyHomePageForOnsiteUser() {
        home.verifyHomePageElementsDisplayedForOnSiteUser();
    }

}
