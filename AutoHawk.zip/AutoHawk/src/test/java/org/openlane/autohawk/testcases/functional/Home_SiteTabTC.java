package org.openlane.autohawk.testcases.functional;

import org.openlane.autohawk.pageobject.HomePage;
import org.openlane.autohawk.pageobject.LoginPage;
import org.openlane.autohawk.pageobject.SiteSettingsPage;
import org.openlane.autohawk.pageobject.VehicleInfoPage;
import org.openlane.autohawk.testutils.BaseTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.openlane.autohawk.testutils.Listeners.extentTest;

public class Home_SiteTabTC extends BaseTest {
    LoginPage login;
    HomePage home;
    SiteSettingsPage site;
    VehicleInfoPage vehicleInfo;

    @BeforeClass
    public void setupPages(){
        login = new LoginPage(driver);
        home = new HomePage(driver);
        site = new SiteSettingsPage(driver);
        vehicleInfo = new VehicleInfoPage(driver);
    }

    @Test(priority = 1)
    public void login(){
        login.defaultLogin();
        home.verifyHomePageLoaded();
        extentTest.info("Home page is loaded");
    }

    @Test(priority = 2)
    public void verifySiteTabForOnSiteUser() {
        home.verifyHomePageElementsDisplayedForOnSiteUser();
        extentTest.info("Onsite user is able to see the site tab");
    }

    @Test(priority = 3)
    public void verifyCancelButtonForRetrievingInspection()  {
       home.selectInspectionByIndex("1");
       home.cancelInspection();
       extentTest.info("Inspection cancel is verified");
    }

    @Test(priority = 4)
    public void verifyVehicleInfoAfterRetrievingInspectionDetails() throws InterruptedException {
        home.selectInspectionByIndex("1");
        home.resumeInspection();
        vehicleInfo.verifyVehicleInfoScreenLoaded();
        vehicleInfo.clickConfirmInfoButton();
    }

    @Test(priority = 5)
    public void validateFilterOptions() throws InterruptedException {
        home.verifyHomePageElementsDisplayedForOnSiteUser();
        home.tapSiteTab();
        home.selectClearReselectApplyFilters();
        extentTest.info("Filter options are verified");
    }

    @Test(priority = 6)
    public void validateInspectionThroughSearchBar() throws InterruptedException {
        home.verifyHomePageElementsDisplayedForOnSiteUser();
        home.inspectionUsingSearchBar("2004");
        home.resumeInspection();
        vehicleInfo.clickConfirmInfoButton();
        extentTest.info("Inspection is verified through search bar");
    }
}
