package org.openlane.autohawk.pageobject;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.*;
import org.openlane.autohawk.utils.AndroidActions;
import org.openlane.autohawk.utils.AppiumGeneric;
import org.openlane.autohawk.utils.ApplicationGeneric;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;

@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSXCUITAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
public class InspectionRightExteriorPage {
    AppiumDriver driver;
    AppiumGeneric generic;
    AndroidActions actions;
    ApplicationGeneric appGeneric;
    private static final Logger log = LoggerFactory.getLogger(InspectionRightExteriorPage.class);

    public InspectionRightExteriorPage(AppiumDriver driver) {
        this.driver = driver;
        this.generic = new AppiumGeneric();
        this.generic.setDriver(driver);
        this.actions = new AndroidActions(driver);
        this.appGeneric = new ApplicationGeneric(driver);

        PageFactory.initElements(new AppiumFieldDecorator(driver, Duration.ofSeconds(10)), this);
    }

    //Defining locators


    @AndroidFindBy(id = "com.openlane.autohawk.uat:id/tv_title_extra_photo")
    @iOSXCUITFindBy(id = "")
    private WebElement rightExteriorTitle;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Tire Brand*\")")
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryTireBrandDropdown;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Tire Width*\")")
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryTireWidthDropdown;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Aspect Ratio*\")")
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryAspectRatioDropdown;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Wheel Diameter*\")")
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryWheelDiameterDropdown;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Speed Rating*\")")
    @iOSXCUITFindBy(id = "")
    private WebElement mandatorySpeedRatingDropdown;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Tread Depth*\")")
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryTreadDepthDropdown;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/iv_back"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/iv_back")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement appBackButton;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/btn_next_section"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/btn_next_section")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement frontExteriorButton;

    @AndroidFindBy(xpath = "//android.widget.TextView[contains (@text, \"RF Fender\")]/following-sibling::android.widget.ImageView")
    @iOSXCUITFindBy(id = "")
    private WebElement RFFenderDamageButton;


    //Defining actions

    public void verifyRightExteriorTitle() {
        String expectedTitle = "Right Exterior";
        String actualTitle = rightExteriorTitle.getText();
        Assert.assertEquals(actualTitle, expectedTitle, "Title does not match");
        log.info("Section Title verified successfully: {}", actualTitle);
    }

    public void verifyMandatoryRightRearThreeQuartersPhoto() {
        appGeneric.handlePhotoSelection("Right Rear 3/4 Photo");
    }

    public void handleDropDownSelection(String dropdownText, String selectionText, WebElement sectionTitleName) {
        try {
            // Locate and validate the dropdown
            WebElement dropDownValidation = driver.findElement(By.xpath("//android.widget.TextView[@resource-id=\"com.openlane.autohawk.uat:id/titleText\" and @text=\"" + dropdownText + "\"]/following-sibling::android.widget.TextView[@resource-id=\"com.openlane.autohawk.uat:id/selectionText\"]"));
            if (generic.isElementVisible(dropDownValidation)) {
                log.info("{} already selected: {}", dropdownText, dropDownValidation.getText());
                return;
            }
        } catch (Exception e) {
            log.info("Dropdown validation processing for : {}", dropdownText);
        }

        try {
            // Check and interact with the mandatory dropdown
            if (dropdownText.equals(sectionTitleName.getText())) {
                generic.waitForVisibility(sectionTitleName).click();
                WebElement dropDownPicker = driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().text(\"" + selectionText + "\")"));
                if (dropDownPicker.isDisplayed()) {
                    dropDownPicker.click();
                    By titleLocator = AppiumBy.id("com.openlane.autohawk.uat:id/tv_title");
                    try {
                        WebElement title = driver.findElement(titleLocator);
                        if (!title.getText().equals(dropdownText.substring(0, dropdownText.length() - 1))) {
                            log.info("going back");
                            appBackButton.click();
                        } else {
                            log.info("continuing... dropdown selection");
                        }
                    } catch (Exception e) {
                        log.info("Title not found, continuing with dropdown selection");
                    }
                    log.info("Selected {} type: {}", dropdownText, dropDownPicker.getText());
                } else {
                    log.warn("Selected {} option not found", dropdownText);
                    throw new IllegalStateException("Vehicle source type option not found");
                }
            }
        } catch (NoSuchElementException e) {
            log.error("Dropdown or {} option not found", dropdownText, e);
            throw e;
        } catch (Exception e) {
            log.error("Unexpected error while interacting with the {} dropdown", dropdownText, e);
            throw e;
        }
    }

    public void verifyMandatoryRRTireOrWheelDropDown() {
        By subTitleLocator = By.xpath("//android.widget.TextView[contains(@text, 'RR Tire/Wheel*')]");
        actions.swipeUntilVisibleAndCenter(subTitleLocator);
        actions.scrollElementToCenter(mandatoryTireBrandDropdown);
        handleDropDownSelection("Tire Brand*", "Continental", mandatoryTireBrandDropdown);
        actions.scrollElementToCenter(mandatoryTireWidthDropdown);
        handleDropDownSelection("Tire Width*", "235", mandatoryTireWidthDropdown);
        actions.scrollElementToCenter(mandatoryAspectRatioDropdown);
        handleDropDownSelection("Aspect Ratio*", "55", mandatoryAspectRatioDropdown);
        actions.scrollElementToCenter(mandatoryWheelDiameterDropdown);
        handleDropDownSelection("Wheel Diameter*", "18\\\"", mandatoryWheelDiameterDropdown);
        actions.scrollElementToCenter(mandatorySpeedRatingDropdown);
        handleDropDownSelection("Speed Rating*", "H", mandatorySpeedRatingDropdown);
        actions.scrollElementToCenter(mandatoryTreadDepthDropdown);
        handleDropDownSelection("Tread Depth*", "6/32\\\"", mandatoryTreadDepthDropdown);

    }

    public void verifyMandatoryUnderCarriageRightPhoto() {
        By subTitleLocator = By.xpath("//android.widget.TextView[contains(@text, 'Undercarriage Photo - Right*')]");
        actions.swipeUntilVisibleAndCenter(subTitleLocator);
        appGeneric.handlePhotoSelection("Undercarriage - Right Photo");
    }

    public void verifyMandatoryRFTireOrWheelDropDown() {
        By subTitleLocator = By.xpath("//android.widget.TextView[contains(@text, 'RF Tire/Wheel*')]");
        actions.swipeUntilVisibleAndCenter(subTitleLocator);
        actions.scrollElementToCenter(mandatoryTireBrandDropdown);
        handleDropDownSelection("Tire Brand*", "Continental", mandatoryTireBrandDropdown);
        actions.scrollElementToCenter(mandatoryTireWidthDropdown);
        handleDropDownSelection("Tire Width*", "235", mandatoryTireWidthDropdown);
        actions.scrollElementToCenter(mandatoryAspectRatioDropdown);
        handleDropDownSelection("Aspect Ratio*", "55", mandatoryAspectRatioDropdown);
        actions.scrollElementToCenter(mandatoryWheelDiameterDropdown);
        handleDropDownSelection("Wheel Diameter*", "18\\\"", mandatoryWheelDiameterDropdown);
        actions.scrollElementToCenter(mandatorySpeedRatingDropdown);
        handleDropDownSelection("Speed Rating*", "H", mandatorySpeedRatingDropdown);
        actions.scrollElementToCenter(mandatoryTreadDepthDropdown);
        handleDropDownSelection("Tread Depth*", "6/32\\\"", mandatoryTreadDepthDropdown);

    }

    public void verifyMandatoryRightExteriorPhotoSection() {
        List<String> items = Arrays.asList(
                "Right Side Photo",
                "Motor - Right (Brake Side)"
        );

        for (String item : items) {
            appGeneric.swipeToCenter(item);
            appGeneric.handlePhotoSelection(item);
        }
    }

    public void finalizeRightExteriorSection() throws InterruptedException {
        actions.swipeUntilEnd("up");
        //adding damage
        generic.waitForVisibility(RFFenderDamageButton).click();
        log.info("Adding damage for RF Fender section");
        appGeneric.addDamage();

        actions.swipeUntilEnd("up");
        generic.waitForVisibility(frontExteriorButton).click();
        log.info("completed all mandatory sections of Right Exterior section");
    }
}
