package org.openlane.autohawk.pageobject;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.*;
import org.openlane.autohawk.utils.AndroidActions;
import org.openlane.autohawk.utils.AppiumGeneric;
import org.openlane.autohawk.utils.ApplicationGeneric;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;

@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSXCUITAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
public class InspectionInternetPage {
    AppiumDriver driver;
    AppiumGeneric generic;
    AndroidActions actions;
    ApplicationGeneric appGeneric;
    private static final Logger log = LoggerFactory.getLogger(InspectionInternetPage.class);

    public InspectionInternetPage(AppiumDriver driver) {
        this.driver = driver;
        this.generic = new AppiumGeneric();
        this.generic.setDriver(driver);
        this.actions = new AndroidActions(driver);
        this.appGeneric = new ApplicationGeneric(driver);
        PageFactory.initElements(new AppiumFieldDecorator(driver, Duration.ofSeconds(10)), this);
    }

    //Defining locators

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/tv_title_extra_photo"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/tv_title_extra_photo")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement exteriorAppearanceTitle;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/btn_next_section"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/btn_next_section")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement imagesButton;

    public void verifyInternetTitle() {
        String expectedTitle1 = "Internet ";
        String expectedTitle2 = "Internet";
        String actualTitle = exteriorAppearanceTitle.getText();
        Assert.assertTrue(
                actualTitle.equals(expectedTitle1) || actualTitle.equals(expectedTitle2),
                "Internet title is not matching"
        );
        log.info("Internet title is verified successfully: " + actualTitle);
    }

    // details are same for Toyota cpo and Gulf cpo
    public void verifyInternetButtonOptionsGulfState() {
        List<String> items = Arrays.asList(
                "The vehicle is listed on toyotacertified.com*",
                "Does the vehicle match the listing on toyotacertified.com?*",
                "Do the photos of the unit match the vehicle on toyotacertified.com?*"
        );
        for (String item : items) {
            appGeneric.swipeToCenter(item);
            appGeneric.handleButtonSelection(item, null);
        }

        //input text box in between the buttons
        String textboxTitle = "How many photos are listed in the gallery on toyotacertified.com?*";
        By nextButtonLocator = AppiumBy.xpath("//android.widget.EditText[@text = 'How many photos are listed in the gallery on toyotacertified.com?*']");
        appGeneric.swipeToCenter(textboxTitle);
        WebElement textbox = driver.findElement(nextButtonLocator);
        textbox.sendKeys("10");

        List<String> items2 = Arrays.asList(
                "The photos of the vehicle are of high quality and are taken in a designated area*",
                "The unit has a CarFax Report available on toyotcertified.com*"
        );
        for (String item : items2) {
            appGeneric.swipeToCenter(item);
            appGeneric.handleButtonSelection(item, null);
        }

    }

    public void verifyInternetButtonOptionsHyundai() {
        List<String> items = Arrays.asList(
                "Does the vehicle match the listing on the dealer website*",
                "Do the photos of the unit on the dealer website match the vehicle (ex. not stock photos/a brochure)*"
        );
        for (String item : items) {
            appGeneric.swipeToCenter(item);
            appGeneric.handleButtonSelection(item, null);
        }

        //input text box in between the buttons
        String textboxTitle = "How many photos are listed in the gallery on the dealer website?*";
        By nextButtonLocator = AppiumBy.xpath("//android.widget.EditText[@text = 'How many photos are listed in the gallery on the dealer website?*']");
        appGeneric.swipeToCenter(textboxTitle);
        WebElement textbox = driver.findElement(nextButtonLocator);
        textbox.sendKeys("10");

        List<String> items2 = Arrays.asList(
                "The photos of the vehicle are of high quality*",
                "Does the pricing on the unit match the pricing on the dealer website?*"
        );
        for (String item : items2) {
            appGeneric.swipeToCenter(item);
            appGeneric.handleButtonSelection(item, null);
        }


    }


    public void finalizeInternetSection() throws InterruptedException {
        actions.swipeUntilEnd("up");
        generic.waitForVisibility(imagesButton).click();
        log.info("Completed all sections of Internet.");
    }

}
