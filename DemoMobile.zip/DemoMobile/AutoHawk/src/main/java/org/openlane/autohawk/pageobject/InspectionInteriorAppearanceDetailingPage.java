package org.openlane.autohawk.pageobject;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.*;
import org.openlane.autohawk.utils.AndroidActions;
import org.openlane.autohawk.utils.AppiumGeneric;
import org.openlane.autohawk.utils.ApplicationGeneric;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;

@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSXCUITAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
public class InspectionInteriorAppearanceDetailingPage {
    AppiumDriver driver;
    AppiumGeneric generic;
    AndroidActions actions;
    ApplicationGeneric appGeneric;
    private static final Logger log = LoggerFactory.getLogger(InspectionInteriorAppearanceDetailingPage.class);

    public InspectionInteriorAppearanceDetailingPage(AppiumDriver driver) {
        this.driver = driver;
        this.generic = new AppiumGeneric();
        this.generic.setDriver(driver);
        this.actions = new AndroidActions(driver);
        this.appGeneric = new ApplicationGeneric(driver);
        PageFactory.initElements(new AppiumFieldDecorator(driver, Duration.ofSeconds(10)), this);
    }

    //Defining locators
    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/tv_title_extra_photo"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/tv_title_extra_photo")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement interiorAppearanceTitle;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/btn_next_section"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/btn_next_section")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement exteriorAppearanceButton;

    public void verifyInteriorAppearanceDetailingTitle() {
        String expectedTitle1 = "Interior Appearance / Detailing";
        String expectedTitle2 = "Interior";
        String expectedTitle3 = "Interior Appearance/Detailing";
        String actualTitle = interiorAppearanceTitle.getText();
        Assert.assertTrue(
                actualTitle.equals(expectedTitle1) || actualTitle.equals(expectedTitle2) || actualTitle.equals(expectedTitle3),
                "Interior Appearance/Detailing title is not matching"
        );
        log.info("Interior Appearance/Detailing title is verified successfully: {}", actualTitle);
    }

    public void verifyInteriorAppearanceDetailingButtonOptionsToyota() {
        List<String> items = Arrays.asList(
                "Dash, instrument lens, interior crevices and vents are not clean*",
                "Dash, instruments lens, interior crevices and vents have excessive dressing*",
                "Dashboard has noticeable rips, tears, fading or damage*",
                "Door jambs and gaskets are dirty*",
                "Door gaskets are missing, ripped and/or damaged*",
                "Headline has burn holes, excessive stains and/or damage*",
                "Visor mirrors are cracked, damaged and/or dirty*",
                "Visors are dirty*",
                "Visors have burn holes, excessive stains or damage*",
                "Glove box and console areas do not work properly*",
                "Glove box and console areas are not clean*",
                "Shifter area, boot, and crevices are not clean or dressed*",
                "Cup holders are broken, missing*",
                "Cup holders are dirty*",
                "Ashtrays and lighter are missing*",
                "Ashtrays and lighter are dirty and show signs of use*",
                "Ashtrays and lighter do not function properly*",
                "Vehicle must not have a detectable odor or perfume*",
                "Interior is dirty*",
                "Interior has excessive dressing*",
                "Interior has burn holes, excessive stains or damage*",
                "Spare tire is present and full of air*",
                "Trunk and compartments have debris, stains and/or tears*",
                "Spare tire and storage area not clean*",
                "All tools are not present and/or tightened down*"
        );

        for (String item : items) {
            appGeneric.swipeToCenter(item);
            String details = appGeneric.handleButtonSelection(item, null);
            log.info("For the question : {} selected option: {}", item, details);
        }
    }

    public void verifyInteriorAppearanceDetailingButtonOptionsLexus() {
        List<String> items = Arrays.asList(
                "Dash, instrument lens, interior crevices and vents are not clean*",
                "Dash, instruments lens, interior crevices and vents have excessive dressing*",
                "Dashboard has noticeable rips, tears, fading or damage*",
                "Door jambs and gaskets are dirty*",
                "Door gaskets are missing, ripped and/or damaged*",
                "Headline has burn holes, excessive stains and/or damage*",
                "Visor mirrors are cracked, damaged and/or dirty*",
                "Visors are dirty*",
                "Visors have burn holes, excessive stains or damage*",
                "Glove box and console areas do not work properly*",
                "Glove box and console areas are not clean*",
                "Shifter area, boot, and crevices are not clean or dressed*",
                "Cup holders are broken, missing*",
                "Cup holders are dirty*",
                "Ashtrays and lighter are missing*",
                "Ashtrays and lighter are dirty and show signs of use*",
                "Ashtrays and lighter do not function properly*",
                "Vehicle must not have a detectable odor or perfume*",
                "Interior is dirty*",
                "Interior has excessive dressing*",
                "Interior has burn holes, excessive stains or damage*",
                "Fuel door release does not work properly*",//delete
                "Trunk release functions properly*", //delete
                "Spare tire is present and full of air*",
                "Trunk and compartments have debris, stains and/or tears*",
                "Spare tire and storage area not clean*",
                "All tools are not present and/or tightened down*"

        );

        for (String item : items) {
            appGeneric.swipeToCenter(item);
            String details = appGeneric.handleButtonSelection(item, null);
            log.info("For the question : {} selected option: {}", item, details);
        }
    }

    public void verifyInteriorButtonOptionsHyundai() {
        List<String> items = Arrays.asList(
                "Minimum of two keys are present*",
                "Door handles operate properly*",
                "Power door lock (including child safety) function properly*",
                "Interior lighting functions properly*",
                "Clock functions properly and is set to correct time*",
                "Hazard light and switch function properly*",
                "Dashboard & interior trim free from noticeable rips, tears, fading or damage*",
                "Door jambs and gaskets are dirty*",
                "Door gaskets are missing, ripped and/or damaged*",
                "Headline has burn holes, excessive stains and/or damage*",
                "Seat belts function properly*",
                "Seat belt height adjusters function properly*",
                "All headrests present and working properly*",
                "All headrests free from burn holes, excessive stains and/or damage*",
                "Headrest: Movement and adjustment function properly*",
                "All seats free from burn holes, excessive stains and/or damage*",
                "Lumbar support adjustment functions properly*",
                "Manual seat(s) function properly*",
                "Power seat(s) function properly*",
                "Seat heater/cooler - front/rear function properly*",
                "Power memory seat functions properly*",
                "Visors are dirty*",
                "Visors have burn holes, excessive stains or damage*",
                "Vehicle is free of odor or scents to mask odor*",
                "Interior is dirty*",
                "Interior has excessive dressing*",
                "Carpet is free from visible stains or signs of damage*",
                "Cup holder inserts are present and clean*",
                "Glove box and Glove box lock (if equipped) function properly*",
                "Rearview mirror (day and night mode) and self-dimming function properly*",
                "Vanity mirrors and lights are present, free of damage, and function properly*",
                "Side mirror controls function properly*",
                "Bluetooth system set to default & no personal information remains*",
                "Rearview camera/parking guide system function properly*",
                "All speakers function properly*",
                "Climate control adjusts as required*",
                "Steering wheel lock and turn signals and wiper controls operate*",
                "Defogger/defroster functions properly*",
                "Horn does not work*",
                "Tilt and/or telescopic steering and heated steering wheel (if applicable) function properly*",
                "Memory steering column (if applicable) functions properly*",
                "Power rear sun shade (if applicable) functions properly*",
                "Trunk release functions properly*",
                "Hood release and cluster messaging function properly*",
                "Fuel gauge functions properly*",
                "Fuel door and release function properly*",
                "Gear shift indicator correctly identifies gear*",
                "Alarm/theft deterrent: arms and disarms*",
                "Warning bells/chimes*",
                "A/C does not blow cold air and/or work properly*",
                "Heater does not blow warm air and/or work properly*",
                "Vents do not work properly*",
                "Sunroof glass has no chips, streaks, or cracks*",
                "Sunroof shade free from damage/wear*",
                "Power sunroof functions and controls work properly*",
                "Outside temperature gauge functions properly*",
                "Navigation system - system operates properly and is reset to factory specs*",
                "Cigarette lighter/12V AC power outlet/wireless charging port(s) function properly*",
                "Power windows function properly*",
                "Auto up and down window controls function properly*"
        );

        for (String item : items) {
            appGeneric.swipeToCenter(item);
            String details = appGeneric.handleButtonSelection(item, null);
            log.info("For the question : {} selected option: {}", item, details);
        }
    }

    public void finalizeInteriorAppearanceDetailingSection() throws InterruptedException {
        actions.swipeUntilEnd("up");
        generic.waitForVisibility(exteriorAppearanceButton).click();
        log.info("Completed all sections of Interior Appearance / Detailing.");
    }

}
