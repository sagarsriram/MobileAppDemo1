package org.openlane.autohawk.pageobject;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.*;
import org.openlane.autohawk.utils.AndroidActions;
import org.openlane.autohawk.utils.AppiumGeneric;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSXCUITAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
public class InspectionLandingPage {
    AppiumDriver driver;
    AppiumGeneric generic;
    AndroidActions actions;
    private static final Logger log = LoggerFactory.getLogger(InspectionLandingPage.class);

    public InspectionLandingPage(AppiumDriver driver) {
        this.driver = driver;
        this.generic = new AppiumGeneric();
        this.generic.setDriver(driver);
        this.actions = new AndroidActions(driver);
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }

    /*
    Defining locators
     */
    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/textView"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/textView")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement popupAddDamage;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/button"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/button")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement popupConfirmDamageAcknowledge;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/add_damage_button"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/add_damage_button")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement addDamageButton;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/overflow"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/overflow")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement overflowButton;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Add Extra Photo\")")
    @iOSXCUITFindBy(id = "")
    private WebElement addExtraPhoto;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Edit Vehicle Info\")")
    @iOSXCUITFindBy(id = "")
    private WebElement editVehicleInfo;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Get Help / Give Feedback\")")
    @iOSXCUITFindBy(id = "")
    private WebElement getHelpGiveFeedback;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Save & Exit Inspection\")")
    @iOSXCUITFindBy(id = "")
    private WebElement saveAndExitInspection;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Damages\")")
    @iOSXCUITFindBy(id = "")
    private WebElement damagesTile;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Photos\")")
    @iOSXCUITFindBy(id = "")
    private WebElement photosTile;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Wheels/Tires\")")
    @iOSXCUITFindBy(id = "")
    private WebElement wheelsTiresTile;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Equipment\")")
    @iOSXCUITFindBy(id = "")
    private WebElement equipmentTile;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Announcements\")")
    @iOSXCUITFindBy(id = "")
    private WebElement announcementsTile;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Kickoff\")")
    @iOSXCUITFindBy(id = "")
    private WebElement kickoffSection;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Front Interior\")")
    @iOSXCUITFindBy(id = "")
    private WebElement frontInteriorSection;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Rear Interior\")")
    @iOSXCUITFindBy(id = "")
    private WebElement rearInteriorSection;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Left Exterior\")")
    @iOSXCUITFindBy(id = "")
    private WebElement leftExteriorSection;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Rear Exterior\")")
    @iOSXCUITFindBy(id = "")
    private WebElement rearExteriorSection;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Right Exterior\")")
    @iOSXCUITFindBy(id = "")
    private WebElement rightExteriorSection;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Front Exterior\")")
    @iOSXCUITFindBy(id = "")
    private WebElement frontExteriorSection;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Mechanical\")")
    @iOSXCUITFindBy(id = "")
    private WebElement mechanicalSection;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Overall Vehicle\")")
    @iOSXCUITFindBy(id = "")
    private WebElement overallVehicleSection;

    @AndroidFindBy(uiAutomator = "new UiSelector().textContains(\"Type Of Inspection\")")
    @iOSXCUITFindBy(id = "")
    private WebElement typeOfInspectionSection;

    @AndroidFindBy(uiAutomator = "new UiSelector().textContains(\"Images\")")
    @iOSXCUITFindBy(id = "")
    private WebElement imagesSection;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Comments for Client\")")
    @iOSXCUITFindBy(id = "")
    private WebElement commentsForClientSection;

    @AndroidFindBy(uiAutomator = "new UiSelector().textContains(\"CPO Audit\")")
    @iOSXCUITFindBy(id = "")
    private WebElement cpoAuditSection;

    @AndroidFindBy(uiAutomator = "new UiSelector().textContains(\"Marketing and Paperwork\")")
    @iOSXCUITFindBy(id = "")
    private WebElement marketingAndPaperworkSection;

    @AndroidFindBy(uiAutomator = "new UiSelector().textContains(\"Display / Marketing Information\")")
    @iOSXCUITFindBy(id = "")
    private WebElement displayMarketingInformation;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Vehicle / General Eligibility\")")
    @iOSXCUITFindBy(id = "")
    private WebElement vehicleGeneralEligibilitySection;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Electrical\")")
    @iOSXCUITFindBy(id = "")
    private WebElement electricalSection;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Exterior Appearance/Detailing\")")
    @iOSXCUITFindBy(id = "")
    private WebElement exteriorAppearanceDetailingSection;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Internet \")")
    @iOSXCUITFindBy(id = "")
    private WebElement internetSection;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"COMPLETE INSPECTION\")")
    @iOSXCUITFindBy(id = "")
    private WebElement completeInspectionSection;


    /*
    Defining actions
     */
    public String verifyLandingOfInspectionScreen(String passVinNumber) {
        if (generic.isElementVisible(popupAddDamage)) {
            generic.waitForVisibility(popupConfirmDamageAcknowledge).click();
        } else {
            log.info("No popup upon landing on Inspection screen");
        }

        String extractVinNumber = driver.findElement(By.id("com.openlane.autohawk.uat:id/tv_title_flipped_overflow")).getText();

        String vinRegex = "\\b[0-9A-Z]{17}\\b";

        Pattern pattern = Pattern.compile(vinRegex);
        Matcher matcher = pattern.matcher(extractVinNumber);
        String vinNumber = null;
        if (matcher.find()) {
            vinNumber = matcher.group(); // Extract the VIN
        } else {
            throw new IllegalArgumentException("No valid VIN found in the extracted text: " + extractVinNumber);
        }

        if (Objects.equals(vinNumber, passVinNumber)) {
            Assert.assertTrue(true, "VIN number matched");
            System.out.println(vinNumber + " " + passVinNumber);
        } else {
            Assert.fail("VIN number not matched, Inspection landing screen failed to load");
            System.out.println(vinNumber + " " + passVinNumber);
        }

        return vinNumber;
    }

    public void tapAddDamageButton() {
        generic.waitForVisibility(addDamageButton).click();
    }

    public void tapOverflowButton() {
        generic.waitForVisibility(overflowButton).click();
    }

    public void tapAddExtraPhoto() {
        generic.waitForVisibility(addExtraPhoto).click();
    }

    public void tapEditVehicleInfo() {
        generic.waitForVisibility(editVehicleInfo).click();
    }

    public void tapGetHelpGiveFeedback() {
        generic.waitForVisibility(getHelpGiveFeedback).click();
    }

    public void tapSaveAndExitInspection() {
        generic.waitForVisibility(saveAndExitInspection).click();
    }

    public void tapDamagesTile() {
        generic.waitForVisibility(damagesTile).click();
    }

    public void tapPhotosTile() {
        generic.waitForVisibility(photosTile).click();
    }

    public void tapWheelsTiresTile() {
        generic.waitForVisibility(wheelsTiresTile).click();
    }

    public void tapEquipmentTile() {
        generic.waitForVisibility(equipmentTile).click();
    }

    public void tapAnnouncementsTile() {
        generic.waitForVisibility(announcementsTile).click();
    }

    public void tapKickoffSection() {
        generic.waitForVisibility(kickoffSection).click();
    }

    public void tapFrontInteriorSection() {
        generic.waitForVisibility(frontInteriorSection).click();
    }

    public void tapRearInteriorSection() {
        generic.waitForVisibility(rearInteriorSection).click();
    }

    public void tapLeftExteriorSection() {
        generic.waitForVisibility(leftExteriorSection).click();
    }

    public void tapRearExteriorSection() {
        generic.waitForVisibility(rearExteriorSection).click();
    }

    public void tapRightExteriorSection() {
        generic.waitForVisibility(rightExteriorSection).click();
    }

    public void tapFrontExteriorSection() {
        By subTitleLocator = By.xpath("//android.widget.TextView[contains(@text, 'Front Exterior')]");
        actions.swipeUntilVisibleAndCenter(subTitleLocator);
        generic.waitForVisibility(frontExteriorSection).click();
    }

    public void tapMechanicalSection() {
        By subTitleLocator = By.xpath("//android.widget.TextView[contains(@text, 'Mechanical')]");
        actions.swipeUntilVisibleAndCenter(subTitleLocator);
        generic.waitForVisibility(mechanicalSection).click();
    }

    public void tapOverallVehicleSection() {
        By subTitleLocator = By.xpath("//android.widget.TextView[contains(@text, 'Overall Vehicle')]");
        actions.swipeUntilVisibleAndCenter(subTitleLocator);
        generic.waitForVisibility(overallVehicleSection).click();
    }

    public void tapTypeOfInspectionSection() {
        generic.waitForVisibility(typeOfInspectionSection).click();
    }

    public void tapCPOAuditSection() {
        generic.waitForVisibility(cpoAuditSection).click();
    }

    public void tapImagesSection() {
        generic.waitForVisibility(imagesSection).click();
    }

    public void tapMarketingAndPaperworkSection() {
        generic.waitForVisibility(marketingAndPaperworkSection).click();
    }

    public void tapDisplayMarketingInformationSection() {
        generic.waitForVisibility(marketingAndPaperworkSection).click();
    }

    public void tapCompleteInspectionButton() throws InterruptedException {
        actions.swipeUntilEnd("up");
        generic.waitForVisibility(completeInspectionSection).click();
    }

}


