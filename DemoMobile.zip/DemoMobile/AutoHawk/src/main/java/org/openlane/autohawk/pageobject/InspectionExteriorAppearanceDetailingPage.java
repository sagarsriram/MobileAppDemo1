package org.openlane.autohawk.pageobject;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.*;
import org.openlane.autohawk.utils.AndroidActions;
import org.openlane.autohawk.utils.AppiumGeneric;
import org.openlane.autohawk.utils.ApplicationGeneric;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;

@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSXCUITAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
public class InspectionExteriorAppearanceDetailingPage {
    AppiumDriver driver;
    AppiumGeneric generic;
    AndroidActions actions;
    ApplicationGeneric appGeneric;
    private static final Logger log = LoggerFactory.getLogger(InspectionExteriorAppearanceDetailingPage.class);

    public InspectionExteriorAppearanceDetailingPage(AppiumDriver driver) {
        this.driver = driver;
        this.generic = new AppiumGeneric();
        this.generic.setDriver(driver);
        this.actions = new AndroidActions(driver);
        this.appGeneric = new ApplicationGeneric(driver);
        PageFactory.initElements(new AppiumFieldDecorator(driver, Duration.ofSeconds(10)), this);
    }

    //Defining locators

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/tv_title_extra_photo"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/tv_title_extra_photo")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement exteriorAppearanceTitle;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/btn_next_section"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/btn_next_section")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement internetButtonOrRequiredImagesButton;

    public void verifyExteriorAppearanceDetailingTitle() {
        String expectedTitle1 = "Exterior Appearance/Detailing";
        String expectedTitle2 = "Exterior Appearance / Detailing";
        String expectedTitle3 = "Exterior";
        String actualTitle = exteriorAppearanceTitle.getText();
        Assert.assertTrue(
                actualTitle.equals(expectedTitle1) || actualTitle.equals(expectedTitle2) || actualTitle.equals(expectedTitle3),
                "Exterior Appearance/Detailing title is not matching"
        );
        log.info("Exterior Appearance/Detailing title is verified successfully: " + actualTitle);
    }

    public void verifyExteriorAppearanceDetailingButtonOptionsToyotaSoldUnitNOAndGoldUnitYES() {
        List<String> items = Arrays.asList(
                "One or more dents in zone A*",
                "One or two dents in zone B*",
                "Three or more dents in zone B*",
                "One ding zone A*",
                "Two dings zone A*",
                "Three or more dings*",
                "Three dings zone B*",
                "Four dings zone B*",
                "Five or more dings zone B*",
                "Multiple or severe scratches longer than three inches (including 'keying')*",
                "One unrepaired scratch requiring touch up or repainting zone A*",
                "Two unrepaired scratches requiring touch up or repainting zone A*",
                "Three or more unrepaired scratches requiring touch up or repainting zone A*",
                "One unrepaired scratch requiring touch up or repainting zone B*",
                "Two unrepaired scratches requiring touch up or repainting zone B*",
                "Three unrepaired scratches requiring touch up or repainting zone B*",
                "Four or more unrepaired scratches requiring touch up or repainting zone B*",
                "Excessive or severe paint chips are considered body damage*",
                "Moderate paint chips in hood*",
                "Vehicle has improperly repaired paint*",
                "Swirl marks in the paint*",
                "Exterior surface, cracks and/or side moldings have excessive wax residue*",
                "Paint has hazing and/or uneven luster*",
                "Window tinting in poor condition, obscures vision and can be a safety concern*",
                "Glass has minor cracks, stars, bullseyes and/or pitting*",
                "Excessive damage or crack in glass - window glass with excessive damage obscures vision & can be a safety concern*",
                "Engine compartment is dirty*",
                "Engine compartment has excessive dressing*",
                "Tires dirty and/or greasy from dressing*",
                "Wheels and/or wheel wells are dirty*",
                "Wheels do not match and/or are in poor condition*",
                "Vehicle needs washing and/or maintenance*",
                "Vehicle has etched in water spots*",
                "Vehicle glass dirty or streaky*",
                "Emblems, including trim pieces, missing or damaged*",
                "Bumpers damaged, cut, gouged or scratched*",
                "Rear-view and/or external mirrors missing, cracked and/or damaged*",
                "Rear-view and/or external mirrors are dirty*"
        );

        for (String item : items) {
            appGeneric.swipeToCenter(item);
            String selectedOption = appGeneric.handleButtonSelection(item, null);
            if (item.contains("Engine compartment is dirty*") && selectedOption.contains("Deduct")) {
                appGeneric.handlePhotoSelection("Engine Photo");
            }
        }
    }

    public void verifyExteriorAppearanceDetailingButtonOptionsToyotaSoldUnitNOAndGoldUnitNO() {
        List<String> items = Arrays.asList(
                "One or more dents in zone A*",
                "One or two dents in zone B*",
                "Three or more dents in zone B*",
                "One ding zone A*",
                "Two dings zone A*",
                "Three or more dings*",
                "Three dings zone B*",
                "Four dings zone B*",
                "Five or more dings zone B*",
                "Auto Fail: Multiple or severe scratches longer than three inches (including 'keying')*", //change
                "One unrepaired scratch requiring touch up or repainting zone A*",
                "Two unrepaired scratches requiring touch up or repainting zone A*",
                "Three or more unrepaired scratches requiring touch up or repainting zone A*",
                "One unrepaired scratch requiring touch up or repainting zone B*",
                "Two unrepaired scratches requiring touch up or repainting zone B*",
                "Three unrepaired scratches requiring touch up or repainting zone B*",
                "Four or more unrepaired scratches requiring touch up or repainting zone B*",
                "Excessive or severe paint chips are considered body damage*",
                "Moderate paint chips in hood*",
                "Vehicle has improperly repaired paint*",
                "Swirl marks in the paint*",
                "Exterior surface, cracks and/or side moldings have excessive wax residue*",
                "Paint has hazing and/or uneven luster*",
                "Window tinting in poor condition, obscures vision and can be a safety concern*",
                "Glass has minor cracks, stars, bullseyes and/or pitting*",
                "Excessive damage or crack in glass - window glass with excessive damage obscures vision & can be a safety concern*",
                "Engine compartment is dirty*",
                "Engine compartment has excessive dressing*",
                "Tires dirty and/or greasy from dressing*",
                "Wheels and/or wheel wells are dirty*",
                "Wheels do not match and/or are in poor condition*",
                "Vehicle needs washing and/or maintenance*",
                "Vehicle has etched in water spots*",
                "Vehicle glass dirty or streaky*",
                "Emblems, including trim pieces, missing or damaged*",
                "Bumpers damaged, cut, gouged or scratched*",
                "Rear-view and/or external mirrors missing, cracked and/or damaged*",
                "Rear-view and/or external mirrors are dirty*"
        );

        for (String item : items) {
            appGeneric.swipeToCenter(item);
            String selectedOption = appGeneric.handleButtonSelection(item, null);
            if (item.contains("Engine compartment is dirty*") && selectedOption.contains("Deduct")) {
                appGeneric.handlePhotoSelection("Engine Photo");
            }
        }
    }

    public void verifyExteriorAppearanceDetailingButtonOptionsGulfState() {
        List<String> items = Arrays.asList(
                "One or more dents in zone A*",
                "Vehicle has dents in zone B*",
                "One ding zone A*",
                "Two dings zone A*",
                "Vehicle has three or more dings in zone A*",
                "Three dings zone B*",
                "Four dings zone B*",
                "Five or more dings zone B*",
                "Multiple or severe scratches longer than three inches (including 'keying')*",
                "One unrepaired scratch requiring touch up or repainting zone A*",
                "Two unrepaired scratches requiring touch up or repainting zone A*",
                "Three or more unrepaired scratches requiring touch up or repainting zone A*",
                "One unrepaired scratch requiring touch up or repainting zone B*",
                "Two unrepaired scratches requiring touch up or repainting zone B*",
                "Three unrepaired scratches requiring touch up or repainting zone B*",
                "Four or more unrepaired scratches requiring touch up or repainting zone B*",
                "Vehicle has excessive or severe paint chips are considered body damage*",
                "Moderate paint chips in hood*",
                "Vehicle has improperly repaired paint*",
                "Swirl marks in the paint*",
                "Exterior surface, cracks and/or side moldings have excessive wax residue*",
                "Paint has hazing and/or uneven luster*",
                "Window tinting in poor condition, obscures vision and can be a safety concern*",
                "Glass has minor cracks, stars, bullseyes and/or pitting*",
                "Vehicle has excessive damage or crack(s) in glass*",
                "Engine compartment is dirty*",
                "Engine compartment has excessive dressing*",
                "Tires dirty and/or greasy from dressing*",
                "Wheels and/or wheel wells are dirty*",
                "Wheels do not match and/or are in poor condition*",
                "Vehicle needs washing and/or maintenance*",
                "Vehicle has etched in water spots*",
                "Vehicle glass dirty or streaky*",
                "Vehicle's bumpers are damaged, cut or gouged*",
                "Emblems, including trim pieces, missing or damaged*",
                "Rear-view and/or external mirrors missing, cracked and/or damaged*",
                "Rear-view and/or external mirrors are dirty*"
        );

        for (String item : items) {
            appGeneric.swipeToCenter(item);
            String selectedOption = appGeneric.handleButtonSelection(item, null);
            if (item.contains("Engine compartment is dirty*") && selectedOption.contains("Deduct")) {
                appGeneric.handlePhotoSelection("Engine Photo");
            }
        }
    }

    public void verifyExteriorAppearanceDetailingButtonOptionsLexus() {
        List<String> items = Arrays.asList(
                "Any panels with previous repairs? (Please include comment and images of panels if any.)*",
                "Zone a: any surface scratch*",
                "Zone a: any deep scratch greater than 1 inch that does not penetrate the base metal*",
                "Zone a: any deep scratch that penetrates base metal*",
                "Zone a: any scuff or mar that penetrates the paint*",
                "Zone a: any paint chip greater than 1/4 inch that does not penetrate the base metal*",
                "Zone a: any paint chip that pentrates the base metal*",
                "Zone a: any ding or dent*",
                "Zone b: any surface scratch*",
                "Zone b: any deep scratch greater than 4 inches that does not penetrate the cladding/bumper*",
                "Zone b: any paint transfer*",
                "Zone b: any scuff or mark that penetrates the cladding/bumper*",
                "Zone b: any paint chip greater than 4 inches that does not penetrate the cladding/bumper*",
                "Vehicle has improperly repaired paint*",
                "Swirl marks in the paint*",
                "Exterior surface, cracks and/or side moldings have excessive wax residue*",
                "Paint has hazing and/or uneven luster*",
                "Window tinting in poor condition, obscures vision and can be a safety concern*",
                "Windshield / glass has cracks of any kind in any location*",
                "Windshield / glass has scratches that impair the view*",
                "Vehicle glass dirty or streaky*",
                "Tires dirty and/or greasy from dressing*",
                "Wheels and/or wheel wells are dirty*",
                "Wheels do not match and/or are in poor condition*",
                "Wheels are bent and/or cracked*",
                "Scuffs, cuts, or gouges on the face of the wheel*",
                "Vehicle needs washing and/or maintenance*",
                "Emblems, including trim pieces, missing or damaged*",
                "Rear-view and/or external mirrors missing, cracked and/or damaged*",
                "Rear-view and/or external mirror housings have dents and/or cuts in trim or molding*",
                "Scrapes / scratches on external mirror housings*",
                "Rear-view and/or external mirrors are dirty*"
        );

        for (String item : items) {
            appGeneric.swipeToCenter(item);
            String details = appGeneric.handleButtonSelection(item, null);
            log.info("For the question : {} selected option: {}", item, details);
        }
    }

    public void verifyExteriorButtonOptionsHyundai() {
        List<String> items = Arrays.asList(
                "Frame/unibody must not have previous damage. Repairing still does not meet eligibility requirements.*",
                "Vehicle has improperly repaired paint*",
                "Swirl marks in the paint*",
                "Paint has hazing and/or uneven luster*",
                "All body panels free from dents*",
                "Body panels free from issues with fit and alignment*",
                "Windshield and other glass is free from chips or cracks*",
                "Front and rear bumper/grille: finish, appearance, no visible damage*",
                "Emblems/name plates show no signs of damage/wear*",
                "Head lamps function properly on high/low beam*",
                "Head lamps have a clear lens and are free from damage*",
                "Parking lamp function properly on high/low beam*",
                "Parking lamp has a clear lens and is free from damage*",
                "Brake light, high-mount tail light, reverse, and license plate light illuminate and function properly*",
                "Brake light, high-mount tail light, reverse, and license plate light have clear lenses and are free from damage*",
                "Fog lamps function properly*",
                "Fog lamps have a clear lens and no damage*",
                "Turn signals function properly*",
                "Turn signals have a clear lens and no damage*",
                "Side lights function properly*",
                "Side lights have a clear lens and no damage*",
                "Rear defrost element has no visible damage*",
                "Door hinges function properly (ex. door opens smoothly, free of squeaks)*",
                "Hood strut (if applicable) functions properly*",
                "Rear lift gate struts & lock (if applicable) function properly*",
                "Remote trunk entry functions properly (if applicable)*",
                "Trunk light functions properly*",
                "Trunk and compartments are free from debris, stains, damage, and/or tears*",
                "Spare tire and storage area not clean*",
                "Trunk carpet free from tears, stains, or damage/wear*",
                "Jack, jack handle kit, and tool kit is present*",
                "Spare tire/mobility kit (if applicable) is present*",
                "License place bracket front and back (if applicable) are present*",
                "Exterior modifications abide by factory specifications*",
                "Puddle lights function properly*",
                "Door handle welcome lights function properly*",
                "All labels/decals/vin number stickers (ex. under hood, door jam, etc.) are present and in good condition*",
                "Tires on vehicle are properly inflated*",
                "Tires on vehicle are a matched set (size, brand, and speed/load rating)*",
                "Tire tread depth (minimum 5/32\" across tread width)*",
                "Wheels/rims on vehicle are a matched set*",
                "Wheels/rims and valve stems are free from damage/wear*"
        );

        for (String item : items) {
            appGeneric.swipeToCenter(item);
            String details = appGeneric.handleButtonSelection(item, null);
            log.info("For the question : {} selected option: {}", item, details);
        }
    }

    public void finalizeExteriorAppearanceDetailingSection() throws InterruptedException {
        actions.swipeUntilEnd("up");
        generic.waitForVisibility(internetButtonOrRequiredImagesButton).click();
        log.info("Completed all sections of Exterior Appearance / Detailing.");
    }


}
