package org.openlane.autohawk.utils;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;
import org.apache.commons.io.FileUtils;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class AppiumGeneric {
    public AppiumDriverLocalService service;
    protected AppiumDriver driver;
    private static final Logger log = LoggerFactory.getLogger(AppiumGeneric.class);

    /**
     * This method sets the AppiumDriver instance for the current session.
     * It is typically used during driver initialization after creating the AppiumDriver.
     *
     * @param driver - the AppiumDriver instance (can be AndroidDriver or IOSDriver)
     *               Why it's needed:
     *               - Centralizes driver management across utility/helper classes
     *               - Allows child classes to reuse the protected driver instance
     */
    public void setDriver(AppiumDriver driver) {
        this.driver = driver;
    }

    /**
     * Starts the Appium server programmatically using the provided IP and port.
     * This is useful for CI/CD environments or avoiding manual server start via terminal.
     *
     * @param ipAddress - the IP address to bind the Appium server to (usually "127.0.0.1")
     * @param port      - the port to run the Appium server on (e.g., 4723)
     * @return - the AppiumDriverLocalService instance, now running
     * Example:
     * startAppiumServer("127.0.0.1", 4723);
     * Note:
     * Make sure Appium is installed and path to main.js is correct.
     */
    public AppiumDriverLocalService startAppiumServer(String ipAddress, int port) {
        service = new AppiumServiceBuilder()
                .withAppiumJS(new File("/usr/local/lib/node_modules/appium/build/lib/main.js"))
                .withIPAddress(ipAddress)
                .usingPort(port)
                //   .withArgument(() -> "--log-level", "error") // Suppress verbose logs
                .build();
        service.start();
        return service;
    }

    /**
     * Captures a screenshot and saves it to a predefined directory with the test case name.
     *
     * @param testCaseName - name used to label the screenshot file
     * @param driver       - the active AppiumDriver instance
     * @return String path of the destination screenshot file
     * @throws IOException if screenshot capture or file write fails
     *                     Example output:
     *                     /your-project/reports/LoginTest.png
     *                     Why it's useful:
     *                     - Captures visual proof of test execution
     *                     - Helps in debugging failed steps
     *                     - Returns file path for use in reports (like ExtentReports)
     */
    public String getScreenShot(String testCaseName, AppiumDriver driver) throws IOException {
        File Source = driver.getScreenshotAs(OutputType.FILE);
        String destinationFile = System.getProperty("user.dir") + "/reports/" + testCaseName + ".png";
        FileHandler.copy(Source, new File(destinationFile));
        return destinationFile;
    }

    /**
     * Captures and saves a screenshot directly to the /reports/ folder.
     *
     * @param screenshotName - desired filename (without extension)
     * @param driver         - the active AppiumDriver instance
     *                       Why it's useful:
     *                       - Quick utility to take screenshots for debugging or ad-hoc steps
     *                       - Doesn't return path, just saves the screenshot with the given name
     *                       - Useful for void-based logging/debugging during test flow
     */
    public void takeScreenshot(String screenshotName, AppiumDriver driver) {
        try {
            File screenshot = driver.getScreenshotAs(OutputType.FILE);
            File destination = new File(System.getProperty("user.dir") + "/reports/" + screenshotName + ".png");
            FileUtils.copyFile(screenshot, destination);
        } catch (IOException e) {
            System.out.println("Failed to take screenshot: " + e.getMessage());
        }
    }

    /**
     * Checks if a given WebElement is currently visible on the screen.
     *
     * @param element - the WebElement to check
     * @return true if element is displayed, false otherwise
     * Why it's useful:
     * - Prevents NoSuchElementException by wrapping in a safe try-catch
     * - Acts as a Boolean condition for optional logic (e.g., if login button exists)
     */
    public boolean isElementVisible(WebElement element) {
        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
            wait.until(ExpectedConditions.visibilityOf(element));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Waits explicitly for a WebElement to become visible on the screen.
     *
     * @param element - the WebElement to wait for
     * @return the same WebElement once it becomes visible
     * Why it's useful:
     * - Ensures synchronization between script and app UI
     * - Reduces flakiness caused by timing issues
     * - Reusable across all page classes
     * - One more method with overloaded to accept a timeout
     */
    public WebElement waitForVisibility(WebElement element) {
        try {
            return new WebDriverWait(driver, Duration.ofSeconds(6))
                    .until(ExpectedConditions.visibilityOf(element));
        } catch (Exception e) {
            log.error("Element not visible: {}", element);
            return null;
        }

    }

    public WebElement waitForVisibility(WebElement element, int timeoutInSeconds) {
        return new WebDriverWait(driver, Duration.ofSeconds(timeoutInSeconds))
                .until(ExpectedConditions.visibilityOf(element));
    }

    public WebElement waitForPresence(By locator, int timeoutInSeconds) {
        return new WebDriverWait(driver, Duration.ofSeconds(timeoutInSeconds))
                .until(ExpectedConditions.presenceOfElementLocated(locator));
    }

    /**
     * Loads and manages configuration from an external .properties file.
     * This static block is executed once when the class is loaded. It reads a configuration
     * file from the specified path and loads its key-value pairs into a Properties object.
     * The `getProperty(String key)` method allows retrieving the values dynamically using a key.
     * It's commonly used for accessing credentials, environment URLs, timeouts, etc.
     * Example usage:
     * String username = getProperty("userName");
     * String baseUrl = getProperty("baseUrl");
     * Usage:
     * - Centralized configuration management
     * - Keeps test data externalized and maintainable
     * - Eliminates hardcoded values from test scripts
     */
    private static Properties props;

    static {
        try {
            FileInputStream file = new FileInputStream(System.getProperty("user.dir") + "/src/main/java/org/openlane/autohawk/resources/data.properties");
            props = new Properties();
            props.load(file);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static String getProperty(String key) {
        String value = props.getProperty(key);

        if (value == null || value.trim().isEmpty()) {
            System.out.println("warning : Property key '" + key + "' not found or is empty in the properties file.");
        }

        return value;
    }


    public class VinDetailsReader {
        private static JSONObject vinDetails;

        static {
            try {
                FileInputStream fis = new FileInputStream(System.getProperty("user.dir") + "/src/main/java/org/openlane/autohawk/resources/data_config.json");
                JSONObject json = new JSONObject(new JSONTokener(fis));
                vinDetails = json.getJSONObject("vinKeyDetails");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        public static String getVinValue(String vinKeyDetails) {
            return vinDetails.optString(vinKeyDetails, "NOT_FOUND");
        }
    }

    public void restartApp() {
        Map<String, Object> args = new HashMap<>();
        args.put("appId", props.getProperty("UAT_ANDROID_APP_PACKAGE"));
        driver.executeScript("mobile: terminateApp", args);
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        driver.executeScript("mobile: activateApp", args);
    }

}
