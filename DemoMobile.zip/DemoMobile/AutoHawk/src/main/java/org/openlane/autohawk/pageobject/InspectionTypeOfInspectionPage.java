package org.openlane.autohawk.pageobject;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.*;
import org.openlane.autohawk.utils.AndroidActions;
import org.openlane.autohawk.utils.AppiumGeneric;
import org.openlane.autohawk.utils.ApplicationGeneric;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.time.Duration;

@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSXCUITAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
public class InspectionTypeOfInspectionPage {
    AppiumDriver driver;
    AppiumGeneric generic;
    AndroidActions actions;
    ApplicationGeneric appGeneric;
    private static final Logger log = LoggerFactory.getLogger(InspectionTypeOfInspectionPage.class);

    public InspectionTypeOfInspectionPage(AppiumDriver driver) {
        this.driver = driver;
        this.generic = new AppiumGeneric();
        this.generic.setDriver(driver);
        this.actions = new AndroidActions(driver);
        this.appGeneric = new ApplicationGeneric(driver);
        PageFactory.initElements(new AppiumFieldDecorator(driver, Duration.ofSeconds(10)), this);
    }

    //Defining locators

    @AndroidFindBy(id = "com.openlane.autohawk.uat:id/tv_title_extra_photo")
    @iOSXCUITFindBy(id = "")
    private WebElement typeOfInspectionTitle;

    public void verifyTypeOfInspectionTitle() {
        String expectedTitle = "Type Of Inspection ";
        String actualTitle = typeOfInspectionTitle.getText();
        Assert.assertEquals(actualTitle.trim().toLowerCase(), expectedTitle.trim().toLowerCase(), "Type Of Inspection title is not matching");
        log.info("Type Of Inspection title is verified successfully: " + actualTitle);
    }

    public void verifyMandatoryTypeOfInspection(String SOLD_UNIT_Input_Yes_or_Input_No) {
        //contains Yes or No option
        appGeneric.handleButtonSelection("Is this a Sold Unit paperwork", SOLD_UNIT_Input_Yes_or_Input_No);
        driver.navigate().back();
    }

    public void verifyMandatoryTypeOfInspectionGoldUnit(String SOLD_UNIT_Input_Yes_or_Input_No, String GOLD_UNIT_Input_Yes_or_Input_No) {
        //contains Yes or No option
        appGeneric.handleButtonSelection("Is this a Sold Unit paperwork", SOLD_UNIT_Input_Yes_or_Input_No);
        appGeneric.handleButtonSelection("Is this a Gold unit", GOLD_UNIT_Input_Yes_or_Input_No);
        driver.navigate().back();
    }
//    public void finalizeTypeOfInspectionSection() throws InterruptedException {
//        actions.swipeUntilEnd("up");
//        generic.waitForVisibility(imagesButton).click();
//        log.info("completed all mandatory sections of CPO Audit - Sold Unit Paperwork On File");
//    }


}
