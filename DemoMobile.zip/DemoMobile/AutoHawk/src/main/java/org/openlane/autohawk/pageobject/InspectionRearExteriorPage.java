package org.openlane.autohawk.pageobject;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.pagefactory.*;
import org.openlane.autohawk.utils.AndroidActions;
import org.openlane.autohawk.utils.AppiumGeneric;
import org.openlane.autohawk.utils.ApplicationGeneric;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;

@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSXCUITAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
public class InspectionRearExteriorPage {
    AppiumDriver driver;
    AppiumGeneric generic;
    AndroidActions actions;
    ApplicationGeneric appGeneric;
    private static final Logger log = LoggerFactory.getLogger(InspectionRearExteriorPage.class);

    public InspectionRearExteriorPage(AppiumDriver driver) {
        this.driver = driver;
        this.generic = new AppiumGeneric();
        this.generic.setDriver(driver);
        this.actions = new AndroidActions(driver);
        this.appGeneric = new ApplicationGeneric(driver);
        PageFactory.initElements(new AppiumFieldDecorator(driver, Duration.ofSeconds(10)), this);
    }

    //Defining locators

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/tv_title_extra_photo"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/tv_title_extra_photo")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement rearExteriorTitle;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Reverse Camera\")")
    @iOSXCUITFindBy(id = "")
    private WebElement optionalRearExteriorReverseCameraCheckBoxSubTitle;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Power Liftgate\")")
    @iOSXCUITFindBy(id = "")
    private WebElement optionalRearExteriorPowerLiftGateCheckBoxSubTitle;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/dropdownBG"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/dropdownBG")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement optionalRearExteriorLicenseStateDropDown;

    @AndroidFindBy(uiAutomator = "new UiSelector().textContains(\"Cargo Area Photo\")")
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryCargoAreaPhotoSubTitle;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Interior Cargo Cover\")")
    @iOSXCUITFindBy(id = "")
    private WebElement optionalCargoAreaInteriorCargoCoverCheckBox;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/et_textbox_control"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/et_textbox_control")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryRearTireSizeTextBox;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Spare Tire Size*\")")
    @iOSXCUITFindBy(id = "")
    private WebElement mandatorySpareTireSizeDropDownSubTitle;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Spare Tire Size*\")")
    @iOSXCUITFindBy(id = "")
    private WebElement mandatorySpareTireTreadDropDownSubTitle;

    @AndroidFindBy(uiAutomator = "new UiSelector().textContains(\"Undercarriage - Rear Photo\")")
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryUnderCarriageRearPhotoSubTitle;

    @AndroidFindBy(uiAutomator = "new UiSelector().textContains(\"Spare Tire & Wheel Photo\")")
    @iOSXCUITFindBy(id = "")
    private WebElement mandatorySpareTireAndWheelPhotoSubTitle;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/btn_next_section"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/btn_next_section")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement rightExteriorButton;

    @AndroidFindBy(xpath = "//android.widget.TextView[contains (@text, \"Towing Options\")]/following-sibling::android.widget.ImageView")
    @iOSXCUITFindBy(id = "")
    private WebElement towingOptionsDamageButton;

    //Defining actions

    public void verifyRearExteriorTitle() {
        String expectedTitle = "Rear Exterior";
        String actualTitle = rearExteriorTitle.getText();
        Assert.assertEquals(actualTitle, expectedTitle, "Title does not match");
        log.info("Section Title verified successfully: {}", actualTitle);
    }

    public void verifyMandatoryCargoAreaSection() {
        By subTitleLocator = By.xpath("//android.widget.TextView[contains(@text, 'Cargo Area')]");
        actions.swipeUntilVisibleAndCenter(subTitleLocator);
        actions.scrollElementToCenter(mandatoryCargoAreaPhotoSubTitle);
        appGeneric.handlePhotoSelection("Cargo Area Photo");

    }

    public void verifyMandatorySpareTireSection() {
        By subTitleLocator = By.xpath("//android.widget.TextView[contains(@text, 'Spare Tire')]");
        actions.swipeUntilVisibleAndCenter(subTitleLocator);
        appGeneric.handleDropDownSelection("Spare Tire Size*", "Full Size Spare", mandatorySpareTireSizeDropDownSubTitle);
        appGeneric.handleDropDownSelection("Spare Tire Tread*", "8/32\\\"", mandatorySpareTireTreadDropDownSubTitle);
        By subTitleLocator1 = By.xpath("//android.widget.TextView[contains(@text, 'Spare Tire & Wheel Photo')]");
        actions.swipeUntilVisibleAndCenter(subTitleLocator1);
        appGeneric.handlePhotoSelection("Spare Tire & Wheel Photo");

        //adding Damage
        By subTitleLocator2 = By.xpath("//android.widget.TextView[contains(@text, 'Towing Options')]");
        actions.swipeUntilVisibleAndCenter(subTitleLocator2);
        generic.waitForVisibility(towingOptionsDamageButton).click();
        log.info("Adding damage for Towing Options section");
        appGeneric.addDamage();

    }

    public void verifyMandatoryUnderCarriagePhotoSection() {
        By subTitleLocator = By.xpath("//android.widget.TextView[contains(@text, 'Undercarriage Photo')]");
        actions.swipeUntilVisibleAndCenter(subTitleLocator);
        appGeneric.waitForVisibility(rightExteriorButton);
        appGeneric.handlePhotoSelection("Undercarriage - Rear Photo");

    }

    public void verifyMandatoryRearTireAndWheelSection() {
        appGeneric.handlePhotoSelection("Rear Tire Tread");
        appGeneric.swipeToCenter("");

        By subTitleLocator2 = By.xpath("//android.widget.TextView[contains(@text, 'Rear Tire Size')]");
        actions.swipeUntilVisibleAndCenter(subTitleLocator2);
        generic.waitForVisibility(mandatoryRearTireSizeTextBox).click();
        generic.waitForVisibility(mandatoryRearTireSizeTextBox).clear();
        generic.waitForVisibility(mandatoryRearTireSizeTextBox).sendKeys("225mm");
        AndroidDriver driver1 = (AndroidDriver) driver;
        driver1.pressKey(new KeyEvent(AndroidKey.ENTER));

        appGeneric.swipeToCenter("Rear Tire Brand");
        appGeneric.handleDropDownSelection("Rear Tire Brand*", "Apollo", null);

        appGeneric.swipeToCenter("Rear Tire Tread Depth");
        appGeneric.handleDropDownSelection("Rear Tire Tread Depth*", "1/32\"", null);

    }

    public void verifyMandatoryRearExteriorSection() {
        List<String> items = Arrays.asList(
                "Left Rear 3/4 Photo",
                "Rear Photo",
                "Right Rear 3/4 Photo"
        );

        for (String item : items) {
            appGeneric.swipeToCenter(item);
            appGeneric.handlePhotoSelection(item);
        }
    }


    public void finalizeRearExteriorInspection() {
        actions.scrollElementToCenter(rightExteriorButton);
        generic.waitForVisibility(rightExteriorButton).click();
        log.info("completed all mandatory sections of RearExterior");

    }


}
