package org.openlane.autohawk.pageobject;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.pagefactory.*;
import org.openlane.autohawk.utils.AndroidActions;
import org.openlane.autohawk.utils.AppiumGeneric;
import org.openlane.autohawk.utils.ApplicationGeneric;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.time.Duration;

@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSXCUITAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
public class InspectionFrontExteriorPage {
    AppiumDriver driver;
    AppiumGeneric generic;
    AndroidActions actions;
    ApplicationGeneric appGeneric;
    private static final Logger log = LoggerFactory.getLogger(InspectionFrontExteriorPage.class);

    public InspectionFrontExteriorPage(AppiumDriver driver) {
        this.driver = driver;
        this.generic = new AppiumGeneric();
        this.generic.setDriver(driver);
        this.actions = new AndroidActions(driver);
        this.appGeneric = new ApplicationGeneric(driver);
        PageFactory.initElements(new AppiumFieldDecorator(driver, Duration.ofSeconds(10)), this);
    }

    //Defining locators

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/tv_title_extra_photo"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/tv_title_extra_photo")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement frontExteriorTitle;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Roof Type*\")")
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryRoofTypeDropDownSubTitle;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/btn_next_section"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/btn_next_section")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement mechanicalButton;

    @AndroidFindBy(xpath = "//android.widget.TextView[contains (@text, \"Front Bumper\")]/following-sibling::android.widget.ImageView")
    @iOSXCUITFindBy(id = "")
    private WebElement frontBumperDamageButton;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/et_textbox_control"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/et_textbox_control")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryFrontTireSizeTextBox;
    //Defining actions

    public void verifyFrontExteriorTitle() {
        String expectedTitle = "Front Exterior";
        String actualTitle = frontExteriorTitle.getText();
        Assert.assertEquals(actualTitle, expectedTitle, "Title does not match");
        log.info("Section Title verified successfully: {}", actualTitle);
    }

    public void verifyMandatoryRoofSection() {
        appGeneric.handleDropDownSelection("Roof Type*", "Hard Top", mandatoryRoofTypeDropDownSubTitle);
        appGeneric.handlePhotoSelection("Exterior Roof Photo");

    }

    public void verifyMandatoryUnderCarriagePhotoFrontSection() {
        By subTitleLocator = By.xpath("//android.widget.TextView[contains(@text, 'Undercarriage Photo')]");
        actions.swipeUntilVisibleAndCenter(subTitleLocator);
        appGeneric.handlePhotoSelection("Undercarriage - Front Photo");
    }

    public void verifyMandatoryFrontTireWheelAndFrontExteriorPhotoSection() {
        appGeneric.handlePhotoSelection("Front Tire Tread");
        appGeneric.swipeToCenter("");

        By subTitleLocator2 = By.xpath("//android.widget.TextView[contains(@text, 'Front Tire Size')]");
        actions.swipeUntilVisibleAndCenter(subTitleLocator2);
        generic.waitForVisibility(mandatoryFrontTireSizeTextBox).click();
        generic.waitForVisibility(mandatoryFrontTireSizeTextBox).clear();
        generic.waitForVisibility(mandatoryFrontTireSizeTextBox).sendKeys("225mm");
        AndroidDriver driver1 = (AndroidDriver) driver;
        driver1.pressKey(new KeyEvent(AndroidKey.ENTER));

        appGeneric.swipeToCenter("Front Tire Brand");
        appGeneric.handleDropDownSelection("Front Tire Brand*", "Apollo", null);

        appGeneric.swipeToCenter("Front Tire Tread Depth");
        appGeneric.handleDropDownSelection("Front Tire Tread Depth*", "1/32\"", null);

        appGeneric.swipeToCenter("Undercarriage");
        appGeneric.handlePhotoSelection("Undercarriage");
    }

    public void finalizeFrontExteriorInspection() throws InterruptedException {
        actions.scrollElementToCenter(mechanicalButton);

        //adding damage
        generic.waitForVisibility(frontBumperDamageButton).click();
        log.info("Adding damage to Front Bumper");
        appGeneric.addDamage();

        actions.swipeUntilEnd("up");
        generic.waitForVisibility(mechanicalButton).click();
        log.info("completed all mandatory sections of Front Exterior");

    }


}
