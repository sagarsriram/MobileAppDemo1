package org.openlane.autohawk.pageobject;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.*;
import org.openlane.autohawk.utils.AndroidActions;
import org.openlane.autohawk.utils.AppiumGeneric;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSXCUITAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
public class HomePage {
    AppiumDriver driver;
    AndroidActions actions;
    AppiumGeneric generic;

    private static final Logger log = LoggerFactory.getLogger(HomePage.class);

    public HomePage(AppiumDriver driver) {
        this.driver = driver;
        this.actions = new AndroidActions(driver);
        this.generic = new AppiumGeneric();
        generic.setDriver(driver);
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }

    /*
    Defining locators
    for id locators replace with "com.openlane.autohawk.uat" with "com.kar.avx.uat.intune" for different package
     */
    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/tv_subtitle_flipped_margin"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/tv_subtitle_flipped_margin")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement homeScreenTitle;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/search_button"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/search_button")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement searchIconButton;

    @AndroidFindBy(className = "android.widget.EditText")
    @iOSXCUITFindBy(id = "")
    private WebElement searchTextBox;


    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/overflow"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/overflow")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement overFlowMenu;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Assigned\")")
    @iOSXCUITFindBy(id = "")
    private WebElement assignedTab;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"My Inspections\")")
    @iOSXCUITFindBy(id = "")
    private WebElement myInspectionsTab;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Site\")")
    @iOSXCUITFindBy(id = "")
    private WebElement siteTab;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/filter_button"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/filter_button")

    })
    @iOSXCUITFindBy(id = "")
    private WebElement filterButton;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/btn_retake"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/btn_retake")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement clearFilterButton;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/btn_next"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/btn_next")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement applyFilterButton;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/floating"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/floating")

    })
    @iOSXCUITFindBy(id = "")
    private WebElement floatingBarcodeScannerButton;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Upload Logs\")")
    @iOSXCUITFindBy(id = "")
    private WebElement uploadLogs;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Get Help / Give Feedback\")")
    @iOSXCUITFindBy(id = "")
    private WebElement getHelp;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"View Intercom Messages\")")
    @iOSXCUITFindBy(id = "")
    private WebElement viewIntercomMessages;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Site Settings\")")
    @iOSXCUITFindBy(id = "")
    private WebElement siteSettings;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Logout\")")
    @iOSXCUITFindBy(id = "")
    private WebElement logout;

    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Assigned']/following-sibling::android.widget.TextView")
    @iOSXCUITFindBy(id = "")
    private WebElement inspectionCountOfAssignedTab;

    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Site']/following-sibling::android.widget.TextView")
    @iOSXCUITFindBy(id = "")
    private WebElement inspectionCountOfSiteTab;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/btn_confirm"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/btn_confirm")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement inProgressInspectionResumeButton;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/btn_cancel"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/btn_cancel")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement inProgressInspectionCancelButton;

    /*
    Defining actions
     */
    public void verifyHomePageLoaded() {
        generic.waitForVisibility(homeScreenTitle, 60);
        Assert.assertTrue(homeScreenTitle.isDisplayed(), "Homescreen title not matched");
        log.info(homeScreenTitle.getText());

    }

    public void synchronizeByRefresh() {
        actions.swipe("down");
    }

    public void verifyHomePageElementsDisplayedForOffSiteUser() {
        Assert.assertTrue(searchIconButton.isDisplayed(), "Search Icon button not displayed");
        Assert.assertTrue(overFlowMenu.isDisplayed(), "Over Flow Menu not displayed");
        Assert.assertTrue(assignedTab.isDisplayed(), " Assigned tab not displayed");
        Assert.assertTrue(myInspectionsTab.isDisplayed(), "My Inspection tab not displayed");
        Assert.assertTrue(floatingBarcodeScannerButton.isDisplayed(), " Barcode Scanner floater not displayed");
    }

    public void verifyOnsiteTabNotPresent() {
        boolean isSiteTabPresent = driver.findElements(By.id("Site_tab")).size() > 0;
        Assert.assertFalse(isSiteTabPresent, "Site Tab should not be visible for Offsite users");
    }

    public void verifyHomePageElementsDisplayedForOnSiteUser() {
        overFlowMenu.click();
        clickOverflowMenuOptions("site settings");
        driver.findElement(By.xpath("//android.widget.TextView[@text=\"On Site\"]")).click();
        driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().text(\"OPENLANE Calgary\")")).click();
        siteTab.click();
        synchronizeByRefresh();
        Assert.assertTrue(siteTab.isDisplayed(), "Site tab not displayed");
        verifyHomePageElementsDisplayedForOffSiteUser();
    }

    public void tapSearchIconButton() {
        searchIconButton.click();
    }

    public void tapOverFlowMenu() {
        overFlowMenu.click();
    }

    public void tapAssignedTab() {
        assignedTab.click();
    }

    public void tapMyInspectionsTab() {
        myInspectionsTab.click();
    }

    public void tapSiteTab() {
        siteTab.click();
    }

    public void tapFilterIcon() {
        filterButton.click();
    }

    public void tapFloatingBarcodeScannerButton() {
        floatingBarcodeScannerButton.click();
    }

    public void clickOverflowMenuOptions(String optionTextLowerCase) {
        By dynamicLocator = By.xpath("//android.widget.TextView[contains(translate(@text, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz') , '" + optionTextLowerCase + "')]");
        driver.findElement(dynamicLocator).click();
    }

    public void verifyOverflowMenuOptions(String optionTextLowerCase) {
        By dynamicLocator = By.xpath("//android.widget.TextView[contains(translate(@text, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz') , '" + optionTextLowerCase + "')]");
        Assert.assertTrue(driver.findElement(dynamicLocator).isDisplayed(), optionTextLowerCase + " is not visible");
    }

    public List<String> getDetailsOfAssignedInspections() throws InterruptedException {
        String vehicleName1 = "//android.widget.TextView[@resource-id=\"com.openlane.autohawk.uat:id/titleTextView\"]";
        String vehicleColorAndVin1 = "//android.widget.TextView[@resource-id=\"com.openlane.autohawk.uat:id/detailTextView\"]";

        boolean isVehicleNameVisible = false;
        boolean isVehicleColorAndVinVisible = false;
        try {
            isVehicleNameVisible = driver.findElement(By.xpath(vehicleName1)).isDisplayed();
        } catch (Exception e) {
            System.out.println("Vehicle Name not visible " + e.getMessage());
        }
        try {
            isVehicleColorAndVinVisible = driver.findElement(By.xpath(vehicleColorAndVin1)).isDisplayed();
        } catch (Exception e) {
            System.out.println("Color and Vin not visible " + e.getMessage());
        }

        if (!isVehicleNameVisible && !isVehicleColorAndVinVisible) {
            System.out.println("Inspections details not found ");
            return Collections.emptyList();
        }

        List<String> vehicleName = actions.getAllUniqueVisibleTexts(Collections.singletonList(By.xpath(vehicleName1)));
        actions.swipeUntilEnd("down");
        List<String> vehicleColorAndVin = actions.getAllUniqueVisibleTexts(Collections.singletonList(By.xpath(vehicleColorAndVin1)));

        int size = Math.min(vehicleName.size(), vehicleColorAndVin.size());
        List<String> finalOutput = new ArrayList<>();
        System.out.println(size);

        for (int i = 0; i < size; i++) {
            finalOutput.add(vehicleName.get(i));
            finalOutput.add(vehicleColorAndVin.get(i));
        }
        return finalOutput;
    }

    public String initiateAndVerifyInspectionThroughVinValidationUsingInputFromAssignedTab() {
        By vehicleLocator = By.xpath("(//android.widget.TextView[@resource-id=\"com.openlane.autohawk.uat:id/titleTextView\"])[5]");
        By extractVinDetails = By.xpath("(//android.widget.TextView[@resource-id=\"com.openlane.autohawk.uat:id/detailTextView\"])[5]");
        By typeVinButton = AppiumBy.androidUIAutomator("new UiSelector().text(\"Type VIN\")");
        By vinInputField = AppiumBy.androidUIAutomator("new UiSelector().className(\"android.widget.EditText\")");
        By vinValidationButton = AppiumBy.androidUIAutomator("new UiSelector().text(\"VALIDATE\")");

        String extractVinNumber = driver.findElement(extractVinDetails).getText();

        String vinRegex = "\\b[0-9A-Z]{17}\\b";

        Pattern pattern = Pattern.compile(vinRegex);
        Matcher matcher = pattern.matcher(extractVinNumber);
        String vinNumber = null;
        if (matcher.find()) {
            vinNumber = matcher.group(); // Extract the VIN
        } else {
            throw new IllegalArgumentException("No valid VIN found in the extracted text: " + extractVinNumber);
        }

        WebElement vehicleLocatorEle = driver.findElement(vehicleLocator);
        generic.waitForVisibility(vehicleLocatorEle).click();

        WebElement typeVinButtonEle = driver.findElement(typeVinButton);
        generic.waitForVisibility(typeVinButtonEle).click();

        WebElement vinInputFieldEle = driver.findElement(vinInputField);
        generic.waitForVisibility(vinInputFieldEle).sendKeys(vinNumber);

        WebElement vinValidationButtonEle = driver.findElement(vinValidationButton);
        generic.waitForVisibility(vinValidationButtonEle).click();

        if (generic.isElementVisible(inProgressInspectionResumeButton)) {
            generic.waitForVisibility(inProgressInspectionResumeButton).click();
        } else {
            log.info("No popups appeared");
        }
        return vinNumber;

    }

    public String initiateInspectionFromSiteTab() {
        WebElement vehicleLocator = driver.findElement(By.xpath("(//android.widget.TextView[@resource-id=\"com.openlane.autohawk.uat:id/titleTextView\"])[1]"));
        WebElement vinLocator = driver.findElement(By.xpath("(//android.widget.TextView[@resource-id=\"com.openlane.autohawk.uat:id/detailTextView\"])[1]"));

        String vinRegex = "\\b[0-9A-Z]{17}\\b";
        String extractVinNumber = vinLocator.getText();
        Pattern pattern = Pattern.compile(vinRegex);
        Matcher matcher = pattern.matcher(extractVinNumber);
        String vinNumber = null;
        if (matcher.find()) {
            vinNumber = matcher.group(); // Extract the VIN
        } else {
            throw new IllegalArgumentException("No valid VIN found in the extracted text: " + extractVinNumber);
        }

        generic.waitForVisibility(siteTab).click();
        generic.waitForVisibility(vehicleLocator).click();
        if (generic.isElementVisible(inProgressInspectionResumeButton)) {
            generic.waitForVisibility(inProgressInspectionResumeButton).click();

        } else {
            log.info("No popups appeared");
        }
        return vinNumber;
    }

    public void selectInspectionByIndex(String index) {
        WebElement vehicleLocator = driver.findElement(By.xpath("(//android.widget.TextView[@resource-id=\"com.openlane.autohawk.uat:id/titleTextView\"])[" + index + "]"));
        generic.waitForVisibility(vehicleLocator).click();
    }

    public void resumeInspection() {
        generic.waitForVisibility(inProgressInspectionResumeButton).click();
    }

    public void cancelInspection() {
        generic.waitForVisibility(inProgressInspectionCancelButton).click();
    }

    public void selectClearReselectApplyFilters() {
        filterButton.click();
        try {
            // Wait for filter checkboxes to appear
            List<WebElement> allFilterOptions = driver.findElements(
                    By.xpath("//android.widget.CheckBox[@resource-id=\"com.openlane.autohawk.uat:id/cb_control\"]")
            );
            if (allFilterOptions.isEmpty()) {
                log.info("No filter options available.");
                return;
            }
            // Select the first checkbox (Select All)
            WebElement selectAllCheckBox = allFilterOptions.get(0);
            selectAllCheckBox.click();
            clearFilterButton.click();
            log.info("selected all checkboxes and cleared the filters");

            // Refresh the list after clear
            allFilterOptions = driver.findElements(
                    By.xpath("//android.widget.CheckBox[@resource-id=\"com.openlane.autohawk.uat:id/cb_control\"]")
            );

            if (allFilterOptions.size() == 1) {
                WebElement onlyCheckbox = allFilterOptions.get(0);
                if (!onlyCheckbox.isSelected()) {
                    generic.waitForVisibility(onlyCheckbox).click();
                    log.info("Only one filter found and selected");
                }
                if (applyFilterButton.isEnabled()) {
                    generic.waitForVisibility(applyFilterButton).click();
                    log.info("Applied selected filter for only single filter.");
                } else {
                    log.warn("Apply button was disabled – maybe no filters selected?");
                }
                return;
            }

            // Select the checkboxes
            log.info("Found " + allFilterOptions.size() + " filter options");
            for (int i = 1; i < Math.min(4, allFilterOptions.size()); i++) {
                WebElement checkbox = allFilterOptions.get(i);
                if (!checkbox.isSelected()) {
                    generic.waitForVisibility(checkbox).click();
                    log.info(allFilterOptions.get(i).getText() + " checkbox selected");
                }
            }
            log.info("Re-selected checkbox");

            // Click the apply button
            if (applyFilterButton.isEnabled()) {
                generic.waitForVisibility(applyFilterButton).click();
                log.info("Applied selected filters.");
            } else {
                log.warn("Apply button was disabled – maybe no filters selected?");
            }
        } catch (Exception e) {
            log.error("Error in selecting filters: " + e.getMessage());
            throw new RuntimeException(e);
        }
    }

    public void inspectionUsingSearchBar(String inspectionName) {
        generic.waitForVisibility(searchIconButton).click();
        generic.waitForVisibility(searchTextBox).clear();
        generic.waitForVisibility(searchTextBox).sendKeys(inspectionName);
        try {
            By searchResult = (By.xpath("(//android.widget.LinearLayout[@resource-id=\"com.openlane.autohawk.uat:id/rowFG\"])"));
            List<WebElement> searchResults = driver.findElements(searchResult);
            if (searchResults.isEmpty()) {
                log.info("No search results found for the given search term: " + inspectionName);
            } else {
                WebElement searchResultShown = searchResults.get(0);
                searchResultShown.click();
                log.info("Inspection found for the given search term ");
            }
        } catch (Exception e) {
            log.error("Search result not found: " + e.getMessage());
            throw new RuntimeException(e);
        }

    }

    public void initiateInspectionUsingVinFromSearchBar(String VINNumber) {
        generic.waitForVisibility(searchIconButton).click();
        generic.waitForVisibility(searchTextBox).clear();
        generic.waitForVisibility(searchTextBox).sendKeys(VINNumber);

        List<WebElement> searchResults = driver.findElements(By.className("android.widget.TextView"));
        if (!searchResults.isEmpty()) {
            //  for (WebElement result : searchResults) {
            //    if (result.getText().contains(VINNumber)) {
            driver.findElement(By.className("android.widget.Button")).click();
            log.info("Inspection found for the given VIN number: " + VINNumber);
            //    }
            //  }
        } else {
            log.info("No search results found for the given VIN number: " + VINNumber);
        }

        By typeVinButton = AppiumBy.androidUIAutomator("new UiSelector().text(\"Type VIN\")");
        By vinInputField = AppiumBy.androidUIAutomator("new UiSelector().className(\"android.widget.EditText\")");
        By vinValidationButton = AppiumBy.androidUIAutomator("new UiSelector().text(\"VALIDATE\")");

        WebElement typeVinButtonEle = driver.findElement(typeVinButton);
        generic.waitForVisibility(typeVinButtonEle).click();

        WebElement vinInputFieldEle = driver.findElement(vinInputField);
        generic.waitForVisibility(vinInputFieldEle).sendKeys(VINNumber);

        WebElement vinValidationButtonEle = driver.findElement(vinValidationButton);
        generic.waitForVisibility(vinValidationButtonEle).click();

        if (generic.isElementVisible(inProgressInspectionResumeButton)) {
            generic.waitForVisibility(inProgressInspectionResumeButton).click();
        } else {
            log.info("No popups appeared");
        }


    }


}


