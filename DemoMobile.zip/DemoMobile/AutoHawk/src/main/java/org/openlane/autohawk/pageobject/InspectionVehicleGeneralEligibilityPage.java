package org.openlane.autohawk.pageobject;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.pagefactory.*;
import org.openlane.autohawk.utils.AndroidActions;
import org.openlane.autohawk.utils.AppiumGeneric;
import org.openlane.autohawk.utils.ApplicationGeneric;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;

@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSXCUITAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
public class InspectionVehicleGeneralEligibilityPage {
    AppiumDriver driver;
    AppiumGeneric generic;
    AndroidActions actions;
    ApplicationGeneric appGeneric;
    private static final Logger log = LoggerFactory.getLogger(InspectionVehicleGeneralEligibilityPage.class);

    public InspectionVehicleGeneralEligibilityPage(AppiumDriver driver) {
        this.driver = driver;
        this.generic = new AppiumGeneric();
        this.generic.setDriver(driver);
        this.actions = new AndroidActions(driver);
        this.appGeneric = new ApplicationGeneric(driver);
        PageFactory.initElements(new AppiumFieldDecorator(driver, Duration.ofSeconds(10)), this);
    }

    //Defining locators

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/tv_title_extra_photo"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/tv_title_extra_photo")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement vehicleGeneralEligibilityTitle;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/btn_next_section"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/btn_next_section")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement mechanicalButton;

    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@text , \"Odometer Reading\")]")
    @iOSXCUITFindBy(id = "")
    private WebElement textInputOdometerReading;

    @AndroidFindBy(xpath = "(//android.widget.EditText)[1]")
    @iOSXCUITFindBy(id = "")
    private WebElement textInputMileageReading;

    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@text , \"Stock Number\")]")
    @iOSXCUITFindBy(id = "")
    private WebElement textInputStockNumber;

    public void verifyVehicleGeneralEligibilityTitle() {
        String expectedTitle1 = "Vehicle / General Eligibility";
        String expectedTitle2 = "General Eligibility";
        String expectedTitle3 = "Vehicle";
        String actualTitle = vehicleGeneralEligibilityTitle.getText();
        Assert.assertTrue(
                actualTitle.equals(expectedTitle1) || actualTitle.equals(expectedTitle2) || actualTitle.equals(expectedTitle3),
                "Vehicle / General Eligibility title is not matching"
        );
        log.info("Vehicle / General Eligibility title is verified successfully: " + actualTitle);
    }

    public void verifyGeneralEligibilitySectionHyundai() {
        List<String> items = Arrays.asList(
                "Vehicle not more than 5 years from current year (not more than 2017 in 2022, not more than 2018 in 2023)*",
                "Vehicle has less than 80,000 miles*"
        );

        for (String item : items) {
            appGeneric.swipeToCenter(item);
            String details = appGeneric.handleButtonSelection(item, null);
            log.info("For the question : {} selected option: {}", item, details);
        }

        generic.waitForVisibility(textInputOdometerReading).clear();
        generic.waitForVisibility(textInputOdometerReading).click();
        generic.waitForVisibility(textInputOdometerReading).sendKeys("544321");
        AndroidDriver androidDriver = (AndroidDriver) driver;
        androidDriver.pressKey(new KeyEvent(AndroidKey.ENTER));
        log.info("Odometer Reading is entered successfully.");

        appGeneric.handleDropDownSelection("Odometer Scale*", "Miles", null);

    }

    public void verifyGeneralEligibilitySectionToyota() {
        List<String> items = Arrays.asList(
                "Vehicle is current model year or ten (10) years back.*",
                "Vehicle must have less than 125,000 miles.*"
        );

        for (String item : items) {
            appGeneric.swipeToCenter(item);
            String details = appGeneric.handleButtonSelection(item, null);
            log.info("For the question : {} selected option: {}", item, details);
        }

        generic.waitForVisibility(textInputMileageReading).clear();
        generic.waitForVisibility(textInputMileageReading).click();
        generic.waitForVisibility(textInputMileageReading).sendKeys("544321");
        AndroidDriver androidDriver = (AndroidDriver) driver;
        androidDriver.pressKey(new KeyEvent(AndroidKey.ENTER));
        log.info("Odometer Reading is entered successfully.");

        appGeneric.handleDropDownSelection("Odometer Scale*", "Miles", null);

    }

    public void verifyVehicleSectionGulfState() {
        // for odometer details
        generic.waitForVisibility(textInputOdometerReading).clear();
        generic.waitForVisibility(textInputOdometerReading).click();
        generic.waitForVisibility(textInputOdometerReading).sendKeys("544321");
        AndroidDriver androidDriver = (AndroidDriver) driver;
        androidDriver.pressKey(new KeyEvent(AndroidKey.ENTER));
        log.info("Odometer Reading is entered successfully.");

        // for odometer scale dropdown
        appGeneric.handleDropDownSelection("Odometer Scale*", "Miles", null);
        log.info("Odometer scale is selected successfully.");

        // for stock number details
        generic.waitForVisibility(textInputStockNumber).clear();
        generic.waitForVisibility(textInputStockNumber).click();
        generic.waitForVisibility(textInputStockNumber).sendKeys("123456789");
        androidDriver.pressKey(new KeyEvent(AndroidKey.ENTER));
        log.info("Stock Number is entered successfully.");
    }

    public void verifyVehicleSectionMercedesBenz() {
        // for odometer details
        generic.waitForVisibility(textInputMileageReading).clear();
        generic.waitForVisibility(textInputMileageReading).click();
        generic.waitForVisibility(textInputMileageReading).sendKeys("544321");
        AndroidDriver androidDriver = (AndroidDriver) driver;
        androidDriver.pressKey(new KeyEvent(AndroidKey.ENTER));
        log.info("Mileage Reading is entered successfully.");

        // for odometer scale dropdown
        appGeneric.handleDropDownSelection("Odometer Scale*", "Miles", null);
        log.info("Odometer scale is selected successfully.");

        // for primary Exterior color
        appGeneric.handleDropDownSelection("Primary Exterior Color*", "Black", null);
        log.info("Primary Exterior Color is selected successfully.");
    }

    public void verifyVehicleInfoSectionLexus() {
        // for odometer details
        generic.waitForVisibility(textInputMileageReading).clear();
        generic.waitForVisibility(textInputMileageReading).click();
        generic.waitForVisibility(textInputMileageReading).sendKeys("544321");
        AndroidDriver androidDriver = (AndroidDriver) driver;
        androidDriver.pressKey(new KeyEvent(AndroidKey.ENTER));
        log.info("Mileage Reading is entered successfully.");

        // for odometer scale dropdown
        appGeneric.handleDropDownSelection("Odometer Scale*", "Miles", null);
        log.info("Odometer scale is selected successfully.");

    }

    public void verifyGeneralEligibilitySectionGulfState() {
        String first = "Vehicle is older than six years*";
        String second = "Vehicle Has More Than 85,000 Miles*";
        try {
            appGeneric.swipeToCenter(first);
            WebElement button1 = driver.findElement(AppiumBy.xpath("//android.widget.TextView[contains(@text , \"Vehicle is older than six years*\")]/parent::android.widget.LinearLayout/following-sibling::android.widget.LinearLayout/child::android.widget.Button[1]"));
            button1.click();
        } catch (Exception staleElementReferenceException) {
            WebElement button1 = driver.findElement(AppiumBy.xpath("//android.widget.TextView[contains(@text , \"Vehicle is older than six years*\")]/parent::android.widget.LinearLayout/following-sibling::android.widget.LinearLayout/child::android.widget.Button[1]"));
            button1.click();
        }
        try {
            appGeneric.swipeToCenter(second);
            WebElement button2 = driver.findElement(AppiumBy.xpath("//android.widget.TextView[contains(@text , \"Vehicle Has More Than 85,000 Miles*\")]/parent::android.widget.LinearLayout/following-sibling::android.widget.LinearLayout/child::android.widget.Button[1]"));
            button2.click();
        } catch (Exception staleElementReferenceException) {
            WebElement button2 = driver.findElement(AppiumBy.xpath("//android.widget.TextView[contains(@text , \"Vehicle Has More Than 85,000 Miles*\")]/parent::android.widget.LinearLayout/following-sibling::android.widget.LinearLayout/child::android.widget.Button[1]"));
            button2.click();
        }

    }

    public void verifyGeneralEligibilitySectionLexus() {
        List<String> items = Arrays.asList(
                "Vehicle is current model year or six years back*",
                "Vehicle has less than 80,000 miles*",
                "Evidence of any frame / unibody damage (old, new, or repaired)*",
                "No evidence of substandard repairs on any panel. (Please include images and comments about the panels/repairs.)*",
                "Suspension / body mod (including non-oem spoilers, special flarings, aerodynamic kits, roof conversions, and lowered suspension)*",
                "No evidence of flood/water damage*",
                "There must be no evidence of oil sludge*"
        );

        for (String item : items) {
            appGeneric.swipeToCenter(item);
            String details = appGeneric.handleButtonSelection(item, null);
            log.info("For the question : {} selected option: {}", item, details);
        }


    }

    public void finalizeVehicleGeneralEligibilitySection() throws InterruptedException {
        actions.swipeUntilEnd("up");
        generic.waitForVisibility(mechanicalButton).click();
        log.info("Completed all sections of Vehicle / General Eligibility.");
    }

}
