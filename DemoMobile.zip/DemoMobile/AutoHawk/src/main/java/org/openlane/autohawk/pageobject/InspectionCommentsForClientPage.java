package org.openlane.autohawk.pageobject;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.*;
import org.openlane.autohawk.utils.AndroidActions;
import org.openlane.autohawk.utils.AppiumGeneric;
import org.openlane.autohawk.utils.ApplicationGeneric;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.time.Duration;

@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSXCUITAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
public class InspectionCommentsForClientPage {
    AppiumDriver driver;
    AppiumGeneric generic;
    AndroidActions actions;
    ApplicationGeneric appGeneric;
    private static final Logger log = LoggerFactory.getLogger(InspectionCommentsForClientPage.class);

    public InspectionCommentsForClientPage(AppiumDriver driver) {
        this.driver = driver;
        this.generic = new AppiumGeneric();
        this.generic.setDriver(driver);
        this.actions = new AndroidActions(driver);
        this.appGeneric = new ApplicationGeneric(driver);
        PageFactory.initElements(new AppiumFieldDecorator(driver, Duration.ofSeconds(10)), this);
    }

    //Defining locators

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/tv_title_extra_photo"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/tv_title_extra_photo")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement commentsForClientTitle;

    @AndroidFindBy(xpath = "(//android.widget.EditText)[1]")
    @iOSXCUITFindBy(id = "")
    private WebElement overallNotesInput;

    @AndroidFindBy(xpath = "(//android.widget.EditText)[2]")
    @iOSXCUITFindBy(id = "")
    private WebElement repNotesInput;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.test:id/btn_next_section"),
            @AndroidBy(id = "com.openlane.autohawk.uat:id/btn_next_section")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement doneButton;

    public void verifyCommentsForClientTitle() {
        String expectedTitle1 = "Comments for Client";
        String expectedTitle2 = "General Comments";
        String expectedTitle3 = "Comments";
        String actualTitle = commentsForClientTitle.getText();
        Assert.assertTrue(actualTitle.equals(expectedTitle1) || actualTitle.equals(expectedTitle2) || actualTitle.equals(expectedTitle3),
                "Comments for Client title is not matching");
        log.info("Comments for Client title is verified successfully: " + actualTitle);
    }

    public void verifyCommentInput() {
        if (overallNotesInput.getText().isEmpty()) {
            overallNotesInput.sendKeys("Overall Notes: This is a test comment for overall notes.");
            log.info("Overall Notes input is verified successfully.");
        } else {
            overallNotesInput.clear();
            overallNotesInput.sendKeys("Overall Notes: This is a test comment for overall notes.");
            log.info("Overall Notes input is cleared and new comment is entered.");
        }
        if (repNotesInput.getText().isEmpty()) {
            repNotesInput.sendKeys("Rep Notes: This is a test comment for rep notes.");
            log.info("Rep Notes input is verified successfully.");
        } else {
            repNotesInput.clear();
            repNotesInput.sendKeys("Rep Notes: This is a test comment for rep notes.");
            log.info("Rep Notes input is cleared and new comment is entered.");
        }

    }

    public void finalizeCommentsForClientSection() {
        generic.waitForVisibility(doneButton).click();
        log.info("Completed all sections of Comments for Client.");
    }

}
