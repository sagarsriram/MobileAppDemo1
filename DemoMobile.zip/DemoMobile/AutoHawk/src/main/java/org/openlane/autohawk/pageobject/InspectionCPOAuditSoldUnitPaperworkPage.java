package org.openlane.autohawk.pageobject;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.*;
import org.openlane.autohawk.utils.AndroidActions;
import org.openlane.autohawk.utils.AppiumGeneric;
import org.openlane.autohawk.utils.ApplicationGeneric;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;

@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSXCUITAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
public class InspectionCPOAuditSoldUnitPaperworkPage {
    AppiumDriver driver;
    AppiumGeneric generic;
    AndroidActions actions;
    ApplicationGeneric appGeneric;
    private static final Logger log = LoggerFactory.getLogger(InspectionCPOAuditSoldUnitPaperworkPage.class);

    public InspectionCPOAuditSoldUnitPaperworkPage(AppiumDriver driver) {
        this.driver = driver;
        this.generic = new AppiumGeneric();
        this.generic.setDriver(driver);
        this.actions = new AndroidActions(driver);
        this.appGeneric = new ApplicationGeneric(driver);
        PageFactory.initElements(new AppiumFieldDecorator(driver, Duration.ofSeconds(10)), this);
    }

    //Defining locators

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/tv_title_extra_photo"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/tv_title_extra_photo")

    })
    @iOSXCUITFindBy(id = "")
    private WebElement CPOAuditSoldUnitPaperworkTitle;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/btn_next_section"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/btn_next_section")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement imagesButton;

    public void verifyCPOAuditSoldUnitPaperWorkTitle() {
        String expectedTitle1 = "CPO Audit - Sold Unit Paperwork On File";
        String expectedTitle2 = "Sold Unit Paperwork on File";
        String actualTitle = CPOAuditSoldUnitPaperworkTitle.getText();
        Assert.assertTrue(
                actualTitle.equals(expectedTitle1) || actualTitle.equals(expectedTitle2),
                "CPO Audit Sold Unit Paperwork title is not matching"
        );
        log.info("CPO Audit - Sold Unit Paperwork On File title is verified successfully: " + actualTitle);
    }


    public void verifyCPOAuditMandatoryButtonOptions() {
        List<String> items = Arrays.asList(
                "Vehicle is older than six years*",
                "Vehicle Has More Than 85,000 Miles*",
                "Check sheet is missing (digital or paper copies acceptable)*",
                "Check sheet is not filled out completely and correctly (digital or paper copies acceptable)*",
                "Vehicle's inspection form is missing any required signatures (This excludes the detailer) (digital or paper copies acceptable)*",
                "Repair orders documenting required repairs are missing (digital or paper copies acceptable)*",
                "Repair orders match the checklist (digital or paper copies acceptable)*",
                "Vehicle history report (VHR) is missing (digital or paper copies acceptable)*",
                "Techstream health check is not complete or copy is missing from file (digital or paper copies acceptable)*"
        );

        for (String item : items) {
            appGeneric.swipeToCenter(item);
            appGeneric.handleButtonSelection(item, null);
        }
    }

    public void verifyPaperworkOnFileButtonOptionsToyotaSoldUnitYESGoldUnitYES() {
        List<String> items = Arrays.asList(
                "Vehicle is current model year or six (6) years back*",
                "Vehicle must have less than 85,000 Miles*",
                "Check sheet is missing  (digital or paper copies acceptable)*",
                "Check sheet is not filled out completely and correctly*",
                "Vehicle's inspection form is missing any required signatures (This excludes the detailer) (digital or paper copies acceptable)*",
                "Repair orders documenting required repairs are missing  (digital or paper copies acceptable)*",
                "Repair orders match the checklist  (digital or paper copies acceptable)*",
                "Vehicle history report (VHR) is missing  (digital or paper copies acceptable)*"
        );

        for (String item : items) {
            appGeneric.swipeToCenter(item);
            appGeneric.handleButtonSelection(item, null);
        }
    }

    public void verifyPaperworkOnFileButtonOptionsToyotaSoldUnitYESGoldUnitNO() {
        List<String> items = Arrays.asList(
                "Vehicle is current model year or ten (10) years back*",
                "Vehicle must have less than 125,000 Miles*",
                "Check sheet is missing  (digital or paper copies acceptable)*",
                "Check sheet is not filled out completely and correctly*",
                "Vehicle's inspection form is missing any required signatures (This excludes the detailer) (digital or paper copies acceptable)*",
                "Repair orders documenting required repairs are missing  (digital or paper copies acceptable)*",
                "Repair orders match the checklist  (digital or paper copies acceptable)*",
                "Vehicle history report (VHR) is missing  (digital or paper copies acceptable)*"
        );

        for (String item : items) {
            appGeneric.swipeToCenter(item);
            appGeneric.handleButtonSelection(item, null);
        }
    }

    public void verifySoldUnitPaperworkButtonOptionsMercedesBenz() {
        List<String> items = Arrays.asList(
                "Vehicle Is Older Than Six (6) Calendar Years*",
                "Vehicle Has More Than 75,000 Miles*",
                "MBCPO ICR in deal jacket or stored electronically with date and signature (digital or paper copies acceptable)*",
                "MBCPO ICR in deal jacket or stored electronically Is Not Filled Out Completely and/or Correctly (digital or paper copies acceptable)*",
                "Copy of RO in deal jacket or stored electronically with date and signature (digital or paper copies acceptable)*",
                "Missing Vehicle History Report (VHR)- Carfax (digital or paper copies acceptable)*",
                "Discrepancy found in Carfax report (digital or paper copies acceptable)*",
                "Identifiable Structural Damage as documented in CARFAX report. (digital or paper copies acceptable)*",
                "EV Vehicles only - Evaluation Log for High-Voltage Battery in deal jacket where applicable*",
                "Battery Capacacity % greater than or equal to 70% as noted on the Evlauation Log for High Voltage Battery where applicable for full electric models*",
                "MBCPO Bill of Sale in deal jacket or stored electronically with date and signature (digital or paper copies acceptable)*",
                "MBCPO Bill of Sale in deal jacket or stored electronically Is Not Filled Out Completely and/or Correctly (digital or paper copies acceptable)*",
                "Ultimate DDR - Is buyer listed the end consumer by indivual name (should not be corporate entity/reseller/wholesaler/rental agent, leasing entity, rideshare etc.)*",
                "Sold date on purchase order is after or the same as the ICR date*"
        );

        for (String item : items) {
            appGeneric.swipeToCenter(item);
            String details = appGeneric.handleButtonSelection(item, null);
            log.info("For the question : {} selected option: {}", item, details);
        }
    }

    public void finalizeCPOAuditSoldUnitPaperworkSection() throws InterruptedException {
        actions.swipeUntilEnd("up");
        generic.waitForVisibility(imagesButton).click();
        log.info("Completed all sections of CPO Audit - Sold Unit Paperwork.");
    }

}
