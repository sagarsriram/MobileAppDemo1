package org.openlane.autohawk.pageobject;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.*;
import org.openlane.autohawk.utils.AppiumGeneric;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSXCUITAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
public class GetHelpPage {
    AppiumDriver driver;
    AppiumGeneric generic;

    private static final Logger log = LoggerFactory.getLogger(GetHelpPage.class);

    public GetHelpPage(AppiumDriver driver) {
        this.driver = driver;
        this.generic = new AppiumGeneric();
        this.generic.setDriver(driver);
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }

    /*
    Defining locators
     */
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Ask us anything, or share your feedback.\")")
    @iOSXCUITFindBy(id = "")
    private WebElement getHelpSubTitle;

    @AndroidFindBy(xpath = "//android.widget.EditText[@contains,\"Current Site\"]")
    @iOSXCUITFindBy(id = "")
    private WebElement textInput;

    @AndroidFindBy(accessibility = "Gallery")
    @iOSXCUITFindBy(id = "")
    private WebElement galleryButton;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Gallery\")")
    @iOSXCUITFindBy(id = "")
    private WebElement gallery;

    @AndroidFindBy(xpath = "//android.view.View[contains(@content-desc, \"GIF taken\")]")
    @iOSXCUITFindBy(id = "")
    private WebElement selectGIF;

    @AndroidFindBy(xpath = "(//android.view.View[contains(@content-desc, \"Photo taken\")])[1]")
    @iOSXCUITFindBy(id = "")
    private WebElement selectPhoto;

    @AndroidFindAll({
            @AndroidBy(accessibility = "Send"),
            @AndroidBy(uiAutomator = "new UiSelector().className(\"android.widget.Button\").instance(1)")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement sendButton;


    /*
    Defining actions
     */

    public void verifyGetHelpSubTitle() {
        Assert.assertTrue(getHelpSubTitle.isDisplayed(), "Subtitle not matched");
    }

    public void uploadGif() {
        generic.waitForVisibility(galleryButton).click();
        gallery.click();
        selectGIF.click();
        sendButton.click();
    }

    public void uploadPhoto() {
        galleryButton.click();
        gallery.click();
        selectPhoto.click();
        sendButton.click();
    }

    public void sendMessage() {
        textInput.sendKeys("Testing");
        sendButton.click();
    }


}


