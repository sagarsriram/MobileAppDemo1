package org.openlane.autohawk.pageobject;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.*;
import org.openlane.autohawk.utils.AndroidActions;
import org.openlane.autohawk.utils.AppiumGeneric;
import org.openlane.autohawk.utils.ApplicationGeneric;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.time.Duration;
import java.util.Set;

@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSXCUITAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
public class InspectionLeftExteriorPage {
    AppiumDriver driver;
    AppiumGeneric generic;
    AndroidActions actions;
    ApplicationGeneric appGeneric;
    private static final Logger log = LoggerFactory.getLogger(InspectionLeftExteriorPage.class);

    public InspectionLeftExteriorPage(AppiumDriver driver) {
        this.driver = driver;
        this.generic = new AppiumGeneric();
        this.generic.setDriver(driver);
        this.actions = new AndroidActions(driver);
        this.appGeneric = new ApplicationGeneric(driver);
        PageFactory.initElements(new AppiumFieldDecorator(driver, Duration.ofSeconds(10)), this);
    }

    //Defining locators

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/tv_title_extra_photo"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/tv_title_extra_photo")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement leftExteriorScreenTitle;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Tire Brand*\")")
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryTireBrandDropdown;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Tire Width*\")")
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryTireWidthDropdown;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Aspect Ratio*\")")
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryAspectRatioDropdown;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Wheel Diameter*\")")
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryWheelDiameterDropdown;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Speed Rating*\")")
    @iOSXCUITFindBy(id = "")
    private WebElement mandatorySpeedRatingDropdown;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Tread Depth*\")")
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryTreadDepthDropdown;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/iv_back"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/iv_back")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement appBackButton;

    @AndroidFindBy(xpath = "//android.widget.TextView[contains (@text, \"LF Tire\")]/following-sibling::android.widget.ImageView")
    @iOSXCUITFindBy(id = "")
    private WebElement damageButtonLFTireWheel;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/btn_next_section"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/btn_next_section")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement rearExteriorButton;

    @AndroidFindBy(xpath = "//android.widget.TextView[contains (@text, \"Interior Doors\")]/following-sibling::android.widget.ImageView")
    @iOSXCUITFindBy(id = "")
    private WebElement interiorDoorsRearDamageButton;

    //Defining methods

    public void verifyLeftExteriorScreenTitle() {
        String expectedTitle = "Left Exterior";
        String actualTitle = generic.waitForVisibility(leftExteriorScreenTitle).getText();
        Assert.assertEquals(actualTitle, expectedTitle, "Left Exterior screen title is not matching");
        log.info("Left Exterior screen title is verified successfully");
    }

    public void handleDropDownSelection(String dropdownText, String selectionText, WebElement sectionTitleName) {
        try {
            // Locate and validate the dropdown
            WebElement dropDownValidation = driver.findElement(By.xpath("//android.widget.TextView[@resource-id=\"com.openlane.autohawk.uat:id/titleText\" and @text=\"" + dropdownText + "\"]/following-sibling::android.widget.TextView[@resource-id=\"com.openlane.autohawk.uat:id/selectionText\"]"));
            if (generic.isElementVisible(dropDownValidation)) {
                log.info("{} already selected: {}", dropdownText, dropDownValidation.getText());
                return;
            }
        } catch (Exception e) {
            log.info("Dropdown validation processing for : {}", dropdownText);
        }

        try {
            // Check and interact with the mandatory dropdown
            if (dropdownText.equals(sectionTitleName.getText())) {
                generic.waitForVisibility(sectionTitleName).click();
                WebElement dropDownPicker = driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().text(\"" + selectionText + "\")"));
                if (dropDownPicker.isDisplayed()) {
                    dropDownPicker.click();
                    By titleLocator = AppiumBy.id("com.openlane.autohawk.uat:id/tv_title");
                    try {
                        WebElement title = driver.findElement(titleLocator);
                        if (!title.getText().equals(dropdownText.substring(0, dropdownText.length() - 1))) {
                            log.info("going back");
                            appBackButton.click();
                        } else {
                            log.info("continuing... dropdown selection");
                        }
                    } catch (Exception e) {
                        log.info("Title not found, continuing with dropdown selection");
                    }
                    log.info("Selected {} type: {}", dropdownText, dropDownPicker.getText());
                } else {
                    log.warn("Selected {} option not found", dropdownText);
                    throw new IllegalStateException("Vehicle source type option not found");
                }
            }
        } catch (NoSuchElementException e) {
            log.error("Dropdown or {} option not found", dropdownText, e);
            throw e;
        } catch (Exception e) {
            log.error("Unexpected error while interacting with the {} dropdown", dropdownText, e);
            throw e;
        }
    }

    public void verifyMandatoryLFTireOrWheelsDropdowns() {
        handleDropDownSelection("Tire Brand*", "Continental", mandatoryTireBrandDropdown);
        handleDropDownSelection("Tire Width*", "235", mandatoryTireWidthDropdown);
        handleDropDownSelection("Aspect Ratio*", "55", mandatoryAspectRatioDropdown);
        handleDropDownSelection("Wheel Diameter*", "18\\\"", mandatoryWheelDiameterDropdown);
        handleDropDownSelection("Speed Rating*", "H", mandatorySpeedRatingDropdown);
        actions.swipe("up");
        handleDropDownSelection("Tread Depth*", "6/32\\\"", mandatoryTreadDepthDropdown);

    }

    public void verifyMandatoryLRTireOrWheelDropDowns() {
        By subTitleLocator = By.xpath("//android.widget.TextView[contains(@text, 'LR Tire/Wheel*')]");
        actions.swipeUntilVisibleAndCenter(subTitleLocator);
        actions.scrollElementToCenter(mandatoryTireBrandDropdown);
        handleDropDownSelection("Tire Brand*", "Continental", mandatoryTireBrandDropdown);
        actions.scrollElementToCenter(mandatoryTireWidthDropdown);
        handleDropDownSelection("Tire Width*", "235", mandatoryTireWidthDropdown);
        actions.scrollElementToCenter(mandatoryAspectRatioDropdown);
        handleDropDownSelection("Aspect Ratio*", "55", mandatoryAspectRatioDropdown);
        actions.scrollElementToCenter(mandatoryWheelDiameterDropdown);
        handleDropDownSelection("Wheel Diameter*", "18\\\"", mandatoryWheelDiameterDropdown);
        actions.scrollElementToCenter(mandatorySpeedRatingDropdown);
        handleDropDownSelection("Speed Rating*", "H", mandatorySpeedRatingDropdown);
        actions.scrollElementToCenter(mandatoryTreadDepthDropdown);
        handleDropDownSelection("Tread Depth*", "6/32\\\"", mandatoryTreadDepthDropdown);

    }

    public void verifyMandatoryLeftRearThreeQuartersPhoto() {
        By subTitleLocator = By.xpath("//android.widget.TextView[contains(@text, 'Left Rear 3/4 Photo')]");
        actions.swipeUntilVisibleAndCenter(subTitleLocator);
        appGeneric.handlePhotoSelection("Left Rear 3/4 Photo");
    }

    public void verifyMandatoryLeftExterior() {
        appGeneric.handlePhotoSelection("Motor - Left (Clutch Side)");
    }

    public void finalizeLeftExteriorSection() throws InterruptedException {
        actions.swipeUntilEnd("up");
        generic.waitForVisibility(rearExteriorButton).click();
        log.info("completed all mandatory sections of Left Exterior section");
    }

    public void addDamageLFTireWheel() {
        damageButtonLFTireWheel.click();
        log.info("Clicked on LFTire/Wheel damage button");
        appGeneric.addDamage();
    }

}
