package org.openlane.autohawk.pageobject;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.*;
import org.openlane.autohawk.utils.AndroidActions;
import org.openlane.autohawk.utils.AppiumGeneric;
import org.openlane.autohawk.utils.ApplicationGeneric;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;

@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSXCUITAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
public class InspectionImagesPage {
    AppiumDriver driver;
    AppiumGeneric generic;
    AndroidActions actions;
    ApplicationGeneric appGeneric;
    private static final Logger log = LoggerFactory.getLogger(InspectionImagesPage.class);

    public InspectionImagesPage(AppiumDriver driver) {
        this.driver = driver;
        this.generic = new AppiumGeneric();
        this.generic.setDriver(driver);
        this.actions = new AndroidActions(driver);
        this.appGeneric = new ApplicationGeneric(driver);
        PageFactory.initElements(new AppiumFieldDecorator(driver, Duration.ofSeconds(10)), this);
    }

    //Defining locators
    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/tv_title_extra_photo"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/tv_title_extra_photo")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement imagesTitle;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/btn_next_section"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/btn_next_section")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement commentsForClientButton;

    public void verifyImagesTitle() {
        String expectedTitle1 = "Images";
        String expectedTitle2 = "Required Images";
        String actualTitle = imagesTitle.getText();
        Assert.assertTrue(
                actualTitle.equals(expectedTitle1) || actualTitle.equals(expectedTitle2),
                "Images title is not matching"
        );
        log.info("Images title is verified successfully: " + actualTitle);
    }

    public void verifyRequiredImagesToyotaSoldUnitYESAndGoldUnitSelected() {
        List<String> items = Arrays.asList(
                "CPO Checksheet",
                "Vehicle History Report",
                "Repair Orders"
        );
        for (String item : items) {
            appGeneric.swipeToCenter(item);
            appGeneric.handlePhotoSelection(item);
        }
    }

    public void verifyRequiredImagesToyotaSoldUnitNOAndGoldUnitSelected() {
        List<String> items = Arrays.asList(
                "VIN Sticker Photo",
                "Odometer Photo",
                "Front Interior Photo",
                "Left Front 3/4 Photo",
                "CPO Window Label"
        );
        for (String item : items) {
            appGeneric.swipeToCenter(item);
            appGeneric.handlePhotoSelection(item);
        }
    }

    public void verifyRequiredImagesGulfStateSoldUnitNo() {
        List<String> items = Arrays.asList(
                "Left Front 3/4 View*",
                "VIN*",
                "Odometer*",
                "CPO Certification Label*",
                "Front Interior*",
                "Baseline Paint Gauge*",
                "Left Front Wheel/Tire Photo*",
                "Left Rear Wheel/ Tire Photo*",
                "Right Rear Wheel/ Tire Photo*",
                "Right Front Wheel/ Tire Photo*"
        );
        for (String item : items) {
            appGeneric.swipeToCenter(item);
            appGeneric.handlePhotoSelection(item);
        }
    }

    public void verifyRequiredImagesHyundaiSoldUnitYES() {
        List<String> items = Arrays.asList(
                "CPO Checksheet",
                "Repair Orders",
                "Vehicle History Report"

        );
        for (String item : items) {
            appGeneric.swipeToCenter(item);
            appGeneric.handlePhotoSelection(item);
        }
    }

    public void verifyRequiredImagesHyundaiSoldUnitNO() {
        List<String> items = Arrays.asList(
                "VIN",
                "CPO Display Area",
                "Front Interior",
                "FTC Window Label",
                "Left Front 3/4 View",
                "Monroney Label",
                "Odometer",
                "Tire Specification Sticker"

        );
        for (String item : items) {
            appGeneric.swipeToCenter(item);
            appGeneric.handlePhotoSelection(item);
        }
    }

    public void verifyRequiredImagesLexus() {
        List<String> items = Arrays.asList(
                "Left Front 3/4 Photo",
                "VIN Sticker Photo",
                "Odometer Photo",
                "Permanent Certification Insignia",
                "CPO Certification Label",
                "CPO Certified Window Label",
                "Front Interior Photo"
        );
        for (String item : items) {
            appGeneric.swipeToCenter(item);
            appGeneric.handlePhotoSelection(item);
        }
    }

    public void verifyRequiredImagesMercedesBenzSoldUnitYES() {
        List<String> items = Arrays.asList(
                "CPO Checksheet",
                "Vehicle History Report",
                "Repair Orders"
        );
        for (String item : items) {
            appGeneric.swipeToCenter(item);
            appGeneric.handlePhotoSelection(item);
        }
    }

    public void verifyRequiredImagesMercedesBenzSoldUnitNO() {
        List<String> items = Arrays.asList(
                "VIN Sticker Photo",
                "Odometer Photo",
                "Front Interior Photo",
                "Left Front 3/4 Photo",
                "Repair Orders"
        );
        for (String item : items) {
            appGeneric.swipeToCenter(item);
            appGeneric.handlePhotoSelection(item);
        }
    }

    public void verifyRequiredImagesHarleyDavidson() {
        List<String> items = Arrays.asList(
                "VIN Sticker Photo*",
                "Odometer Photo*",
                "Left Side Photo*",
                "Front Photo*",
                "Right Side Photo*",
                "Rear Photo*",
                "Engine Photo*"
        );
        for (String item : items) {
            appGeneric.swipeToCenter(item);
            appGeneric.handlePhotoSelection(item);
        }
    }

    public void finalizeImagesSection() throws InterruptedException {
        actions.swipeUntilEnd("up");
        generic.waitForVisibility(commentsForClientButton).click();
        log.info("Completed all sections of Comments for Client.");
    }

}
