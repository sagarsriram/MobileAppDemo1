package org.openlane.autohawk.pageobject;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.*;
import org.openlane.autohawk.utils.AndroidActions;
import org.openlane.autohawk.utils.AppiumGeneric;
import org.openlane.autohawk.utils.ApplicationGeneric;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;

@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSXCUITAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
public class InspectionComplianceRequirementsPage {
    AppiumDriver driver;
    AppiumGeneric generic;
    AndroidActions actions;
    ApplicationGeneric appGeneric;
    private static final Logger log = LoggerFactory.getLogger(InspectionComplianceRequirementsPage.class);

    public InspectionComplianceRequirementsPage(AppiumDriver driver) {
        this.driver = driver;
        this.generic = new AppiumGeneric();
        this.generic.setDriver(driver);
        this.actions = new AndroidActions(driver);
        this.appGeneric = new ApplicationGeneric(driver);
        PageFactory.initElements(new AppiumFieldDecorator(driver, Duration.ofSeconds(10)), this);
    }

    //Defining locators
    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/tv_title_extra_photo"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/tv_title_extra_photo")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement complianceRequirementsTitle;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/btn_next_section"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/btn_next_section")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement finalizeComplianceRequirementsButton;

    public void verifyTitleComplianceRequirements() {
        String expectedTitle = "Compliance Requirements";
        String actualTitle = complianceRequirementsTitle.getText();
        Assert.assertEquals(actualTitle, expectedTitle, "Compliance Requirements title is not matching");
        log.info("Compliance Requirements title is verified successfully: " + actualTitle);
    }

    public void verifyComplianceRequirementsButtonOptions() {
        List<String> items = Arrays.asList(
                "Identifiable Structural Damage as documented in CARFAX report (digital or paper copies acceptable).*",
                "TMU/Vehicle Mileage history above or equal to stated mileage.*",
                "Vehicle Is Older Than Six (6) Calendar Years*",
                "Discrepancy found in Carfax report (digital or paper copies acceptable)*",
                "MBCPO ICR in deal jacket or stored electronically with date and signature (digital or paper copies acceptable)*",
                "EV Vehicles only - Evaluation Log for High-Voltage Battery in deal jacket where applicable *",
                "Battery Capacacity % greater than or equal to 70% as noted on the Evlauation Log for High Voltage Battery where applicable for full electric models *"
        );

        for (String item : items) {
            appGeneric.swipeToCenter(item);
            String details = appGeneric.handleButtonSelection(item, null);
            log.info("For the question : {} selected option: {}", item, details);
        }
    }

    public void finalizeComplianceRequirementsSection() throws InterruptedException {
        actions.swipeUntilEnd("up");
        generic.waitForVisibility(finalizeComplianceRequirementsButton).click();
        log.info("Completed all sections of Compliance Requirements.");
    }

    public void verifyComplianceStandardsButtonOptions() throws InterruptedException {
        List<String> items = Arrays.asList(
                "FTC buyers guide label present in vehicle*",
                "Carfax report in deal jacket or stored electronically (digital or paper copies acceptable).*",
                "Copy of RO in deal jacket or stored electronically with date and signature (digital or paper copies acceptable)*",
                "All spare keys (including wheel locks if installed) present*",
                "Serviced according to maintenance schedule/serviced if within 5,000 miles of service needed*",
                "OEM Factory windshield sticker present and verify all glass is free of damage/chips/cracks (Refer to MBCPO Reconditioning Manual)*",
                "Factory “Mercedes-Benz” windshield is installed on vehicle. (Check for Mercedes-Benz signature or symbol, signature of Gottlieb Daimler, or signature of Carl Benz in bottom right corner of glass.)*",
                "Dashboard free of any warning lights*",
                "Headlights, taillights, directional lights operable*",
                "Radio and Stereo Speaker Function operable*",
                "Seat heater/cooler - front/rear function properly*",
                "Interior and entry lighting operable*",
                "Windshield Wiper/Washer; Rear Window Wiper/Washer; Including Wiper Inserts, Headlamp Cleaning functional*",
                "All 4 of the vehicle’s tires clearly display the stamp “MO” or “MOE”*",
                "Tire Wear (Including spare); Min. Tread Depth = 5/32 in. NOT including TWI.*",
                "Inspect Wheels / Tires, Correct Tire Pressure within variance inside fuel door/No TPMS light on.*",
                "Interior trim; inspect dash, door panels, seat covers, wood, etc.*",
                "The seat belts are not damaged or excessively stained and function properly*",
                "Seat belt height adjusters function properly*",
                "Door/Trunk Lid and Tailgate Closing Assist*",
                "Trunk release functions properly*",
                "Sliding roof function drains and headliner operational*",
                "Moisture and odor present*",
                "No paint chips, scratches, dents that penetrate through base metal and mouldings*",
                "No damage on any panel greater than 3.5 inches and/or no visible damage to multiple body panels*"
        );

        for (String item : items) {
            appGeneric.swipeToCenter(item);
            String details = appGeneric.handleButtonSelection(item, null);
            log.info("For the question : {} selected option: {}", item, details);
        }

        actions.swipeUntilEnd("up");
        generic.waitForVisibility(finalizeComplianceRequirementsButton).click();
        log.info("Completed all sections of Compliance Standard Requirements.");
    }

    public void verifyMBCPOMarketingStandardsButtonOptions() {
        appGeneric.handleButtonSelection("CPO price and detailed description of vehicle displayed in window*", null);
        generic.waitForVisibility(finalizeComplianceRequirementsButton).click();
        log.info("Completed all sections of  MBCPO Marketing Standards.");
    }


}
