package org.openlane.autohawk.utils;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Random;

public class ApplicationGeneric extends AppiumGeneric {

    AppiumDriver driver;
    AndroidActions actions;
    private static final Logger log = LoggerFactory.getLogger(ApplicationGeneric.class);

    public ApplicationGeneric(AppiumDriver driver) {
        this.driver = driver;
        this.setDriver(driver);
        this.actions = new AndroidActions(driver);
    }

    public String handleRadioButtonsSelection(List<WebElement> radioButtonElement) {
        int count = radioButtonElement.size();
        if (count == 0) {
            log.warn("No options found");
            throw new IllegalStateException("No radio button options to select");
        }
        // check if any radio button is already selected
        for (WebElement radioButton : radioButtonElement) {
            if (radioButton.getAttribute("checked").equals("true")) {
                log.info("Radio button option already selected : {}", radioButton.getText());
                return radioButton.getText();
            }
        }
        // perform random selection if none are selected.
        Random random = new Random();
        int randomIndex = random.nextInt(count);
        log.info("Radio button selected option: {}", radioButtonElement.get(randomIndex).getText());
        String selectedOption = radioButtonElement.get(randomIndex).getText();
        radioButtonElement.get(randomIndex).click();
        return selectedOption;
    }

    public String handleCheckBoxSelection(String ButtonTitleName) {
        By buttonLocator = AppiumBy.xpath("//android.widget.TextView[contains(@text , \"" + ButtonTitleName + "\")]/parent::android.widget.LinearLayout/following-sibling::android.widget.LinearLayout/child::android.widget.Button");
        By popupLocator = AppiumBy.id("com.openlane.autohawk.uat:id/btn_confirm");
        List<WebElement> buttonSelection = driver.findElements(buttonLocator);
        int count = buttonSelection.size();
        if (count == 0) {
            log.warn("no button selection option found");
            throw new IllegalStateException("No button selection option to select");
        }

        Random random = new Random();
        int firstIndex = random.nextInt(count);
        int secondIndex;
        do {
            secondIndex = random.nextInt(count);
        } while (secondIndex == firstIndex);

        log.info("Selected button option : {}", buttonSelection.get(secondIndex).getText());
        String selectedOption = buttonSelection.get(secondIndex).getText();
        waitForVisibility(buttonSelection.get(firstIndex)).click();
        try {
            WebElement popup = driver.findElement(popupLocator);
            if (isElementVisible(popup)) {
                log.info("Popup is displayed");
                waitForVisibility(popup).click();
            }
        } catch (NoSuchElementException e) {
            log.info("Popup is not displayed");
        }
        buttonSelection = driver.findElements(buttonLocator);
        waitForVisibility(buttonSelection.get(secondIndex)).click();

        return selectedOption;
    }

    public String handleButtonSelection(String ButtonTitleName, String sectionName) {
        By buttonLocator = AppiumBy.xpath("//android.widget.TextView[contains(@text , \"" + ButtonTitleName + "\")]/parent::android.widget.LinearLayout/following-sibling::android.widget.LinearLayout/child::android.widget.Button");
        List<WebElement> buttonSelection = driver.findElements(buttonLocator);
        int count = buttonSelection.size();
        if (count == 0) {
            log.warn("no button selection option found");
            throw new IllegalStateException("No button selection option to select");
        }

        if (sectionName != null) {
            for (WebElement button : buttonSelection) {
                String text = button.getText();
                if (text.contains(sectionName)) {
                    // perform action
                    button.click();
                    log.info("Clicked on button with section name: {}", sectionName);
                } else {
                    log.info("Button with section name {} not found, available options: {}", sectionName, text);
                }
            }
        } else {
            Random random = new Random();
            int firstIndex = random.nextInt(count);
            int secondIndex;
            do {
                secondIndex = random.nextInt(count);
            } while (secondIndex == firstIndex);

            // log.info("Selected button option : {}", buttonSelection.get(secondIndex).getText());
            String selectedOption = buttonSelection.get(secondIndex).getText();
            waitForVisibility(buttonSelection.get(firstIndex)).click();
            buttonSelection = driver.findElements(buttonLocator);
            waitForVisibility(buttonSelection.get(secondIndex)).click();
            buttonSelection = driver.findElements(buttonLocator);
            log.info("Selected button option : {}", buttonSelection.get(secondIndex).getText());
            return selectedOption;
        }
        return sectionName;
    }

    public void handleChoiceOptionsSelection(List<WebElement> radioButtonElement) {
        int count = radioButtonElement.size();
        if (count == 0) {
            log.warn("No check box options found");
            throw new IllegalStateException("No check box options to select");
        }
        Random random = new Random();
        int randomIndex = random.nextInt(count);
        if (radioButtonElement.get(randomIndex).isSelected()) {
            log.info("check box option already selected : {}", radioButtonElement.get(randomIndex).getText());
            return;
        }
        radioButtonElement.get(randomIndex).click();
        log.info("Selected check box option : {}", radioButtonElement.get(randomIndex).getText());
    }

    public void handlePhotoSelection(String sectionNameWithoutAsterisk) {
        By cameraCaptureButtonLocator = AppiumBy.id("com.openlane.autohawk.uat:id/camera_capture_button");
        By confirmCaptureNextButtonLocator = AppiumBy.id("com.openlane.autohawk.uat:id/btn_next");
        By retakeCameraCaptureButtonLocator = AppiumBy.id("com.openlane.autohawk.uat:id/btn_retake");
        try {
            WebElement addPhoto = driver.findElement(By.xpath("//android.widget.TextView[@text='" + sectionNameWithoutAsterisk + "*']/parent::android.widget.LinearLayout/following-sibling::android.widget.TextView[@text=\"Add Photo*\"]"));
            addPhoto.click();
            WebElement cameraCaptureButton = driver.findElement(cameraCaptureButtonLocator);
            cameraCaptureButton.click();
            WebElement confirmCaptureNextButton = driver.findElement(confirmCaptureNextButtonLocator);
            confirmCaptureNextButton.click();
            log.info("{} is captured", sectionNameWithoutAsterisk);
        } catch (Exception e) {
            WebElement retakeCapturedPhotoButton = driver.findElement(By.xpath("//android.widget.TextView[@text = \"" + sectionNameWithoutAsterisk + "\"]/parent::android.widget.LinearLayout/following-sibling::android.view.ViewGroup/child::android.widget.Button[@resource-id=\"com.openlane.autohawk.uat:id/btn_reviewInspection\"]"));
            if (isElementVisible(retakeCapturedPhotoButton)) {
                log.info("{} is already captured", sectionNameWithoutAsterisk);
            } else {
                log.warn("Capture Button is not visible for section: {}", sectionNameWithoutAsterisk);
            }
        }
    }

    public void handleDropDownSelection(String dropdownText, String selectionText, WebElement sectionTitleName) {
        try {
            WebElement dropDownValidation = driver.findElement(By.xpath("//android.widget.TextView[@resource-id=\"com.openlane.autohawk.uat:id/titleText\" and @text=\"" + dropdownText + "\"]/following-sibling::android.widget.TextView[@resource-id=\"com.openlane.autohawk.uat:id/selectionText\"]"));
            if (isElementVisible(dropDownValidation)) {
                log.info("{} already selected: {}", dropdownText, dropDownValidation.getText());
            }
        } catch (Exception e) {
            WebElement dropDownTitleValidation = driver.findElement(By.xpath("//android.widget.TextView[@text=\"" + dropdownText + "\" and @resource-id=\"com.openlane.autohawk.uat:id/selectionText\"]"));
            waitForVisibility(dropDownTitleValidation).click();
            WebElement dropDownPicker = driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().text(\"" + selectionText + "\")"));
            if (dropDownPicker.isDisplayed()) {
                dropDownPicker.click();
                log.info("Selected {} type: {}", dropdownText, dropDownPicker.getText());
            }
        }
    }

    public void addDamage() {
        By cameraCaptureButtonLocator = AppiumBy.id("com.openlane.autohawk.uat:id/camera_capture_button");
        By nextButtonLocator = AppiumBy.id("com.openlane.autohawk.uat:id/btn_next");
        By saveDamageLocator = AppiumBy.id("com.openlane.autohawk.uat:id/btn_save_damage");
        By damageOptionLocator = AppiumBy.xpath("//android.widget.Button/preceding-sibling::android.widget.TextView");

        int maxAttempts = 20;
        int attempts = 0;
        while (attempts < maxAttempts) {
            try {
                // if capture button is present then click on it
                WebElement cameraCaptureButton = driver.findElement(cameraCaptureButtonLocator);
                if (cameraCaptureButton != null) {
                    cameraCaptureButton.click();
                    WebElement nextButton = driver.findElement(nextButtonLocator);
                    waitForVisibility(nextButton).click();
                    WebElement saveDamageButton = driver.findElement(saveDamageLocator);
                    waitForVisibility(saveDamageButton).click();
                    log.info("Save Damage button clicked, Damage saved successfully.");
                    return;
                }
            } catch (NoSuchElementException e) {
                log.info("Capture button not found, Attempting to select a damage option. ");
            }
            // click widget button if available
            List<WebElement> damageOption = driver.findElements(damageOptionLocator);
            Random random = new Random();
            int count = damageOption.size();
            if (!damageOption.isEmpty()) {
                int randomIndex = random.nextInt(count);
                String selectedOption = damageOption.get(0).getText();
                waitForVisibility(damageOption.get(0)).click();
                log.info("selected option : {}", selectedOption);
            } else {
                log.warn("No damage options available");
            }
            attempts++;
        }
    }

    public void swipeToCenter(String sectionName) {
        try {
            By locator = By.xpath("//android.widget.TextView[contains(@text, \"" + sectionName + "\")]");
            actions.swipeUntilVisibleAndCenter(locator);
            log.info("Swiped to center for section: {}", sectionName);
        } catch (Exception e) {
            log.error("Failed to swipe to center for section: {}", sectionName, e);
            throw new RuntimeException("Failed to swipe to center for section: " + sectionName, e);
        }
    }
}
