package org.openlane.autohawk.pageobject;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.*;
import org.openlane.autohawk.utils.AndroidActions;
import org.openlane.autohawk.utils.AppiumGeneric;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSXCUITAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
public class VehicleInfoPage {
    AppiumDriver driver;
    AndroidActions actions;
    AppiumGeneric generic;

    private static final Logger log = LoggerFactory.getLogger(VehicleInfoPage.class);

    public VehicleInfoPage(AppiumDriver driver) {
        this.driver = driver;
        this.actions = new AndroidActions(driver);
        this.generic = new AppiumGeneric();
        generic.setDriver(driver);
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }


    //Defining locators
    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/btn_cancel"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/btn_cancel")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement popupPermissionsForOBD2LaterButton;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/btn_confirm"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/btn_confirm")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement popupPermissionsForOBD2RequestButton;

    @AndroidFindBy(xpath = "//android.widget.TextView[contains (@text, \"Canadian Auction\")]/following-sibling::android.widget.Button")
    @iOSXCUITFindBy(id = "")
    private WebElement popupCanadianAuctionWithUSLocale;

    @AndroidFindBy(xpath = "//android.widget.TextView[contains (@text, \"Missing Mitchell\")]/following-sibling::android.widget.Button [@text = \"IGNORE\"]")
    @iOSXCUITFindBy(id = "")
    private WebElement popupMissingMitchellIgnoreButton;

    @AndroidFindBy(xpath = "//android.widget.TextView[contains (@text, \"Missing Mitchell\")]/following-sibling::android.widget.Button [@text = \"FILL OUT\"]")
    @iOSXCUITFindBy(id = "")
    private WebElement popupMissingMitchellFillOutButton;

    @AndroidFindBy(xpath = "//android.widget.TextView[contains (@text, \"Change Trim\")]/following-sibling::android.widget.Button [@text = \"CONFIRM\"]")
    @iOSXCUITFindBy(id = "")
    private WebElement popupChangeTrimConfirmButton;


    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Vehicle Info\")")
    @iOSXCUITFindBy(id = "")
    private WebElement vehicleInfoScreenTitle;

    @AndroidFindBy(id = "com.openlane.autohawk.uat:id/btn_confirm_info_normal")
    @iOSXCUITFindBy(id = "")
    private WebElement confirmInfoButton;

    //Defining actions
    public void verifyVehicleInfoScreenLoaded() {
        if (generic.isElementVisible(popupPermissionsForOBD2RequestButton)) {
            generic.waitForVisibility(popupPermissionsForOBD2RequestButton, 5).click();
            log.info("OBD2 permission popup is displayed");
        } else {
            log.info("OBD2 permission popup is not displayed");
        }
        if (generic.isElementVisible(popupCanadianAuctionWithUSLocale)) {
            generic.waitForVisibility(popupCanadianAuctionWithUSLocale, 5).click();
            log.info("Canadian auction with US locale popup is displayed");
        } else {
            log.info("Canadian auction with US locale popup is not displayed");
        }
        log.info("VehicleInfo screen is loaded without any popups");
        Assert.assertTrue(vehicleInfoScreenTitle.isDisplayed(), "VehicleInfo screen title not matched");
        log.info(vehicleInfoScreenTitle.getText());
    }

    public void acceptOBD2Permissions() {
        generic.waitForVisibility(popupPermissionsForOBD2RequestButton).click();
    }

    public void declineOBD2Permissions() {
        generic.waitForVisibility(popupPermissionsForOBD2LaterButton).click();
    }


    public void clickConfirmInfoButton() throws InterruptedException {
        actions.swipeUntilEnd("up");
        generic.waitForVisibility(confirmInfoButton).click();
        if (generic.isElementVisible(popupMissingMitchellIgnoreButton)) {
            generic.waitForVisibility(popupMissingMitchellIgnoreButton).click();
            log.info("Ignoring Missing Mitchell Data popup");
        } else {
            log.info("Missing Mitchell Data popup is not displayed");
        }
        if (generic.isElementVisible(popupChangeTrimConfirmButton)) {
            generic.waitForVisibility(popupChangeTrimConfirmButton).click();
        } else {
            log.info("Change Trim popup is not displayed");
        }
    }

}


