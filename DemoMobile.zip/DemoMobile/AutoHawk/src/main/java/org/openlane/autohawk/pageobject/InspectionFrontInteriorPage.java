package org.openlane.autohawk.pageobject;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.*;
import org.openlane.autohawk.utils.AndroidActions;
import org.openlane.autohawk.utils.AppiumGeneric;
import org.openlane.autohawk.utils.ApplicationGeneric;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.time.Duration;
import java.util.List;
import java.util.Random;

@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSXCUITAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
public class InspectionFrontInteriorPage {
    AppiumDriver driver;
    AppiumGeneric generic;
    AndroidActions actions;
    ApplicationGeneric appGeneric;
    private static final Logger log = LoggerFactory.getLogger(InspectionFrontInteriorPage.class);

    public InspectionFrontInteriorPage(AppiumDriver driver) {
        this.driver = driver;
        this.generic = new AppiumGeneric();
        this.generic.setDriver(driver);
        this.actions = new AndroidActions(driver);
        this.appGeneric = new ApplicationGeneric(driver);
        PageFactory.initElements(new AppiumFieldDecorator(driver, Duration.ofSeconds(10)), this);
    }

    //Defining locators

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/tv_title_extra_photo"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/tv_title_extra_photo")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement frontInteriorTitle;

    @AndroidFindBy(xpath = "(//android.widget.TextView[@text = \"Interior Color*\"])[2]")
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryInteriorColorDropDownSubTitle;

    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text , \"Odor Type\")]/parent::android.widget.LinearLayout/following-sibling::android.widget.RadioGroup/child::android.widget.RadioButton")
    @iOSXCUITFindBy(id = "")
    private List<WebElement> mandatoryOdorTypeRadioButtonList;

    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text , \"Key Type\")]/parent::android.widget.LinearLayout/following-sibling::android.widget.RadioGroup/child::android.widget.RadioButton")
    @iOSXCUITFindBy(id = "")
    private List<WebElement> mandatoryKeysTypeRadioButtonList;

    @AndroidFindBy(xpath = "(//android.widget.TextView[@text = \"# of Keys*\"])")
    @iOSXCUITFindBy(accessibility = "")
    private WebElement mandatoryNoOfKeysSubTitle;

    @AndroidFindBy(xpath = "(//android.widget.TextView[@text = \"# of Combo Keys*\"])")
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryNoOfComboKeysSubTitle;

    @AndroidFindBy(xpath = "(//android.widget.TextView[@text = \"# of Smart Keys*\"])")
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryNoOfSmartKeysSubTitle;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/et_textbox_control"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/et_textbox_control")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryMileageTextBox;

    @AndroidFindBy(uiAutomator = "new UiSelector().textContains(\"Double-check\")")
    @iOSXCUITFindBy(id = "")
    private WebElement DoubleCheckPopup;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/btn_confirm"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/btn_confirm")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement unitOfMeasurePopupConfirmButton;

    @AndroidFindBy(xpath = "(//android.widget.TextView[@text = \"Fuel*\"])[2]")
    @iOSXCUITFindBy(id = "")
    private WebElement mandatoryFuelSubTitle;

    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text , \"Fuel\")]/parent::android.widget.LinearLayout/following-sibling::android.widget.RadioGroup/child::android.widget.RadioButton")
    @iOSXCUITFindBy(id = "")
    private List<WebElement> mandatoryFuelRadioButtonList;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/btn_add_photo"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/btn_add_photo")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement addPhotoButton;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/camera_capture_button"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/camera_capture_button")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement cameraCaptureButton;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/btn_next"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/btn_next")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement confirmCapturedPhoto;

    @AndroidFindBy(uiAutomator = "new UiSelector().textContains(\"Damage Summary\")")
    @iOSXCUITFindBy(id = "")
    private WebElement damageSummaryScreen;

    @AndroidFindBy(uiAutomator = "new UiSelector().textContains(\"I need to skip OBD2 Codes\")")
    @iOSXCUITFindBy(id = "")
    private WebElement skipOBD2CheckBox;

    @AndroidFindBy(uiAutomator = "new UiSelector().textContains(\"OBD2 Scan Not Performed\")")
    @iOSXCUITFindBy(id = "")
    private WebElement OBD2DropDownTitle;


    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text , \"Transmission Speed\")]/parent::android.widget.LinearLayout/following-sibling::android.widget.RadioGroup/child::android.widget.RadioButton")
    @iOSXCUITFindBy(id = "")
    private List<WebElement> mandatoryTransmissionSpeedRadioButtonList;

    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text , \"Air Type\")]/parent::android.widget.LinearLayout/following-sibling::android.widget.RadioGroup/child::android.widget.RadioButton")
    @iOSXCUITFindBy(id = "")
    private List<WebElement> mandatoryAirTypeRadioButtonList;

    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text , \"Radio Equipment\")]/parent::android.widget.LinearLayout/following-sibling::android.widget.RadioGroup/child::android.widget.RadioButton")
    @iOSXCUITFindBy(id = "")
    private List<WebElement> mandatoryRadioEquipmentRadioButtonList;

    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text , \"Tire Pressure Monitoring\")]/parent::android.widget.LinearLayout/following-sibling::android.widget.RadioGroup/child::android.widget.RadioButton")
    @iOSXCUITFindBy(id = "")
    private List<WebElement> mandatoryTirePressureRadioButtonList;

    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text , \"Seat Covering Type\")]/parent::android.widget.LinearLayout/following-sibling::android.widget.RadioGroup/child::android.widget.RadioButton")
    @iOSXCUITFindBy(id = "")
    private List<WebElement> mandatorySeatCoveringRadioButtonList;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/btn_save_damage"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/btn_save_damage")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement saveDamageButton;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/btn_next_section"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/btn_next_section")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement rearInteriorButton;

    @AndroidFindBy(xpath = "//android.widget.TextView[contains (@text, \"Interior Doors\")]/following-sibling::android.widget.ImageView")
    @iOSXCUITFindBy(id = "")
    private WebElement interiorDoorsFrontDamageButton;

    //Defining actions
    public void verifyFrontInteriorTitle() {
        String expectedTitle = "Front Interior";
        String actualTitle = frontInteriorTitle.getText();
        Assert.assertEquals(actualTitle, expectedTitle, "Title does not match");
        log.info("Section Title verified successfully: {}", actualTitle);
    }

    public void verifyMandatoryOdorPresentButton() {
        String value = appGeneric.handleCheckBoxSelection("Odor Present");
        log.info("Odor Present checkbox is selected as : {}", value);
        if (value.equals("Mild") || value.equals("Extreme")) {
            appGeneric.handleRadioButtonsSelection(mandatoryOdorTypeRadioButtonList);
        } else {
            log.info("Odor Type field not present for :{}", value);
        }

    }

    public void verifyMandatoryInteriorColorDropDown() {
        appGeneric.handleDropDownSelection("Interior Color*", "Brown", mandatoryInteriorColorDropDownSubTitle);
    }

    public void addDamage() {
        By cameraCaptureButtonLocator = AppiumBy.id("com.openlane.autohawk.uat:id/camera_capture_button");
        By nextButtonLocator = AppiumBy.id("com.openlane.autohawk.uat:id/btn_next");
        By saveDamageLocator = AppiumBy.id("com.openlane.autohawk.uat:id/btn_save_damage");
        By damageOptionLocator = AppiumBy.xpath("//android.widget.Button/preceding-sibling::android.widget.TextView");
        int maxAttempts = 20;
        int attempts = 0;
        while (attempts < maxAttempts) {
            try {
                // if capture button is present then click on it
                WebElement cameraCaptureButton = driver.findElement(cameraCaptureButtonLocator);
                if (cameraCaptureButton != null) {
                    cameraCaptureButton.click();
                    WebElement nextButton = driver.findElement(nextButtonLocator);
                    nextButton.click();
                    WebElement saveDamageButton = driver.findElement(saveDamageLocator);
                    saveDamageButton.click();
                    return;
                }
            } catch (NoSuchElementException e) {
                log.info("Capture button not found, Attempting to select a damage option. ");
            }
            // click widget button if available
            List<WebElement> damageOption = driver.findElements(damageOptionLocator);
            Random random = new Random();
            int count = damageOption.size();
            if (!damageOption.isEmpty()) {
                int randomIndex = random.nextInt(count);
                String selectedOption = damageOption.get(randomIndex).getText();
                generic.waitForVisibility(damageOption.get(randomIndex)).click();
                log.info("selected option : {}", selectedOption);
            } else {
                WebElement nextButton = driver.findElement(nextButtonLocator);
                nextButton.click();
                log.warn("No damage options available .. continue to capture image");
            }
            attempts++;
        }
    }

    public String handleButtonSelection(String ButtonTitleName) {
        By buttonLocator = AppiumBy.xpath("//android.widget.TextView[contains(@text , \"" + ButtonTitleName + "\")]/parent::android.widget.LinearLayout/following-sibling::android.widget.LinearLayout/child::android.widget.Button");
        By popupLocator = AppiumBy.id("com.openlane.autohawk.uat:id/btn_confirm");
        List<WebElement> buttonSelection = driver.findElements(buttonLocator);
        int count = buttonSelection.size();
        if (count == 0) {
            log.warn("no button selection option found");
            throw new IllegalStateException("No button selection option to select");
        }

        Random random = new Random();
        int firstIndex = count - 1; // Always select the last index
        int secondIndex;
        do {
            secondIndex = random.nextInt(count);
        } while (secondIndex == firstIndex);

        log.info("Selected Button option : {}", buttonSelection.get(secondIndex).getText());
        String selectedOption = buttonSelection.get(secondIndex).getText();
        generic.waitForVisibility(buttonSelection.get(firstIndex)).click();
        buttonSelection = driver.findElements(buttonLocator);
        generic.waitForVisibility(buttonSelection.get(secondIndex)).click();
        return selectedOption;
    }

    public void verifyMandatoryKeysSection() {
        By subTitleLocator = By.xpath("//android.widget.TextView[contains(@text, 'Keys*')]");
        actions.swipeUntilVisibleAndCenter(subTitleLocator);
        String value = appGeneric.handleRadioButtonsSelection(mandatoryKeysTypeRadioButtonList);
        if (value.equals("Standard")) {
            actions.scrollElementToCenter(mandatoryNoOfKeysSubTitle);
            String value1 = handleButtonSelection("# of Keys*");
            if (value1.equals("0")) {
                try {
                    addDamage();
                } catch (Exception e) {
                    log.info("damage is already added for # of Keys");
                }
            } else {
                log.info("# of Keys is selected as : {}", value1);
            }
        } else if (value.equals("Standard w/ Remote")) {
            actions.scrollElementToCenter(mandatoryNoOfKeysSubTitle);
            String value1 = handleButtonSelection("# of Keys*");
            if (value1.equals("0")) {
                try {
                    addDamage();
                } catch (Exception e) {
                    log.info("damage is already added for # of Keys");
                }
            } else {
                log.info("# of Keys is selected as : {}", value1);
            }
            String value2 = handleButtonSelection("# of Remotes");
            if (value2.equals("0")) {
                try {
                    addDamage();
                } catch (Exception e) {
                    log.info("damage is already added for # of Remotes");
                }
            } else {
                log.info("# of Remotes is selected as : {}", value2);
            }

        } else if (value.equals("Combo")) {
            actions.scrollElementToCenter(mandatoryNoOfComboKeysSubTitle);
            String value1 = handleButtonSelection("# of Combo Keys*");
            if (value1.equals("0")) {
                try {
                    addDamage();
                } catch (Exception e) {
                    log.info("damage is already added for # of Combo Keys");
                }
            } else {
                log.info("# of Combo Keys is selected as : {}", value1);
            }

        } else if (value.equals("Smart")) {
            actions.scrollElementToCenter(mandatoryNoOfSmartKeysSubTitle);
            String value1 = handleButtonSelection("# of Smart Keys*");
            if (value1.equals("0")) {
                try {
                    addDamage();
                } catch (Exception e) {
                    log.info("damage is already added for # of Smart Keys");
                }
            } else {
                log.info("# of Smart Keys is selected as : {}", value1);
            }
            String value2 = handleButtonSelection("# of Emergency Keys*");
            if (value2.equals("0")) {
                try {
                    addDamage();
                } catch (Exception e) {
                    log.info("damage is already added for # of Emergency Keys");
                }
            } else {
                log.info("# of Emergency Keys is selected as : {}", value2);
            }
        } else {
            log.info("No keys are selected");

        }
    }


    public void verifyMandatoryKeysFobsManualPhoto() {
        By subTitleLocator = By.xpath("//android.widget.TextView[contains(@text, 'Keys/Fobs/Manual Photo')]");
        actions.swipeUntilVisibleAndCenter(subTitleLocator);
        appGeneric.handlePhotoSelection("Keys/Fobs/Manual Photo");
    }

    public void verifyMandatoryDrivableDropDown() {
        By subTitleLocator = By.xpath("//android.widget.TextView[contains(@text, 'Drivable')]");
        actions.swipeUntilVisibleAndCenter(subTitleLocator);
        By dropdownTitleLocator = By.xpath("//android.widget.TextView[@resource-id=\"com.openlane.autohawk.uat:id/titleText\"]");
        By dropdownLocator = By.xpath("//android.widget.TextView[@resource-id=\"com.openlane.autohawk.uat:id/selectionText\"]");
        try {
            WebElement dropdown = driver.findElement(dropdownLocator);
            dropdown.click();
            WebElement selectionText = driver.findElement(By.xpath("//android.widget.TextView[@text = \"Yes\"]"));
            selectionText.click();
            log.info("Drivable dropdown is selected as : " + selectionText.getText());
        } catch (Exception e) {
            WebElement dropdownTitle = driver.findElement(dropdownTitleLocator);
            Assert.assertEquals(dropdownTitle.getText(), "Drivable*", "Drivable dropdown is already selected");
            log.info("Drivable dropdown is already selected");
        }
    }

    public void verifyMandatoryOdometerInfo() {
        By subTitleLocator = By.xpath("//android.widget.TextView[contains(@text, 'Odometer Info')]");
        actions.swipeUntilVisibleAndCenter(subTitleLocator);
        appGeneric.handlePhotoSelection("Odometer Photo");

        By subTitleLocator2 = By.xpath("//android.widget.TextView[contains(@text, 'Mileage*')]");
        actions.swipeUntilVisibleAndCenter(subTitleLocator2);
        generic.waitForVisibility(mandatoryMileageTextBox).click();
        generic.waitForVisibility(mandatoryMileageTextBox).clear();
        generic.waitForVisibility(mandatoryMileageTextBox).sendKeys("4321");
        AndroidDriver driver1 = (AndroidDriver) driver;
        driver1.pressKey(new KeyEvent(AndroidKey.ENTER));
        if (generic.isElementVisible(DoubleCheckPopup)) {
            unitOfMeasurePopupConfirmButton.click();
            log.info("Double-check odo reading popup is displayed");
        } else {
            log.info("Double-check odo reading popup is not displayed");
        }

        By subTitleLocator3 = By.xpath("//android.widget.TextView[contains(@text, 'Odometer Scale*')]");
        actions.swipeUntilVisibleAndCenter(subTitleLocator3);
        appGeneric.handleCheckBoxSelection("Odometer Scale");
        if (generic.isElementVisible(DoubleCheckPopup)) {
            unitOfMeasurePopupConfirmButton.click();
            log.info("Unit of measure popup is displayed");
        } else {
            log.info("Unit of measure popup is not displayed");
        }

    }

    public void verifyMandatoryFuelRadioButton() {
        By subTitleLocator = By.xpath("//android.widget.TextView[contains(@text, 'Fuel*')]");
        actions.swipeUntilVisibleAndCenter(subTitleLocator);
        actions.scrollElementToCenter(mandatoryFuelSubTitle);
        String value = appGeneric.handleRadioButtonsSelection(mandatoryFuelRadioButtonList);
        if (value.equals("Empty") && generic.isElementVisible(damageSummaryScreen)) {
            generic.waitForVisibility(addPhotoButton).click();
            generic.waitForVisibility(cameraCaptureButton).click();
            generic.waitForVisibility(confirmCapturedPhoto).click();
            generic.waitForVisibility(saveDamageButton).click();
            log.info("Fuel type is selected as Empty and photo is captured");
        } else {
            log.info("Fuel type is selected as : {}", value);
        }

    }

    public void verifyMandatoryOBD2CodesSkip() {
        By subTitleLocator = By.xpath("//android.widget.TextView[contains(@text, 'BLUETOOTH SETTINGS')]");
        actions.swipeUntilVisibleAndCenter(subTitleLocator);
        if (skipOBD2CheckBox.getAttribute("checked").equals("true")) {
            if (generic.isElementVisible(OBD2DropDownTitle)) {
                appGeneric.handleDropDownSelection("OBD2 Scan Not Performed*", "Customer Requested No Scan", null);
                log.info("OBD2 Codes skip is selected and dropdown was selected after");
            } else {
                log.info("Skip OBD2 Codes is already checked");
            }
        } else {
            skipOBD2CheckBox.click();
            log.info("Skip OBD2 Codes checkbox is selected");
            appGeneric.handleDropDownSelection("OBD2 Scan Not Performed*", "Customer Requested No Scan", null);
        }
    }

    public void verifyMandatoryDriverControls() {
        By subTitleLocator = By.xpath("//android.widget.TextView[contains(@text, 'Driver Controls')]");
        actions.swipeUntilVisibleAndCenter(subTitleLocator);
        String value = appGeneric.handleCheckBoxSelection("Transmission Type");
        log.info("Transmission Type is selected as : {}", value);
        if (value.equals("Manual")) {
            By subTitleLocator1 = By.xpath("//android.widget.TextView[contains(@text, 'Transmission Speed')]");
            actions.swipeUntilVisibleAndCenter(subTitleLocator1);
            appGeneric.handleRadioButtonsSelection(mandatoryTransmissionSpeedRadioButtonList);
            log.info("Transmission Speed is selected as : {}", value);
        }

    }

    public void verifyMandatoryHeating() {
        By subTitleLocator = By.xpath("//android.widget.TextView[contains(@text, 'Heating')]");
        actions.swipeUntilVisibleAndCenter(subTitleLocator);
        appGeneric.handleRadioButtonsSelection(mandatoryAirTypeRadioButtonList);
    }

    public void verifyMandatorySoundSystem() {
        By subTitleLocator = By.xpath("//android.widget.TextView[contains(@text, 'Radio Equipment')]");
        actions.swipeUntilVisibleAndCenter(subTitleLocator);
        appGeneric.handleRadioButtonsSelection(mandatoryRadioEquipmentRadioButtonList);
    }

    public void verifyMandatorySafetyOptions() {
        By subTitleLocator = By.xpath("//android.widget.TextView[contains(@text, 'Safety Options')]");
        actions.swipeUntilVisibleAndCenter(subTitleLocator);
        appGeneric.handleRadioButtonsSelection(mandatoryTirePressureRadioButtonList);
    }

    public void verifyMandatorySeating() {
        By subTitleLocator = By.xpath("//android.widget.TextView[contains(@text, 'Seating')]");
        actions.swipeUntilVisibleAndCenter(subTitleLocator);
        appGeneric.handleDropDownSelection("# of Passengers*", "5", null);

        By subTitleLocator1 = By.xpath("//android.widget.TextView[contains(@text, 'Seat Covering Type')]");
        actions.swipeUntilVisibleAndCenter(subTitleLocator1);
        appGeneric.handleRadioButtonsSelection(mandatorySeatCoveringRadioButtonList);

    }

    public void verifyMandatoryOwnersManual() {
        appGeneric.swipeToCenter("Owners Manual");
        appGeneric.handleButtonSelection("Owners Manual*", null);
        appGeneric.handleButtonSelection("Warranty Book*", null);
    }

    public void verifyMandatoryOverallInterior() {
        appGeneric.swipeToCenter("Front Mats Present*");
        appGeneric.handleButtonSelection("Front Mats Present*", null);
        appGeneric.handleButtonSelection("Back Mats Present*", null);
    }

    public void finaliseFrontInteriorSection() throws InterruptedException {
        actions.swipeUntilEnd("up");
        //adding damage
        generic.waitForVisibility(interiorDoorsFrontDamageButton).click();
        log.info("Interior Doors Front Damage button is clicked");
        appGeneric.addDamage();

        actions.swipeUntilEnd("up");
        generic.waitForVisibility(rearInteriorButton).click();
        log.info("completed all mandatory sections of Right Exterior section");
    }

}
