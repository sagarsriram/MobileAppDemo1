package org.openlane.autohawk.utils;

import com.google.common.collect.ImmutableMap;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Pause;
import org.openqa.selenium.interactions.PointerInput;
import org.openqa.selenium.interactions.Sequence;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.*;
import java.util.NoSuchElementException;
import java.util.function.Supplier;

public class AndroidActions extends AppiumGeneric {

    AppiumDriver driver;

    public AndroidActions(AppiumDriver driver) {
        this.driver = driver;
    }

    public void longPressAction(WebElement ele) {
        ((JavascriptExecutor) driver).executeScript("mobile: longClickGesture",
                ImmutableMap.of("elementId", ((RemoteWebElement) ele).getId(),
                        "duration", 2000));
    }

    public void scrollToText(String text) {
        driver.findElement(AppiumBy.androidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"" + text + "\"));"));
    }

    public void swipe(String direction) {
        Dimension size = driver.manage().window().getSize();
        int startX, startY, endX, endY;
        switch (direction.toLowerCase()) {
            case "up":
                startX = size.getWidth() / 2;
                startY = size.getHeight() / 2;
                endX = startX;
                endY = (int) (size.getHeight() * 0.35);
                break;
            case "down":
                startX = size.getWidth() / 2;
                startY = (int) (size.getHeight() * 0.35);
                endX = startX;
                endY = size.getHeight() / 2;
                break;
            case "left":
                startY = size.getHeight() / 2;
                startX = (int) (size.getWidth() * 0.8);
                endX = (int) (size.getWidth() * 0.2);
                endY = startY;
                break;
            case "right":
                startY = size.getHeight() / 2;
                startX = (int) (size.getWidth() * 0.1);
                endX = (int) (size.getWidth() * 0.8);
                endY = startY;
                break;
            default:
                throw new IllegalArgumentException("Invalid swipe direction: " + direction);
        }
        PointerInput finger1 = new PointerInput(PointerInput.Kind.TOUCH, "finger1");
        Sequence sequence = new Sequence(finger1, 1)
                .addAction(finger1.createPointerMove(Duration.ZERO, PointerInput.Origin.viewport(), startX, startY))
                .addAction(finger1.createPointerDown(PointerInput.MouseButton.LEFT.asArg()))
                .addAction(new Pause(finger1, Duration.ofMillis(500)))
                .addAction(finger1.createPointerMove(Duration.ofMillis(300), PointerInput.Origin.viewport(), endX, endY))
                .addAction(finger1.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));
        driver.perform(Collections.singletonList(sequence));

    }

    public void swipeUntilEnd(String direction) throws InterruptedException {
        String previousSource;
        String currentSource = driver.getPageSource();
        while (true) {
            previousSource = currentSource;
            swipe(direction);
            Thread.sleep(1500);
            currentSource = driver.getPageSource();
            if (previousSource.equals(currentSource)) {
                System.out.println("Reached end of scroll.");
                break;
            }
        }
        System.out.println("Completed scroll to bottom dynamically.");
    }

    public void swipeUntilVisible(WebElement element) {
        int maxSwipes = 10;
        int attempts = 0;
        while (attempts < maxSwipes) {
            try {
                if (element.isDisplayed()) {
                    System.out.println("Element is now visible.");
                    break;
                }
            } catch (NoSuchElementException | StaleElementReferenceException e) {
                System.out.println("Element not in DOM yet. Swiping...");
            }
            swipe("up"); // your existing swipe method
            attempts++;
        }
        if (attempts == maxSwipes) {
            System.out.println("Element not found after " + maxSwipes + " swipes.");
        }
    }

    public void scrollElementToCenter(WebElement element) {
        int screenHeight = driver.manage().window().getSize().height;
        int centerY = screenHeight / 2;
        int attempts = 0;
        int lastPageSourceLength = 0;

        while (attempts < 10) {
            String currentPageSource = driver.getPageSource();
            int currentPageSourceLength = currentPageSource.length();

            //if page source length is same as last page source length, break the loop
            if (currentPageSourceLength == lastPageSourceLength) {
                System.out.println("No more content to scroll.");
                break;
            }

            lastPageSourceLength = currentPageSourceLength;

            try {
                int elementY = element.getLocation().getY();
                if (elementY <= centerY) {
                    System.out.println("Element is already above center.");
                    break; // Element is already in view i,e first 50 percent of the screen
                }

                swipe("up");
            } catch (NoSuchElementException e) {
                System.out.println("Element not found during scroll: " + e.getMessage());
                swipe("up");
            }

            attempts++;
        }
    }

    public void swipeUntilVisibleAndCenter(By locator) {
        int screenHeight = driver.manage().window().getSize().height;
        int centerY = screenHeight / 2;
        int lastPageSourceLength = 0;
        int attempts = 0;
        long startTime = System.currentTimeMillis();

        while (attempts < 10) {
            if (!driver.findElements(locator).isEmpty()) {
                try {
                    WebElement element = driver.findElement(locator);
                    int elementY = element.getLocation().getY();
                    if (elementY <= centerY) {
                        System.out.println("Element is visible and above center.");
                        break;
                    }
                    swipe("up");
                } catch (Exception e) {
                    System.out.println("Failed to scroll to center: " + e.getMessage());
                    swipe("up");
                }
            } else {
                swipe("up");
            }
            String currentSource = driver.getPageSource();
            int currentLength = currentSource.length();
            if (currentLength == lastPageSourceLength) {
                System.out.println("No more content to scroll.");
                break;
            }
            lastPageSourceLength = currentLength;
            attempts++;
        }
    }

    public List<String> getAllUniqueVisibleTexts(By locator) throws InterruptedException {
        Set<String> uniqueTexts = new LinkedHashSet<>();
        String previousSource;
        String currentSource = driver.getPageSource();
        while (true) {
            previousSource = currentSource;
            List<WebElement> elements = driver.findElements(locator);
            for (WebElement el : elements) {
                String text = el.getText().trim();
                if (!text.isEmpty()) {
                    uniqueTexts.add(text);
                }
            }
            swipe("up"); // existing method
            Thread.sleep(1500); // let UI load
            currentSource = driver.getPageSource();
            if (previousSource.equals(currentSource)) {
                System.out.println("Reached end of scroll. No more content.");
                break;
            }
        }
        System.out.println("Total unique items collected: " + uniqueTexts.size());
        return new ArrayList<>(uniqueTexts);
    }

    public List<String> getAllUniqueVisibleTexts(List<By> locators) throws InterruptedException {
        Set<String> uniqueTexts = new LinkedHashSet<>();
        String previousSource;
        String currentSource = driver.getPageSource();
        while (true) {
            previousSource = currentSource;
            // Loop through each locator and collect text
            for (By locator : locators) {
                List<WebElement> elements = driver.findElements(locator);
                for (WebElement el : elements) {
                    String text = el.getText().trim();
                    if (!text.isEmpty()) {
                        uniqueTexts.add(text);
                    }
                }
            }
            swipe("up"); // reusable method
            Thread.sleep(1500); // allow UI to update
            currentSource = driver.getPageSource();
            if (previousSource.equals(currentSource)) {
                System.out.println("No more new content to scroll.");
                break;
            }
        }
        return new ArrayList<>(uniqueTexts);
    }
}
