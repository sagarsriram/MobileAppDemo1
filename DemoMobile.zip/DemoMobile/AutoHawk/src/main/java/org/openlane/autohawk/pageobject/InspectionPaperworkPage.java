package org.openlane.autohawk.pageobject;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.*;
import org.openlane.autohawk.utils.AndroidActions;
import org.openlane.autohawk.utils.AppiumGeneric;
import org.openlane.autohawk.utils.ApplicationGeneric;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;

@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSXCUITAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
public class InspectionPaperworkPage {
    AppiumDriver driver;
    AppiumGeneric generic;
    AndroidActions actions;
    ApplicationGeneric appGeneric;
    private static final Logger log = LoggerFactory.getLogger(InspectionPaperworkPage.class);

    public InspectionPaperworkPage(AppiumDriver driver) {
        this.driver = driver;
        this.generic = new AppiumGeneric();
        this.generic.setDriver(driver);
        this.actions = new AndroidActions(driver);
        this.appGeneric = new ApplicationGeneric(driver);
        PageFactory.initElements(new AppiumFieldDecorator(driver, Duration.ofSeconds(10)), this);
    }

    //Defining locators
    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/tv_title_extra_photo"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/tv_title_extra_photo")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement paperworkTitle;

    @AndroidFindAll({
            @AndroidBy(id = "com.openlane.autohawk.uat:id/btn_next_section"),
            @AndroidBy(id = "com.openlane.autohawk.test:id/btn_next_section")
    })
    @iOSXCUITFindBy(id = "")
    private WebElement generalEligibilityButton;

    public void verifyTitlePaperwork() {
        String expectedTitle = "Paperwork";
        String actualTitle = paperworkTitle.getText();
        Assert.assertEquals(actualTitle, expectedTitle, "Paperwork title is not matching");
        log.info("Paperwork title is verified successfully: " + actualTitle);
    }

    public void verifyPaperworkButtonOptions() {
        List<String> items = Arrays.asList(
                "Lexus vehicle certificate is present (digital or paper copies acceptable)*",
                "Lexus vehicle certificate includes vin (digital or paper copies acceptable)*",
                "Lexus vehicle certificate includes signature of person who performed certification (digital or paper copies acceptable)*",
                "Check sheet is present (digital or paper copies acceptable)*",
                "Check sheet is not filled out completely and correctly (digital or paper copies acceptable)*",
                "Check sheet has all required signatures (digital or paper copies acceptable)*",
                "Repair orders documenting required repairs are missing (digital or paper copies acceptable)*",
                "Repair orders match the checklist (digital or paper copies acceptable)*",
                "Vehicle history report (VHR) is missing (digital or paper copies acceptable)*",
                "Original owners manual is present*",
                "Certified pre-owned warranty supplement and roadside assistance guide is present*",
                "Are there open recalls on this vehicle confirmed at www.Lexus.com/recalls?*"
        );

        for (String item : items) {
            appGeneric.swipeToCenter(item);
            String details = appGeneric.handleButtonSelection(item, null);
            log.info("For the question : {} selected option: {}", item, details);
        }
    }

    public void finalizeExteriorAppearanceDetailingSection() throws InterruptedException {
        actions.swipeUntilEnd("up");
        generic.waitForVisibility(generalEligibilityButton).click();
        log.info("Completed all sections of Paperwork.");
    }

}
