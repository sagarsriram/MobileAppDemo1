package org.openlane.autohawk.testcases.e2e;

import org.openlane.autohawk.pageobject.*;
import org.openlane.autohawk.testutils.BaseTest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

import static org.openlane.autohawk.testutils.Listeners.extentTest;

//completed do not alter unless u debug
public class AVL_CPO_Inspection_TOYOTA_SoldUnit_NO_GoldUnit_YES extends BaseTest {
    // This class is a placeholder for the full inspection test case.
    // It will contain methods to perform end-to-end testing of the application.
    // The actual implementation will depend on the specific requirements and flow of the application.

    //VIN - used - 5TDJY5G15ES093742

    LoginPage login;
    HomePage home;
    SiteSettingsPage siteSettings;
    VehicleInfoPage vehicleInfo;
    InspectionLandingPage inspectionHome;
    InspectionTypeOfInspectionPage typeOfInspectionSection;
    InspectionMarketingAndPaperworkPage marketingAndPaperworkSection;
    InspectionVehicleGeneralEligibilityPage vehicleGeneralEligibilitySection;
    InspectionMechanicalTwoPage mechanicalTwoSection;
    InspectionElectricalPage electricalSection;
    InspectionInteriorAppearanceDetailingPage interiorAppearanceDetailingPage;
    InspectionExteriorAppearanceDetailingPage exteriorAppearanceDetailingPage;
    InspectionInternetPage internetSection;
    InspectionImagesPage imagesSection;
    InspectionCommentsForClientPage commentsForClientSection;
    InspectionCompletionPage completionSection;
    private static final Logger log = LoggerFactory.getLogger(AVL_CPO_Inspection_TOYOTA_SoldUnit_NO_GoldUnit_YES.class);

    @BeforeClass
    public void setupPages() {
        login = new LoginPage(driver);
        home = new HomePage(driver);
        siteSettings = new SiteSettingsPage(driver);
        vehicleInfo = new VehicleInfoPage(driver);
        inspectionHome = new InspectionLandingPage(driver);
        typeOfInspectionSection = new InspectionTypeOfInspectionPage(driver);
        marketingAndPaperworkSection = new InspectionMarketingAndPaperworkPage(driver);
        vehicleGeneralEligibilitySection = new InspectionVehicleGeneralEligibilityPage(driver);
        mechanicalTwoSection = new InspectionMechanicalTwoPage(driver);
        electricalSection = new InspectionElectricalPage(driver);
        interiorAppearanceDetailingPage = new InspectionInteriorAppearanceDetailingPage(driver);
        exteriorAppearanceDetailingPage = new InspectionExteriorAppearanceDetailingPage(driver);
        internetSection = new InspectionInternetPage(driver);
        imagesSection = new InspectionImagesPage(driver);
        commentsForClientSection = new InspectionCommentsForClientPage(driver);
        completionSection = new InspectionCompletionPage(driver);
    }

    @Test
    public void login() throws InterruptedException {
        login.defaultLogin();
        home.verifyHomePageLoaded();
        home.tapAssignedTab();
        String vinNumber = VinDetailsReader.getVinValue("FINAL_AVL_CPO_INSPECTION_TOYOTA_SOLDUNIT_NO_GOLDUNIT_YES");
        home.initiateInspectionUsingVinFromSearchBar(vinNumber);
        vehicleInfo.verifyVehicleInfoScreenLoaded();
        vehicleInfo.clickConfirmInfoButton();
        inspectionHome.verifyLandingOfInspectionScreen(vinNumber);
        extentTest.info("Inspection screen is loaded for VIN: " + vinNumber);
    }

    @Test(dependsOnMethods = {"login"}) //completed
    public void typeOfInspection() throws Exception {
        inspectionHome.tapTypeOfInspectionSection();
        typeOfInspectionSection.verifyTypeOfInspectionTitle();
        typeOfInspectionSection.verifyMandatoryTypeOfInspectionGoldUnit("No", "Yes");
        extentTest.info("Type of Inspection section verified successfully.");
    }

    @Test(dependsOnMethods = {"typeOfInspection"}) //completed
    public void marketingAndPaperWorkInspection() throws InterruptedException {
        inspectionHome.tapMarketingAndPaperworkSection();
        marketingAndPaperworkSection.verifyMarketingAndPaperworkTitle();
        marketingAndPaperworkSection.verifyMarketingAndPaperworkButtonOptionsToyotaSoldUnitNOAndSelectedGoldUnit();
        marketingAndPaperworkSection.finalizeMarketingAndPaperworkSection();
        extentTest.info("Marketing and Paperwork section completed successfully.");
    }

    @Test(dependsOnMethods = {"marketingAndPaperWorkInspection"}) //completed
    public void vehicleGeneralEligibilityInspection() throws InterruptedException {
        vehicleGeneralEligibilitySection.verifyVehicleGeneralEligibilityTitle();
        vehicleGeneralEligibilitySection.verifyGeneralEligibilitySectionToyota();
        vehicleGeneralEligibilitySection.finalizeVehicleGeneralEligibilitySection();
        extentTest.info("Vehicle General Eligibility section completed successfully.");
    }

    @Test(dependsOnMethods = {"exteriorAppearanceInspection"}) //completed
    public void mechanicalTwoInspection() throws InterruptedException {
        mechanicalTwoSection.verifyMechanicalTitle();
        mechanicalTwoSection.verifyMechanicalButtonOptionsToyotaSoldUnitNOAndGoldUnitYES();
        mechanicalTwoSection.finalizeMechanicalSection();
        extentTest.info("Mechanical Two section completed successfully.");
    }

    @Test(dependsOnMethods = {"mechanicalTwoInspection"}) //completed
    public void electricalInspection() throws InterruptedException {
        electricalSection.verifyElectricalTitle();
        electricalSection.verifyElectricalButtonOptionsToyota();
        electricalSection.finalizeElectricalSection();
        extentTest.info("Electrical section completed successfully.");
    }

    @Test(dependsOnMethods = {"electricalInspection"}) //completed
    public void interiorAppearanceInspection() throws InterruptedException {
        interiorAppearanceDetailingPage.verifyInteriorAppearanceDetailingTitle();
        interiorAppearanceDetailingPage.verifyInteriorAppearanceDetailingButtonOptionsToyota();
        interiorAppearanceDetailingPage.finalizeInteriorAppearanceDetailingSection();
        extentTest.info("Interior Appearance Detailing section completed successfully.");
    }

    @Test(dependsOnMethods = {"interiorAppearanceInspection"}) //completed
    public void exteriorAppearanceInspection() throws InterruptedException {
        exteriorAppearanceDetailingPage.verifyExteriorAppearanceDetailingTitle();
        exteriorAppearanceDetailingPage.verifyExteriorAppearanceDetailingButtonOptionsToyotaSoldUnitNOAndGoldUnitYES();
        exteriorAppearanceDetailingPage.finalizeExteriorAppearanceDetailingSection();
        extentTest.info("Exterior Appearance Detailing section completed successfully.");
    }

    @Test(dependsOnMethods = {"exteriorAppearanceInspection"}) //completed
    public void ImagesInspection() throws InterruptedException {
        imagesSection.verifyImagesTitle();
        imagesSection.verifyRequiredImagesToyotaSoldUnitNOAndGoldUnitSelected();
        imagesSection.finalizeImagesSection();
        extentTest.info("Images section completed successfully.");
    }

    @Test(dependsOnMethods = {"internetInspection"}) //completed
    public void internetInspection() throws InterruptedException {
        internetSection.verifyInternetTitle();
        internetSection.verifyInternetButtonOptionsGulfState();
        internetSection.finalizeInternetSection();
        extentTest.info("Internet section completed successfully.");
    }

    @Test(dependsOnMethods = {"ImagesInspection"}) //completed
    public void commentsForClientInspection() {
        commentsForClientSection.verifyCommentsForClientTitle();
        commentsForClientSection.verifyCommentInput();
        commentsForClientSection.finalizeCommentsForClientSection();
        extentTest.info("Comments for Client section completed successfully.");
    }

    @Test(dependsOnMethods = {"commentsForClientInspection"})
    public void completeInspection() throws InterruptedException {
        inspectionHome.tapCompleteInspectionButton();
        Map<String, String> details = completionSection.verifyInspectionCompletion();
        String totalTime = details.get("TotalTime");
        String totalInspection = details.get("TotalInspections");
        log.info("Total time taken for inspection: {}", totalTime);
        log.info("Total Inspections completed: {}", totalInspection);
        extentTest.info("Inspection completed successfully with total time: " + totalTime + " and total inspections: " + totalInspection);
    }
}
