package org.openlane.autohawk.testcases.e2e;

import org.openlane.autohawk.pageobject.*;
import org.openlane.autohawk.testutils.BaseTest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

import static org.openlane.autohawk.testutils.Listeners.extentTest;


public class AVL_CPO_Inspection_MERCEDES_BENZ_SoldUnit_NO extends BaseTest {
    // This class is a placeholder for the full inspection test case.
    // It will contain methods to perform end-to-end testing of the application.
    // The actual implementation will depend on the specific requirements and flow of the application.
    LoginPage login;
    HomePage home;
    SiteSettingsPage siteSettings;
    VehicleInfoPage vehicleInfo;
    InspectionLandingPage inspectionHome;
    InspectionTypeOfInspectionPage typeOfInspectionSection;
    InspectionVehicleGeneralEligibilityPage vehicleGeneralEligibilitySection;
    InspectionComplianceRequirementsPage complianceRequirementsSection;
    InspectionImagesPage imagesSection;
    InspectionCommentsForClientPage commentsForClientSection;
    InspectionCompletionPage completionSection;
    private static final Logger log = LoggerFactory.getLogger(AVL_CPO_Inspection_MERCEDES_BENZ_SoldUnit_NO.class);

    @BeforeClass
    public void setupPages() {
        login = new LoginPage(driver);
        home = new HomePage(driver);
        siteSettings = new SiteSettingsPage(driver);
        vehicleInfo = new VehicleInfoPage(driver);
        inspectionHome = new InspectionLandingPage(driver);
        typeOfInspectionSection = new InspectionTypeOfInspectionPage(driver);
        vehicleGeneralEligibilitySection = new InspectionVehicleGeneralEligibilityPage(driver);
        complianceRequirementsSection = new InspectionComplianceRequirementsPage(driver);
        imagesSection = new InspectionImagesPage(driver);
        commentsForClientSection = new InspectionCommentsForClientPage(driver);
        completionSection = new InspectionCompletionPage(driver);
    }

    @Test
    public void login() throws InterruptedException {
        login.defaultLogin();
        home.verifyHomePageLoaded();
        home.tapAssignedTab();
        String vinNumber = VinDetailsReader.getVinValue("FINAL_AVL_CPO_INSPECTION_MERCEDES_BENZ_SOLDUNIT_NO");
        home.initiateInspectionUsingVinFromSearchBar(vinNumber);
        vehicleInfo.verifyVehicleInfoScreenLoaded();
        vehicleInfo.clickConfirmInfoButton();
        inspectionHome.verifyLandingOfInspectionScreen(vinNumber);
        extentTest.info("Inspection screen is loaded for VIN: " + vinNumber);
    }

    @Test(dependsOnMethods = {"login"})
    public void typeOfInspection() throws Exception {
        inspectionHome.tapTypeOfInspectionSection();
        typeOfInspectionSection.verifyTypeOfInspectionTitle();
        typeOfInspectionSection.verifyMandatoryTypeOfInspection("No");
        extentTest.info("Type of Inspection section verified with 'No' option for Mercedes Benz Sold Unit.");
    }

    @Test(dependsOnMethods = {"typeOfInspection"})
    public void vehicleGeneralEligibilityInspection() throws InterruptedException {
        vehicleGeneralEligibilitySection.verifyVehicleGeneralEligibilityTitle();
        vehicleGeneralEligibilitySection.verifyVehicleSectionMercedesBenz();
        vehicleGeneralEligibilitySection.finalizeVehicleGeneralEligibilitySection();
        extentTest.info("Vehicle General Eligibility section completed successfully for Mercedes Benz Sold Unit.");
    }

    @Test(dependsOnMethods = {"vehicleGeneralEligibilityInspection"})
    public void complianceRequirementsInspection() throws InterruptedException {
        complianceRequirementsSection.verifyTitleComplianceRequirements();
        complianceRequirementsSection.verifyComplianceRequirementsButtonOptions();
        complianceRequirementsSection.finalizeComplianceRequirementsSection();
        complianceRequirementsSection.verifyComplianceStandardsButtonOptions();
        complianceRequirementsSection.verifyMBCPOMarketingStandardsButtonOptions();
        extentTest.info("Compliance Requirements section completed successfully for Mercedes Benz Sold Unit.");
    }

    @Test(dependsOnMethods = {"complianceRequirementsInspection"})
    public void imagesInspection() throws InterruptedException {
        inspectionHome.tapImagesSection();
        imagesSection.verifyImagesTitle();
        imagesSection.verifyRequiredImagesMercedesBenzSoldUnitNO();
        imagesSection.finalizeImagesSection();
        extentTest.info("Images section completed successfully for Mercedes Benz Sold Unit.");
    }

    @Test(dependsOnMethods = {"imagesInspection"})
    public void commentsForClientInspection() {
        commentsForClientSection.verifyCommentsForClientTitle();
        commentsForClientSection.verifyCommentInput();
        commentsForClientSection.finalizeCommentsForClientSection();
        extentTest.info("Comments for Client section completed successfully for Mercedes Benz Sold Unit.");
    }

    @Test(dependsOnMethods = {"commentsForClientInspection"})
    public void completeInspection() throws InterruptedException {
        inspectionHome.tapCompleteInspectionButton();
        Map<String, String> details = completionSection.verifyInspectionCompletion();
        String totalTime = details.get("TotalTime");
        String totalInspection = details.get("TotalInspections");
        log.info("Total time taken for inspection: {}", totalTime);
        log.info("Total Inspections completed: {}", totalInspection);
        extentTest.info("Inspection completed successfully with total time: " + totalTime + " and total inspections: " + totalInspection);
    }
}
