package org.openlane.autohawk.testcases.functional;

import org.openlane.autohawk.pageobject.HomePage;
import org.openlane.autohawk.pageobject.LoginPage;
import org.openlane.autohawk.pageobject.SiteSettingsPage;
import org.openlane.autohawk.pageobject.VehicleInfoPage;
import org.openlane.autohawk.testutils.BaseTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.List;

import static org.openlane.autohawk.testutils.Listeners.extentTest;

public class Home_MyInspectionsTabTC extends BaseTest {
    LoginPage login;
    HomePage home;
    SiteSettingsPage site;
    VehicleInfoPage vehicleInfo;

    @BeforeClass
    public void setupPages(){
        login = new LoginPage(driver);
        home = new HomePage(driver);
        site = new SiteSettingsPage(driver);
        vehicleInfo = new VehicleInfoPage(driver);
    }

    @Test(priority = 1)
    public void login(){
        login.defaultLogin();
        home.verifyHomePageLoaded();
        extentTest.info("Home page is loaded");
    }
    @Test(priority = 2)
    public void verifyVehicleDetailsListInMyInspectionTab() throws InterruptedException {
        List<String> details;
        home.tapAssignedTab();
        home.initiateAndVerifyInspectionThroughVinValidationUsingInputFromAssignedTab();
        vehicleInfo.verifyVehicleInfoScreenLoaded();
        vehicleInfo.clickConfirmInfoButton();
        restartApp();
        login.defaultLogin();
        home.verifyHomePageElementsDisplayedForOnSiteUser();
        home.initiateInspectionFromSiteTab();
        vehicleInfo.verifyVehicleInfoScreenLoaded();
        vehicleInfo.clickConfirmInfoButton();
        restartApp();
        login.defaultLogin();
        home.tapMyInspectionsTab();
        details = home.getDetailsOfAssignedInspections();
        for (String detail : details) {
            System.out.println(detail);
        }
    }

    //@Test(priority = 3)
    public void validateFilterOptions() throws InterruptedException {
        home.tapMyInspectionsTab();
        home.selectClearReselectApplyFilters();
        extentTest.info("Filter options are verified");
    }
}
