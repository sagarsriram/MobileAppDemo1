package org.openlane.autohawk.testcases.e2e;


import org.openlane.autohawk.pageobject.*;
import org.openlane.autohawk.testutils.BaseTest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

import static org.openlane.autohawk.testutils.Listeners.extentTest;

//changes required
public class AVL_Specialty_Inspection_KAR_Specialty extends BaseTest {

    LoginPage login;
    HomePage home;
    SiteSettingsPage siteSettings;
    VehicleInfoPage vehicleInfo;
    InspectionLandingPage inspectionHome;
    InspectionKickOffPage kickoffSection;
    InspectionFrontInteriorPage frontInteriorSection;
    InspectionRearInteriorPage rearInteriorSection;
    InspectionLeftExteriorPage leftExteriorSection;
    InspectionRearExteriorPage rearExteriorSection;
    InspectionRightExteriorPage rightExteriorSection;
    InspectionFrontExteriorPage frontExteriorSection;
    InspectionMechanicalPage mechanicalSection;
    InspectionOverallVehiclePage overallVehicleSection;
    InspectionCompletionPage completionSection;
    private static final Logger log = LoggerFactory.getLogger(AVL_Specialty_Inspection_KAR_Specialty.class);

    @BeforeClass
    public void setupPages() {
        login = new LoginPage(driver);
        home = new HomePage(driver);
        siteSettings = new SiteSettingsPage(driver);
        vehicleInfo = new VehicleInfoPage(driver);
        inspectionHome = new InspectionLandingPage(driver);
        kickoffSection = new InspectionKickOffPage(driver);
        frontInteriorSection = new InspectionFrontInteriorPage(driver);
        rearInteriorSection = new InspectionRearInteriorPage(driver);
        leftExteriorSection = new InspectionLeftExteriorPage(driver);
        rearExteriorSection = new InspectionRearExteriorPage(driver);
        rightExteriorSection = new InspectionRightExteriorPage(driver);
        frontExteriorSection = new InspectionFrontExteriorPage(driver);
        mechanicalSection = new InspectionMechanicalPage(driver);
        overallVehicleSection = new InspectionOverallVehiclePage(driver);
        completionSection = new InspectionCompletionPage(driver);
    }

    @Test
    public void login() throws InterruptedException {
        login.defaultLogin();
        home.verifyHomePageLoaded();
        home.verifyHomePageElementsDisplayedForOnSiteUser();
        String vinNumber = VinDetailsReader.getVinValue("FINAL_AVL_SPECIALTY_INSPECTION_KAR_SPECIALTY");
        home.initiateInspectionUsingVinFromSearchBar(vinNumber);
        vehicleInfo.verifyVehicleInfoScreenLoaded();
        vehicleInfo.clickConfirmInfoButton();
        inspectionHome.verifyLandingOfInspectionScreen(vinNumber);
        extentTest.info("Inspection screen is loaded for VIN: " + vinNumber);
    }

    @Test(dependsOnMethods = {"login"})
    public void kickoffInspection() throws InterruptedException {
        inspectionHome.tapKickoffSection();
        kickoffSection.verifyKickOffScreenTitle();
        kickoffSection.verifyMandatoryInspectionDetailsVehicleTypeRadioButtons();
        kickoffSection.verifyMandatoryInspectionDetailsNumberOfDoorsOptions();
        kickoffSection.verifyMandatoryInspectionDetailsVehicleSourceTypeDropDown();
        kickoffSection.verifyMandatoryInspectionDetailsArrivalDateDropDown();
        kickoffSection.verifyMandatoryKickoffPhotosDashVINPlatePhoto();
        kickoffSection.verifyMandatoryKickoffPhotosLeftFrontThreeQuartersPhoto();
        kickoffSection.verifyMandatoryKickoffPhotosLeftFrontWheelTirePhoto();
        kickoffSection.verifyMandatoryKickoffPhotosUnderCarriageLeftPhoto();
        kickoffSection.verifyMandatoryKickoffPhotosFrontInteriorPhoto();
        kickoffSection.verifyMandatoryVINStickerVINStickerPhoto();
        kickoffSection.verifyMandatoryEngineDetailsEngineDetailsDropDown();
        kickoffSection.verifyMandatoryExteriorColorsPrimaryExteriorColorsDropDown();
        kickoffSection.finalizeKickOffSection();
        extentTest.info("Kickoff section is completed successfully");
    }

    @Test(dependsOnMethods = {"kickoffInspection"})
    public void frontInteriorInspection() throws InterruptedException {
        inspectionHome.tapFrontInteriorSection();
        frontInteriorSection.verifyFrontInteriorTitle();
        frontInteriorSection.verifyMandatoryOdorPresentButton();
        frontInteriorSection.verifyMandatoryInteriorColorDropDown();
        frontInteriorSection.verifyMandatoryKeysSection();
        frontInteriorSection.verifyMandatoryKeysFobsManualPhoto();
        frontInteriorSection.verifyMandatoryDrivableDropDown();
        frontInteriorSection.verifyMandatoryOdometerInfo();
        frontInteriorSection.verifyMandatoryFuelRadioButton();
        frontInteriorSection.verifyMandatoryOBD2CodesSkip();
        frontInteriorSection.verifyMandatoryDriverControls();
        frontInteriorSection.verifyMandatoryHeating();
        frontInteriorSection.verifyMandatorySoundSystem();
        frontInteriorSection.verifyMandatorySafetyOptions();
        frontInteriorSection.verifyMandatorySeating();
        frontInteriorSection.finaliseFrontInteriorSection();
        extentTest.info("Front interior inspection is completed successfully");
    }

    @Test(dependsOnMethods = {"frontInteriorInspection"})
    public void rearInteriorInspection() throws InterruptedException {
        inspectionHome.tapRearInteriorSection();
        rearInteriorSection.verifyRearInteriorTitle();
        rearInteriorSection.verifyMandatoryInteriorPhoto();
        rearInteriorSection.finalizeRearInteriorInspection();
        extentTest.info("Rear interior inspection is completed successfully");
    }

    @Test(dependsOnMethods = {"rearInteriorInspection"})
    public void leftExteriorInspection() throws InterruptedException {
        inspectionHome.tapLeftExteriorSection();
        leftExteriorSection.verifyLeftExteriorScreenTitle();
        leftExteriorSection.addDamageLFTireWheel();
        leftExteriorSection.verifyMandatoryLFTireOrWheelsDropdowns();
        leftExteriorSection.verifyMandatoryLRTireOrWheelDropDowns();
        leftExteriorSection.verifyMandatoryLeftRearThreeQuartersPhoto();
        leftExteriorSection.finalizeLeftExteriorSection();
        extentTest.info("Left exterior inspection is completed successfully");
    }

    @Test(dependsOnMethods = {"leftExteriorInspection"})
    public void rearExteriorInspection() throws InterruptedException {
        inspectionHome.tapRearExteriorSection();
        rearExteriorSection.verifyRearExteriorTitle();
        rearExteriorSection.verifyMandatoryCargoAreaSection();
        rearExteriorSection.verifyMandatorySpareTireSection();
        rearExteriorSection.verifyMandatoryUnderCarriagePhotoSection();
        rearExteriorSection.finalizeRearExteriorInspection();
        extentTest.info("Rear exterior inspection is completed successfully");
    }

    @Test(dependsOnMethods = {"rearExteriorInspection"})
    public void rightExteriorInspection() throws InterruptedException {
        rightExteriorSection.verifyRightExteriorTitle();
        rightExteriorSection.verifyMandatoryRightRearThreeQuartersPhoto();
        rightExteriorSection.verifyMandatoryRRTireOrWheelDropDown();
        rightExteriorSection.verifyMandatoryUnderCarriageRightPhoto();
        rightExteriorSection.verifyMandatoryRFTireOrWheelDropDown();
        rightExteriorSection.finalizeRightExteriorSection();
        extentTest.info("Right exterior inspection is completed successfully");
    }

    @Test(dependsOnMethods = {"rightExteriorInspection"})
    public void frontExteriorInspection() throws InterruptedException {
        frontExteriorSection.verifyFrontExteriorTitle();
        frontExteriorSection.verifyMandatoryRoofSection();
        frontExteriorSection.verifyMandatoryUnderCarriagePhotoFrontSection();
        frontExteriorSection.finalizeFrontExteriorInspection();
        extentTest.info("Front exterior inspection is completed successfully");
    }

    @Test(dependsOnMethods = {"frontExteriorInspection"})
    public void mechanicalInspection() throws InterruptedException {
        mechanicalSection.verifyMechanicalSectionTitle();
        mechanicalSection.verifyMandatoryEmissionStickerSection();
        mechanicalSection.verifyMandatoryEngineSection();
        mechanicalSection.verifyMandatoryDrivetrainSection();
        mechanicalSection.finalizeMechanicalInspection();
        extentTest.info("Mechanical inspection is completed successfully");
    }

    @Test(dependsOnMethods = {"mechanicalInspection"})
    public void overallVehicleInspection() throws InterruptedException {
        overallVehicleSection.verifyOverallVehicleSectionTitle();
        overallVehicleSection.verifyMandatoryRightFrontThreeQuartersPhoto();
        overallVehicleSection.verifyMandatoryVehicleAdminVehicleGrade();
        overallVehicleSection.finalizeOverallInspection();
        extentTest.info("Overall vehicle inspection is completed successfully");
    }

    @Test(dependsOnMethods = {"overallVehicleInspection"})
    public void completeInspection() throws InterruptedException {
        inspectionHome.tapCompleteInspectionButton();
        Map<String, String> details = completionSection.verifyInspectionCompletion();
        String totalTime = details.get("TotalTime");
        String totalInspection = details.get("TotalInspections");
        log.info("Total time taken for inspection: {}", totalTime);
        log.info("Total Inspections completed: {}", totalInspection);
        extentTest.info("Inspection completed successfully with total time: " + totalTime + " and total inspections: " + totalInspection);
    }
}
