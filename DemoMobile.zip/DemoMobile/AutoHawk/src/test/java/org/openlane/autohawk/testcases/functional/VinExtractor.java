package org.openlane.autohawk.testcases.functional;


    import org.openlane.autohawk.utils.AppiumGeneric;
    import org.openqa.selenium.WebDriver;
    import org.slf4j.Logger;
    import org.slf4j.LoggerFactory;
    import org.testng.annotations.Test;

    import java.util.regex.Matcher;
    import java.util.regex.Pattern;

    public class VinExtractor {
        private static final Logger log = LoggerFactory.getLogger(VinExtractor.class);
        public static void main(String[] args) {

           String vin =  AppiumGeneric.VinDetailsReader.getVinValue("");
           log.info("VIN from AppiumGeneric: {}", vin);
            log.info("abcd");
            String first = "Silver • SCAZD02A8JCX23877";
            String second = "Red • WDZPE7CC1A5452218";

            // Regular expression to match the VIN (alphanumeric sequence)
            String vinRegex = "\\b[0-9A-Z]{17}\\b";

            System.out.println("Extracted VIN from first: " + extractVin(first, vinRegex));
            System.out.println("Extracted VIN from second: " + extractVin(second, vinRegex));
        }

        private static String extractVin(String input, String regex) {
            Pattern pattern = Pattern.compile(regex);
            Matcher matcher = pattern.matcher(input);
            if (matcher.find()) {
                return matcher.group(); // Return the matched VIN
            }
            return "No VIN found";
        }

        @Test
        public void sample(){
            System.out.println("working");
        }



}
