package org.openlane.autohawk.testcases.e2e;

import org.openlane.autohawk.pageobject.*;
import org.openlane.autohawk.testutils.BaseTest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

import static org.openlane.autohawk.testutils.Listeners.extentTest;


public class AVL_CPO_SoldUnit_No extends BaseTest {
    // This class is a placeholder for the full inspection test case.
    // It will contain methods to perform end-to-end testing of the application.
    // The actual implementation will depend on the specific requirements and flow of the application.

    LoginPage login;
    HomePage home;
    SiteSettingsPage siteSettings;
    VehicleInfoPage vehicleInfo;
    InspectionLandingPage inspectionHome;
    InspectionTypeOfInspectionPage typeOfInspectionSection;
    InspectionMarketingAndPaperworkPage marketingAndPaperworkSection;
    InspectionVehicleGeneralEligibilityPage vehicleGeneralEligibilitySection;
    InspectionMechanicalTwoPage mechanicalTwoSection;
    InspectionElectricalPage electricalSection;
    InspectionExteriorAppearanceDetailingPage exteriorAppearanceSection;
    InspectionInternetPage internetSection;
    InspectionImagesPage imagesSection;
    InspectionCommentsForClientPage commentsForClientSection;
    InspectionCompletionPage completionSection;
    private static final Logger log = LoggerFactory.getLogger(AVL_CPO_SoldUnit_No.class);

    @BeforeClass
    public void setupPages() {
        login = new LoginPage(driver);
        home = new HomePage(driver);
        siteSettings = new SiteSettingsPage(driver);
        vehicleInfo = new VehicleInfoPage(driver);
        inspectionHome = new InspectionLandingPage(driver);
        typeOfInspectionSection = new InspectionTypeOfInspectionPage(driver);
        marketingAndPaperworkSection = new InspectionMarketingAndPaperworkPage(driver);
        vehicleGeneralEligibilitySection = new InspectionVehicleGeneralEligibilityPage(driver);
        mechanicalTwoSection = new InspectionMechanicalTwoPage(driver);
        electricalSection = new InspectionElectricalPage(driver);
        exteriorAppearanceSection = new InspectionExteriorAppearanceDetailingPage(driver);
        internetSection = new InspectionInternetPage(driver);
        imagesSection = new InspectionImagesPage(driver);
        commentsForClientSection = new InspectionCommentsForClientPage(driver);
        completionSection = new InspectionCompletionPage(driver);
    }

    @Test
    public void login() throws InterruptedException {
        //login to the app and launch home screen
        login.defaultLogin();
        home.verifyHomePageLoaded();
        home.tapAssignedTab();
        String vinNumber = home.initiateAndVerifyInspectionThroughVinValidationUsingInputFromAssignedTab();
//        home.verifyHomePageElementsDisplayedForOnSiteUser();
//        String vinNumber = home.initiateInspectionFromSiteTab(); // change index to select inspection
        vehicleInfo.verifyVehicleInfoScreenLoaded();
        vehicleInfo.clickConfirmInfoButton();
        inspectionHome.verifyLandingOfInspectionScreen(vinNumber);
        //extentTest.info("Inspection screen is loaded for VIN: " + vinNumber);
    }

    @Test(dependsOnMethods = {"login"})
    public void typeOfInspection() throws Exception {
        inspectionHome.tapTypeOfInspectionSection();
        typeOfInspectionSection.verifyTypeOfInspectionTitle();
        typeOfInspectionSection.verifyMandatoryTypeOfInspection("No");
    }

    @Test(dependsOnMethods = {"typeOfInspection"})
    public void marketingAndPaperWorkInspection() throws InterruptedException {
        inspectionHome.tapMarketingAndPaperworkSection();
        marketingAndPaperworkSection.verifyMarketingAndPaperworkTitle();
        marketingAndPaperworkSection.verifyMarketingAndPaperworkButtonOptionsGulfState();
        marketingAndPaperworkSection.finalizeMarketingAndPaperworkSection();
    }
    @Test(dependsOnMethods = {"marketingAndPaperWorkInspection"})
    public void vehicleGeneralEligibilityInspection() throws InterruptedException {
        vehicleGeneralEligibilitySection.verifyVehicleGeneralEligibilityTitle();
       vehicleGeneralEligibilitySection.verifyVehicleSectionGulfState();
       vehicleGeneralEligibilitySection.verifyGeneralEligibilitySectionGulfState();
       vehicleGeneralEligibilitySection.finalizeVehicleGeneralEligibilitySection();
    }
    @Test(dependsOnMethods = {"vehicleGeneralEligibilityInspection"})
    public void mechanicalTwoInspection() throws InterruptedException {
        mechanicalTwoSection.verifyMechanicalTitle();
        mechanicalTwoSection.verifyMechanicalButtonOptionsGulfState();
        mechanicalTwoSection.finalizeMechanicalSection();
    }
    @Test(dependsOnMethods = {"mechanicalTwoInspection"})
    public void electricalInspection() throws InterruptedException {
        electricalSection.verifyElectricalTitle();
        electricalSection.verifyElectricalButtonOptionsGulfState();
        electricalSection.finalizeElectricalSection();
    }
    @Test(dependsOnMethods = {"electricalInspection"})
    public void exteriorAppearanceInspection() throws InterruptedException {
        exteriorAppearanceSection.verifyExteriorAppearanceDetailingTitle();
        exteriorAppearanceSection.verifyExteriorAppearanceDetailingButtonOptionsGulfState();
        exteriorAppearanceSection.finalizeExteriorAppearanceDetailingSection();
    }
    @Test(dependsOnMethods = {"exteriorAppearanceInspection"})
    public void internetInspection() throws InterruptedException {
        internetSection.verifyInternetTitle();
        internetSection.verifyInternetButtonOptionsGulfState();
        internetSection.finalizeInternetSection();
    }
    @Test(dependsOnMethods = {"internetInspection"})
    public void ImagesInspection() throws InterruptedException {
        imagesSection.verifyImagesTitle();
        imagesSection.finalizeImagesSection();
    }
    @Test(dependsOnMethods = {"ImagesInspection"})
    public void commentsForClientInspection() {
        commentsForClientSection.verifyCommentsForClientTitle();
        commentsForClientSection.verifyCommentInput();
        commentsForClientSection.finalizeCommentsForClientSection();
    }
    @Test(dependsOnMethods = {"commentsForClientInspection"})
    public void completeInspection() throws InterruptedException {
        //complete Inspection
        inspectionHome.tapCompleteInspectionButton();
        Map<String, String> details = completionSection.verifyInspectionCompletion();
        String totalTime = details.get("TotalTime");
        String totalInspection = details.get("TotalInspections");
        log.info("Total time taken for inspection: {}", totalTime);
        log.info("Total Inspections completed: {}", totalInspection);
        extentTest.info("Inspection completed successfully with total time: " + totalTime + " and total inspections: " + totalInspection);

    }
}
