package org.openlane.autohawk.testcases.e2e;

public class AVL_Specialty_Inspection_SP_MARINE {
}
