package org.openlane.autohawk.testcases.functional;

import org.openlane.autohawk.pageobject.HomePage;
import org.openlane.autohawk.pageobject.LoginPage;
import org.openlane.autohawk.testutils.BaseTest;
import org.openlane.autohawk.utils.AppiumGeneric;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class LoginTC extends BaseTest {

    LoginPage login;
    HomePage home;

    @BeforeClass
    public void setupPages() {
        login = new LoginPage(driver);
        home = new HomePage(driver);
    }

    public void performLoginAndVerify(String username, String password, String expectedErrorType) {
        login.verifyLoginScreenLoadedAfterLoginButton();
        login.enterCredentials(username, password);
        login.clickRememberMe();
        login.clickSignIn();
        switch (expectedErrorType) {
            case "blank":
                login.verifyBlankFieldError(); // handles error for blank username/password
                driver.navigate().back();
                break;
            case "invalid":
                login.verifyInvalidCredentialError(); // handles error for wrong username/password
                driver.navigate().back();
                break;
            case "none":
                home.verifyHomePageLoaded(); // success path
                break;
        }
    }

    @Test(priority = 1)
    public void verifyBlankUserNameAndPassword() {
        performLoginAndVerify("", "", "blank");
    }

    @Test(priority = 2)
    public void verifyInvalidUserNameAndPassword() {
        performLoginAndVerify("random", "random123", "invalid");
    }

    @Test(priority = 3)
    public void verifyValidUserNameInvalidPassword() {
        performLoginAndVerify("sagar@openlane.com", "random123", "invalid");
    }

    @Test(priority = 4)
    public void verifyInvalidUserNameValidPassword() {
        performLoginAndVerify("random", "Jalal@9715", "invalid");
    }

    @Test(priority = 5)
    public void verifyLoginWithValidCredentials() {
        String name = AppiumGeneric.getProperty("username");
        String password = AppiumGeneric.getProperty("password");
        performLoginAndVerify(name, password, "none");
    }

}
