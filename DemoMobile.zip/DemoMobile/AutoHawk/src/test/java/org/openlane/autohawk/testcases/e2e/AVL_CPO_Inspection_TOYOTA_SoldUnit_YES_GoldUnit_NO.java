package org.openlane.autohawk.testcases.e2e;

import org.openlane.autohawk.pageobject.*;
import org.openlane.autohawk.testutils.BaseTest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

import static org.openlane.autohawk.testutils.Listeners.extentTest;

//Completed - do not alter code unless u debug

public class AVL_CPO_Inspection_TOYOTA_SoldUnit_YES_GoldUnit_NO extends BaseTest {
    // This class is a placeholder for the full inspection test case.
    // It will contain methods to perform end-to-end testing of the application.
    // The actual implementation will depend on the specific requirements and flow of the application.

    //VIN - used - 5TDJY5G15ES093742

    LoginPage login;
    HomePage home;
    SiteSettingsPage siteSettings;
    VehicleInfoPage vehicleInfo;
    InspectionLandingPage inspectionHome;
    InspectionTypeOfInspectionPage typeOfInspectionSection;
    InspectionImagesPage imagesSection;
    InspectionCPOAuditSoldUnitPaperworkPage soldUnitPaperwork;
    InspectionCommentsForClientPage commentsForClientSection;
    InspectionCompletionPage completionSection;
    private static final Logger log = LoggerFactory.getLogger(AVL_CPO_Inspection_TOYOTA_SoldUnit_YES_GoldUnit_NO.class);

    @BeforeClass
    public void setupPages() {
        login = new LoginPage(driver);
        home = new HomePage(driver);
        siteSettings = new SiteSettingsPage(driver);
        vehicleInfo = new VehicleInfoPage(driver);
        inspectionHome = new InspectionLandingPage(driver);
        typeOfInspectionSection = new InspectionTypeOfInspectionPage(driver);
        imagesSection = new InspectionImagesPage(driver);
        soldUnitPaperwork = new InspectionCPOAuditSoldUnitPaperworkPage(driver);
        commentsForClientSection = new InspectionCommentsForClientPage(driver);
        completionSection = new InspectionCompletionPage(driver);
    }

    @Test
    public void login() throws InterruptedException {
        login.defaultLogin();
        home.verifyHomePageLoaded();
        home.tapAssignedTab();
        String vinNumber = VinDetailsReader.getVinValue("FINAL_AVL_CPO_INSPECTION_TOYOTA_SOLDUNIT_YES_GOLDUNIT_NO");
        home.initiateInspectionUsingVinFromSearchBar(vinNumber);
        vehicleInfo.verifyVehicleInfoScreenLoaded();
        vehicleInfo.clickConfirmInfoButton();
        inspectionHome.verifyLandingOfInspectionScreen(vinNumber);
        extentTest.info("Inspection screen is loaded for VIN: " + vinNumber);
    }

    @Test(dependsOnMethods = {"login"})
    public void typeOfInspection() throws Exception {
        inspectionHome.tapTypeOfInspectionSection();
        typeOfInspectionSection.verifyTypeOfInspectionTitle();
        typeOfInspectionSection.verifyMandatoryTypeOfInspectionGoldUnit("Yes", "No");
        extentTest.info("Type of Inspection section completed successfully with Sold Unit: Yes and Gold Unit: No.");
    }

    @Test(dependsOnMethods = {"typeOfInspection"})
    public void ImagesInspection() throws InterruptedException {
        inspectionHome.tapImagesSection();
        imagesSection.verifyImagesTitle();
        imagesSection.verifyRequiredImagesToyotaSoldUnitYESAndGoldUnitSelected();
        imagesSection.finalizeImagesSection();
        extentTest.info("Images section completed successfully for Toyota Sold Unit YES and Gold Unit NO.");
    }

    @Test(dependsOnMethods = {"typeOfInspection"})
    public void SoldUnitPaperworkInspection() throws InterruptedException {
        soldUnitPaperwork.verifyCPOAuditSoldUnitPaperWorkTitle();
        soldUnitPaperwork.verifyPaperworkOnFileButtonOptionsToyotaSoldUnitYESGoldUnitNO();
        soldUnitPaperwork.finalizeCPOAuditSoldUnitPaperworkSection();
        extentTest.info("CPO Audit - Sold Unit Paperwork section completed successfully for Toyota Sold Unit YES and Gold Unit NO.");
    }

    @Test(dependsOnMethods = {"ImagesInspection"})
    public void commentsForClientInspection() {
        commentsForClientSection.verifyCommentsForClientTitle();
        commentsForClientSection.verifyCommentInput();
        commentsForClientSection.finalizeCommentsForClientSection();
        extentTest.info("Comments for Client section completed successfully.");
    }

    @Test(dependsOnMethods = {"commentsForClientInspection"})
    public void completeInspection() throws InterruptedException {
        inspectionHome.tapCompleteInspectionButton();
        Map<String, String> details = completionSection.verifyInspectionCompletion();
        String totalTime = details.get("TotalTime");
        String totalInspection = details.get("TotalInspections");
        log.info("Total time taken for inspection: {}", totalTime);
        log.info("Total Inspections completed: {}", totalInspection);
        extentTest.info("Inspection completed successfully with total time: " + totalTime + " and total inspections: " + totalInspection);
    }
}
