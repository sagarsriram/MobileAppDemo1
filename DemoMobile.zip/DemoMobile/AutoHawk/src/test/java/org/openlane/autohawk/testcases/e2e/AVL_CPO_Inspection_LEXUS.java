package org.openlane.autohawk.testcases.e2e;

import org.openlane.autohawk.pageobject.*;
import org.openlane.autohawk.testutils.BaseTest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

import static org.openlane.autohawk.testutils.Listeners.extentTest;

//Completed - do not alter anything unless u debug

public class AVL_CPO_Inspection_LEXUS extends BaseTest {
    // This class is a placeholder for the full inspection test case.
    // It will contain methods to perform end-to-end testing of the application.
    // The actual implementation will depend on the specific requirements and flow of the application.
    LoginPage login;
    HomePage home;
    SiteSettingsPage siteSettings;
    VehicleInfoPage vehicleInfo;
    InspectionLandingPage inspectionHome;
    InspectionDisplayMarketingInformationPage inspectionDisplayMarketingInformationSection;
    InspectionMarketingAndPaperworkPage marketingAndPaperworkSection;
    InspectionVehicleGeneralEligibilityPage vehicleGeneralEligibilitySection;
    InspectionMechanicalTwoPage mechanicalTwoSection;
    InspectionElectricalPage electricalSection;
    InspectionInteriorAppearanceDetailingPage interiorAppearanceSection;
    InspectionExteriorAppearanceDetailingPage exteriorAppearanceSection;
    InspectionImagesPage imagesSection;
    InspectionCommentsForClientPage commentsForClientSection;
    InspectionCompletionPage completionSection;
    private static final Logger log = LoggerFactory.getLogger(AVL_CPO_Inspection_LEXUS.class);

    @BeforeClass
    public void setupPages() {
        login = new LoginPage(driver);
        home = new HomePage(driver);
        siteSettings = new SiteSettingsPage(driver);
        vehicleInfo = new VehicleInfoPage(driver);
        inspectionHome = new InspectionLandingPage(driver);
        inspectionDisplayMarketingInformationSection = new InspectionDisplayMarketingInformationPage(driver);
        marketingAndPaperworkSection = new InspectionMarketingAndPaperworkPage(driver);
        vehicleGeneralEligibilitySection = new InspectionVehicleGeneralEligibilityPage(driver);
        mechanicalTwoSection = new InspectionMechanicalTwoPage(driver);
        electricalSection = new InspectionElectricalPage(driver);
        interiorAppearanceSection = new InspectionInteriorAppearanceDetailingPage(driver);
        exteriorAppearanceSection = new InspectionExteriorAppearanceDetailingPage(driver);
        imagesSection = new InspectionImagesPage(driver);
        commentsForClientSection = new InspectionCommentsForClientPage(driver);
        completionSection = new InspectionCompletionPage(driver);
    }

    @Test
    public void login() throws InterruptedException {
        login.defaultLogin();
        home.verifyHomePageLoaded();
        home.tapAssignedTab();
        String vinNumber = VinDetailsReader.getVinValue("FINAL_AVL_CPO_INSPECTION_LEXUS");
        home.initiateInspectionUsingVinFromSearchBar(vinNumber);
        vehicleInfo.verifyVehicleInfoScreenLoaded();
        vehicleInfo.clickConfirmInfoButton();
        inspectionHome.verifyLandingOfInspectionScreen(vinNumber);
        extentTest.info("Inspection screen is loaded for VIN: " + vinNumber);
    }

    @Test(dependsOnMethods = {"login"})
    public void displayMarketingInformationInspection() throws Exception {
        inspectionHome.tapDisplayMarketingInformationSection();
        inspectionDisplayMarketingInformationSection.verifyTitleDisplayMarketingInformation();
        inspectionDisplayMarketingInformationSection.verifyDisplayMarketingInformationButtonOptions();
        inspectionDisplayMarketingInformationSection.finalizeDisplayMarketingInformationSection();
        extentTest.info("Display Marketing Information section completed successfully.");
    }

    @Test(dependsOnMethods = {"displayMarketingInformationInspection"})
    public void marketingAndPaperWorkInspection() throws InterruptedException {
        inspectionHome.tapMarketingAndPaperworkSection();
        marketingAndPaperworkSection.verifyMarketingAndPaperworkTitle();
        marketingAndPaperworkSection.verifyPaperworkButtonOptionsLexus();
        marketingAndPaperworkSection.finalizeMarketingAndPaperworkSection();
        extentTest.info("Marketing and Paperwork section completed successfully.");
    }

    @Test(dependsOnMethods = {"marketingAndPaperWorkInspection"})
    public void vehicleGeneralEligibilityInspection() throws InterruptedException {
        vehicleGeneralEligibilitySection.verifyVehicleGeneralEligibilityTitle();
        vehicleGeneralEligibilitySection.verifyVehicleInfoSectionLexus();
        vehicleGeneralEligibilitySection.verifyGeneralEligibilitySectionLexus();
        vehicleGeneralEligibilitySection.finalizeVehicleGeneralEligibilitySection();
        extentTest.info("Vehicle General Eligibility section completed successfully.");
    }

    @Test(dependsOnMethods = {"vehicleGeneralEligibilityInspection"})
    public void mechanicalTwoInspection() throws InterruptedException {
        mechanicalTwoSection.verifyMechanicalTitle();
        mechanicalTwoSection.verifyMechanicalButtonOptionsLexus();
        mechanicalTwoSection.finalizeMechanicalSection();
        extentTest.info("Mechanical section completed successfully.");
    }

    @Test(dependsOnMethods = {"mechanicalTwoInspection"})
    public void electricalInspection() throws InterruptedException {
        electricalSection.verifyElectricalTitle();
        electricalSection.verifyElectricalButtonOptionsLexus();
        electricalSection.finalizeElectricalSection();
        extentTest.info("Electrical section completed successfully.");
    }

    @Test(dependsOnMethods = {"electricalInspection"})
    public void interiorAppearanceInspection() throws InterruptedException {
        interiorAppearanceSection.verifyInteriorAppearanceDetailingTitle();
        interiorAppearanceSection.verifyInteriorAppearanceDetailingButtonOptionsLexus();
        interiorAppearanceSection.finalizeInteriorAppearanceDetailingSection();
        extentTest.info("Interior Appearance Detailing section completed successfully.");
    }

    @Test(dependsOnMethods = {"interiorAppearanceInspection"})
    public void exteriorAppearanceInspection() throws InterruptedException {
        exteriorAppearanceSection.verifyExteriorAppearanceDetailingTitle();
        exteriorAppearanceSection.verifyExteriorAppearanceDetailingButtonOptionsLexus();
        exteriorAppearanceSection.finalizeExteriorAppearanceDetailingSection();
        extentTest.info("Exterior Appearance Detailing section completed successfully.");
    }

    @Test(dependsOnMethods = {"exteriorAppearanceInspection"})
    public void ImagesInspection() throws InterruptedException {
        imagesSection.verifyImagesTitle();
        imagesSection.verifyRequiredImagesLexus();
        imagesSection.finalizeImagesSection();
        extentTest.info("Images section completed successfully.");
    }

    @Test(dependsOnMethods = {"ImagesInspection"})
    public void commentsForClientInspection() {
        commentsForClientSection.verifyCommentsForClientTitle();
        commentsForClientSection.verifyCommentInput();
        commentsForClientSection.finalizeCommentsForClientSection();
        extentTest.info("Comments for Client section completed successfully.");
    }

    @Test(dependsOnMethods = {"commentsForClientInspection"})
    public void completeInspection() throws InterruptedException {
        inspectionHome.tapCompleteInspectionButton();
        Map<String, String> details = completionSection.verifyInspectionCompletion();
        String totalTime = details.get("TotalTime");
        String totalInspection = details.get("TotalInspections");
        log.info("Total time taken for inspection: {}", totalTime);
        log.info("Total Inspections completed: {}", totalInspection);
        extentTest.info("Inspection completed successfully with total time: " + totalTime + " and total inspections: " + totalInspection);
    }
}
