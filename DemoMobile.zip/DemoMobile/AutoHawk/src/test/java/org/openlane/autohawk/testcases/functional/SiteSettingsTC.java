package org.openlane.autohawk.testcases.functional;

import org.openlane.autohawk.pageobject.HomePage;
import org.openlane.autohawk.pageobject.LoginPage;
import org.openlane.autohawk.pageobject.SiteSettingsPage;
import org.openlane.autohawk.testutils.BaseTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.openlane.autohawk.testutils.Listeners.extentTest;

public class SiteSettingsTC extends BaseTest {
    LoginPage login;
    HomePage home;
    SiteSettingsPage site;

    @BeforeClass
    public void setupPages() {
        login = new LoginPage(driver);
        home = new HomePage(driver);
        site = new SiteSettingsPage(driver);
    }

    @Test(priority = 1)
    public void validateSiteSettingLoadedAfter_Login() {
        login.defaultLogin();
        home.tapOverFlowMenu();
        home.clickOverflowMenuOptions("site settings");
        site.verifySiteSettingsTitle();
        extentTest.info("login and landed on Site Settings screen");
    }

    @Test(priority = 2)
    public void verifyInvalidInputOnSearchBarThrowsValidErrorMessage() {
        site.navigateToSearchBarThroughOnSiteTab();
        site.searchForInvalidSite("123abc");
        driver.navigate().back();
        extentTest.info("invalid message is shown");
    }
    @Test(priority = 3)
    public void ValidateMentionedOnSiteLocationIsLoaded() throws InterruptedException {
        site.navigateToSearchBarThroughOnSiteTab();
        site.getSearchResults("cal");
        Thread.sleep(5);
        site.clickOnResult("openlane calgary");
        extentTest.info("calgary is loaded");
    }

}

