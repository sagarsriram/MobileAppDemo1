package org.openlane.autohawk.testcases.functional;

import org.openlane.autohawk.pageobject.GetHelpPage;
import org.openlane.autohawk.pageobject.HomePage;
import org.openlane.autohawk.pageobject.LoginPage;
import org.openlane.autohawk.testutils.BaseTest;
import org.openlane.autohawk.utils.AppiumGeneric;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.openlane.autohawk.testutils.Listeners.extentTest;

public class GetHelpTC extends BaseTest {
    LoginPage login;
    HomePage home;
    GetHelpPage help;

    @BeforeClass
    public void setupPages() {
        login = new LoginPage(driver);
        home = new HomePage(driver);
        help = new GetHelpPage(driver);
    }

    @Test(priority = 1)
    public void navigateToGetHelpScreen_AfterLogin() {
        login.verifyLoginScreenLoadedAfterLoginButton();
        login.enterCredentials(AppiumGeneric.getProperty("username"), AppiumGeneric.getProperty("password"));
        login.clickSignIn();
        home.tapOverFlowMenu();
        home.clickOverflowMenuOptions("get help");
        extentTest.info("landed on Get Help screen after logging in");
    }

    @Test(priority = 2)
    public void verifyUserInteractionWithGetHelp() {
        help.verifyGetHelpSubTitle();
        help.uploadGif();
        extentTest.info("gif uploaded successfully");
        help.uploadPhoto();
        extentTest.info("photo uploaded successfully");
        help.sendMessage();
        extentTest.info("message sent successfully");

    }
}
