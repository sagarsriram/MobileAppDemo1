package org.openlane.autohawk.testcases.functional;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.options.XCUITestOptions;
import io.appium.java_client.service.local.AppiumServiceBuilder;
import org.openlane.autohawk.utils.AppiumGeneric;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

public class BrowserStackDemo {

    public static void main(String[] args) {
        AndroidDriver driver;
        UiAutomator2Options options = new UiAutomator2Options();

        //options.setCapability("browserstack.user", "sagars_BG1RzH");
        //options.setCapability("browserstack.key", "M6DcDNtGTuovKPLrE2dK");
      //  options.setCapability("app", "bs://e4a1c02552c6dd29e598cf50ac08a037e33c3574");
        options.setCapability("deviceName", "Samsung Galaxy S21");
        options.setCapability("os_version", "11.0");
        options.setCapability("browserName", "Chrome");
        //options.setCapability("automationName", "Appium");
        options.autoGrantPermissions();
        options.setAutoWebview(false);

//        IOSDriver driver;
//        XCUITestOptions options = new XCUITestOptions();
//        options.setCapability("app", "bs://a405f7f56fb6f84c1e29afdcb2d4a4d2f17bbaa6");
//        options.setCapability("deviceName", "iPhone 16 Pro");
//        options.setCapability("os_version", "18.0");

        try {
           // URL appiumServerUrl = new URL("http://hud-cloud.browserstack.com/wd/hub");
            URL appiumServerUrl = new URL("https://sagars_BG1RzH:M6DcDNtGTuovKPLrE2dK@hub-cloud.browserstack.com/wd/hub");
            driver = new AndroidDriver(appiumServerUrl, options);
            //driver = new IOSDriver(appiumServerUrl, options);
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        }

        driver.findElement(AppiumBy.iOSClassChain("**/XCUIElementTypeStaticText[`name == \"TEMP LOG IN\"`]")).click();

    }
}
