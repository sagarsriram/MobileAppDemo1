package org.openlane.autohawk.testcases.functional;

import org.openlane.autohawk.pageobject.HomePage;
import org.openlane.autohawk.pageobject.LoginPage;
import org.openlane.autohawk.pageobject.SiteSettingsPage;
import org.openlane.autohawk.testutils.BaseTest;
import org.openlane.autohawk.utils.AppiumGeneric;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.List;

import static org.openlane.autohawk.testutils.Listeners.extentTest;

public class Home_AssignedTabTC extends BaseTest {

    LoginPage login;
    HomePage home;
    SiteSettingsPage site;
    AppiumGeneric generic;

    @BeforeClass
    public void setupPages(){
        login = new LoginPage(driver);
        home = new HomePage(driver);
        site = new SiteSettingsPage(driver);
        generic = new AppiumGeneric();
        generic.setDriver(driver);
    }

    @Test(priority = 1)
    public void login(){
        login.defaultLogin();
        home.verifyHomePageLoaded();
        extentTest.info("login confirmed");
    }

    @Test(priority = 2)
    public void verifyAssignedTabForOffSiteUser() throws InterruptedException {
        List<String> details;
        home.synchronizeByRefresh();
        home.tapAssignedTab();
        details = home.getDetailsOfAssignedInspections();
        for (String detail : details){
            extentTest.info(detail);
        }
        extentTest.info("Offsite user tab is verified with the list mentioned");
    }

    @Test(priority = 3)
    public void verifyAssignedTabForOnSiteUser() throws  InterruptedException {
        List<String> details;
        home.tapOverFlowMenu();
        home.clickOverflowMenuOptions("site settings");
        site.navigateToSearchBarThroughOnSiteTab();
        site.getSearchResults("ca");
        site.clickOnResult("openlane calgary");
        home.tapAssignedTab();
        home.synchronizeByRefresh();
        details = home.getDetailsOfAssignedInspections();
        for (String detail : details){
            extentTest.info(detail);
        }
        extentTest.info("Onsite user tab is verified with the list mentioned");
    }

    @Test(priority = 4)
    public void validateVinFromTheExistingInspection(){
        String vin;
        home.synchronizeByRefresh();
        home.tapAssignedTab();
        vin =  home.initiateAndVerifyInspectionThroughVinValidationUsingInputFromAssignedTab() ;
        extentTest.info("VIN number used for validation: " + vin);
    }

    @Test(priority = 5)
    public void validateFilterOptions(){
        home.selectClearReselectApplyFilters();
    }
}
